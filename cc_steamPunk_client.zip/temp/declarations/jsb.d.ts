/// <reference path="C:\ProgramData\cocos\editors\Creator\3.8.0\resources\resources\3d\engine\@types\jsb.d.ts"/>
