
    /// <reference path="C:\ProgramData\cocos\editors\Creator\3.8.0\resources\resources\3d\engine\bin\.declarations\cc.d.ts"/>
    
    /**
     * @deprecated Global variable `cc` was dropped since 3.0. Use ES6 module syntax to import Cocos Creator APIs.
     */
    declare const cc: never;
    