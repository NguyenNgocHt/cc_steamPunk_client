System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Utils, HttpClient, LanguageManager, _dec, _class, _crd, ccclass, property, languageService;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  function _reportPossibleCrUseOfILanguegeService(extras) {
    _reporterNs.report("ILanguegeService", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUtils(extras) {
    _reporterNs.report("Utils", "../../../../../../framework/utils/Utils", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHttpClient(extras) {
    _reporterNs.report("HttpClient", "../../../../../../framework/network/HttpClient", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLanguageManager(extras) {
    _reporterNs.report("LanguageManager", "../../../../../../framework/languge/LanguageManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      Utils = _unresolved_2.default;
    }, function (_unresolved_3) {
      HttpClient = _unresolved_3.HttpClient;
    }, function (_unresolved_4) {
      LanguageManager = _unresolved_4.LanguageManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "90bb06mHpRNOJPcOwePlKyo", "languageService", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("languageService", languageService = (_dec = ccclass("languageService"), _dec(_class = class languageService {
        constructor() {
          this.isLoadLanguage = false;
        }

        loadingLanguage() {
          var dataDecode = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
            error: Error()
          }), Utils) : Utils).parseUrlData();
          console.log("dataDecode", dataDecode);
          this.getSetting(dataDecode, () => {
            console.log("come in get setting ok");
            this.loadLanguage(dataDecode);
          });

          if (window["onGameInitSuccess"]) {
            window["onGameInitSuccess"]();
          }
        }

        getSetting(dataDecode, callback) {
          return _asyncToGenerator(function* () {
            if (callback === void 0) {
              callback = null;
            }

            if (dataDecode) {
              var url = "" + dataDecode.server + dataDecode.subpath + "/setting";
              var data = yield (_crd && HttpClient === void 0 ? (_reportPossibleCrUseOfHttpClient({
                error: Error()
              }), HttpClient) : HttpClient).instance.post(url, dataDecode);
              console.log("data", data);

              if (data && data.status === 1) {
                callback && callback(true);
              } else {
                callback && callback(false);
              }
            }
          })();
        }

        loadLanguage(dataDecode) {
          var _this = this;

          return _asyncToGenerator(function* () {
            if (dataDecode) {
              yield new (_crd && LanguageManager === void 0 ? (_reportPossibleCrUseOfLanguageManager({
                error: Error()
              }), LanguageManager) : LanguageManager)().getLanguage2(dataDecode, (result => {
                if (result) {
                  console.log("loading language success");
                  _this.isLoadLanguage = result;
                } else {
                  setTimeout(() => {
                    _this.loadLanguage(dataDecode);
                  }, 2000);
                }
              }).bind(_this));
            }
          })();
        }

        getResultLoadLanguage() {
          return this.isLoadLanguage;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=93b47edd4dc1cc645eeb7c4a7caf0de7bd79d4db.js.map