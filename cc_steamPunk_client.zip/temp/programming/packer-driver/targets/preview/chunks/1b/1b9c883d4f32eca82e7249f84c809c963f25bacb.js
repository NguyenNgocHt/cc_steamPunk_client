System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, sys, LOCAL_STORAGE_KEY_WORD, _dec, _class, _crd, ccclass, property, PlayerInfoService;

  function _reportPossibleCrUseOfIPlayerInfoService(extras) {
    _reporterNs.report("IPlayerInfoService", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD(extras) {
    _reporterNs.report("LOCAL_STORAGE_KEY_WORD", "../../../../common/Path", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      sys = _cc.sys;
    }, function (_unresolved_2) {
      LOCAL_STORAGE_KEY_WORD = _unresolved_2.LOCAL_STORAGE_KEY_WORD;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "51c67di91xAfY12/ogK33xr", "PlayerInfoService", undefined);

      __checkObsolete__(['_decorator', 'sys']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerInfoService", PlayerInfoService = (_dec = ccclass("PlayerInfoService"), _dec(_class = class PlayerInfoService {
        handlePlayerInfo(data) {
          var playerInfo = null;
          playerInfo = {
            userName: data.userName,
            money: data.money,
            currency: data.currency
          };
          sys.localStorage.setItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).PLAYER_INFO, JSON.stringify(playerInfo));
        }

        getPlayerInfo() {
          var playerInfo = JSON.parse(sys.localStorage.getItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).PLAYER_INFO));
          return playerInfo ? playerInfo : null;
        }

        getPlayerName() {
          var playerInfo = this.getPlayerInfo();
          return playerInfo ? playerInfo.userName : null;
        }

        getCurrentMoney() {
          var playerInfo = this.getPlayerInfo();
          return playerInfo ? playerInfo.money : 0;
        }

        getCurrency() {
          var playerInfo = this.getPlayerInfo();
          return playerInfo ? playerInfo.currency : null;
        }

        updateCurrentMoney(currentMoney) {
          var playerInfo = this.getPlayerInfo();
          var newPlayerInfo = null;
          newPlayerInfo = {
            userName: playerInfo.userName,
            money: currentMoney,
            currency: playerInfo.currency
          };
          this.handlePlayerInfo(newPlayerInfo);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1b9c883d4f32eca82e7249f84c809c963f25bacb.js.map