System.register(["__unresolved_0", "cc", "cc/env", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, sys, view, DEV, EventBus, EventBusName, _dec, _class, _crd, ccclass, property, PotraitCanvasResize;

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "./EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBusName(extras) {
    _reporterNs.report("EventBusName", "./EventBus", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      sys = _cc.sys;
      view = _cc.view;
    }, function (_ccEnv) {
      DEV = _ccEnv.DEV;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
      EventBusName = _unresolved_2.EventBusName;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f1672bE4hVEFITBosd8fJW/", "PortraitCanvasResize", undefined);

      __checkObsolete__(['_decorator', 'Component', 'sys', 'view', 'log']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PotraitCanvasResize", PotraitCanvasResize = (_dec = ccclass("PotraitCanvasResize"), _dec(_class = class PotraitCanvasResize extends Component {
        constructor() {
          super(...arguments);
          this._thisOnResized = void 0;
        }

        onLoad() {
          if (!DEV && sys.isBrowser) {
            this._thisOnResized = this.onScreenResized.bind(this);
            window.addEventListener("resize", this._thisOnResized);
            this.updateCanvasAttributes();
          }

          if (!DEV && sys.isBrowser && sys.isMobile) {
            // console.warn('iOS safari browser ');
            view.on("canvas-resize", this.updateCanvasSize);
            this.updateCanvasSize();
          }
        }

        updateCanvasSize() {
          // console.warn('updateCanvasSize');
          // console.warn('iOS safari browser ');
          window.scrollTo(0, 0);
        }

        updateCanvasAttributes() {
          // const viewSize = view.getFrameSize();
          // log('===================================');
          // log(`window size original: ${window.innerWidth} - ${window.innerHeight}`);
          // log(`view.getDevicePixelRatio: ${view.getDevicePixelRatio()} `);
          // log(`window.getDevicePixelRatio: ${window.devicePixelRatio} `);
          // let ratio = 1; //window.devicePixelRatio;
          var windowWidth = window.innerWidth;
          var windowHeight = window.innerHeight; // log(`window size * ratio: ${windowWidth} - ${windowHeight}`);
          // log(`view size: ${viewSize.width} - ${viewSize.height}`);
          // log(`canvas size: ${view.getCanvasSize().width} - ${view.getCanvasSize().height}`);
          // log(`visible size: ${view.getVisibleSize().width} - ${view.getVisibleSize().height}`);
          // log(`design size: ${view.getDesignResolutionSize().width} - ${view.getDesignResolutionSize().height}`);
          // log(`sys.windowPixelResolution : ${sys.windowPixelResolution.width} - ${sys.windowPixelResolution.height}`);

          var windowRatio = windowWidth * 1.0 / windowHeight;
          var designRatio = view.getDesignResolutionSize().width * 1.0 / view.getDesignResolutionSize().height;
          var cvShadow = document.getElementById("canvas-shadow");

          if (windowRatio > designRatio) {
            if (view.getDesignResolutionSize().width == 1280) {
              designRatio = 1600.0 / 720;
            }

            var cWidth = Math.floor(designRatio * windowHeight);
            var padding = Math.floor((windowWidth - cWidth) / 2); // game.canvas?.setAttribute('width', `${cWidth}px`);
            // game.canvas?.setAttribute('height', `${windowHeight}px`);
            // game.canvas?.setAttribute('style', `width: ${cWidth}px; height: ${windowHeight}px;`);
            // const containerStyle = game.container?.style;
            // if (containerStyle) {
            //     containerStyle.paddingLeft = `${padding}px`;
            //     containerStyle.paddingRight = `${padding}px`;
            //     containerStyle.paddingTop = `0px`;
            //     containerStyle.paddingBottom = `0px`;
            // }
            // document.body.style.width = `${windowWidth}px`;
            // document.body.style.height = `${windowHeight}px`;
            // view.emit("canvas-resize");
            // view._resizeCallback && view._resizeCallback();

            if (cvShadow) {
              cvShadow.setAttribute("style", "visibility: visible;height: " + (windowHeight - 1) + "px;width: " + cWidth + "px;left: " + padding + "px;top: 0px;transform: rotate(0deg);");
            } // game.canvas?.style && (game.canvas.style.visibility = 'hidden');
            // game.canvas?.style && (game.canvas.style.visibility = 'visible');
            // director.reset();
            // game.container?.setAttribute('style', `transform: rotate(0deg); width: ${cWidth}px; height: ${windowHeight}px; margin: 0px; padding: 0px ${padding}px;`);
            // view.setDesignResolutionSize(
            //     view.getDesignResolutionSize().width,
            //     view.getDesignResolutionSize().height,
            //     ResolutionPolicy.SHOW_ALL
            // );

          } else {
            if (view.getDesignResolutionSize().width == 720) {
              designRatio = 720 / 1560.0;
            }

            var cHeight = Math.floor(windowWidth / designRatio); // game.canvas?.setAttribute('width', `${windowWidth}px`);
            // game.canvas?.setAttribute('height', `${cHeight}px`);
            // game.canvas?.setAttribute('style', `width: ${windowWidth}px; height: ${cHeight}px;`);

            var _padding = Math.floor((windowHeight - cHeight) / 2);

            if (cvShadow) {
              cvShadow.setAttribute("style", "visibility: visible;height: " + cHeight + "px;width: " + (windowWidth - 1) + "px;left: 0px;top: " + _padding + "px;transform: rotate(0deg);");
            } // game.container?.setAttribute('style', `transform: rotate(0deg); width: ${windowWidth}px; height: ${cHeight}px; margin: 0px; padding: ${padding}px 0px;`);
            // view.setCanvasSize(windowWidth, cHeight);
            // view.setDesignResolutionSize(
            //     view.getDesignResolutionSize().width,
            //     view.getDesignResolutionSize().height,
            //     ResolutionPolicy.SHOW_ALL
            // );

          }
        }

        onScreenResized() {
          this.updateCanvasAttributes();
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && EventBusName === void 0 ? (_reportPossibleCrUseOfEventBusName({
            error: Error()
          }), EventBusName) : EventBusName).RESIZE_WINDOW_EVENT, this);
        }

        onDestroy() {
          if (!DEV && sys.isBrowser) {
            window.removeEventListener("resize", this._thisOnResized);
          }

          if (!DEV && sys.isBrowser && sys.isMobile) {
            view.off("canvas-resize", this.updateCanvasSize);
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=29f95df2b3f0e4ee3f09da5eca7a5e7852f38cff.js.map