System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, log, assetManager, Prefab, AsyncTaskMgr, AudioManager, ScreenManager, Config, Path, _dec, _class, _crd, ccclass, property, mainGame_Scene;

  function _reportPossibleCrUseOfAsyncTaskMgr(extras) {
    _reporterNs.report("AsyncTaskMgr", "../../../framework/async-task/AsyncTaskMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioManager(extras) {
    _reporterNs.report("AudioManager", "../../../framework/audio/AudioManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfScreenManager(extras) {
    _reporterNs.report("ScreenManager", "../../../framework/ui/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConfig(extras) {
    _reporterNs.report("Config", "./common/Config", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPath(extras) {
    _reporterNs.report("Path", "./common/Path", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      log = _cc.log;
      assetManager = _cc.assetManager;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      AsyncTaskMgr = _unresolved_2.default;
    }, function (_unresolved_3) {
      AudioManager = _unresolved_3.AudioManager;
    }, function (_unresolved_4) {
      ScreenManager = _unresolved_4.default;
    }, function (_unresolved_5) {
      Config = _unresolved_5.Config;
    }, function (_unresolved_6) {
      Path = _unresolved_6.Path;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "0a49btJYpNP4pUtu5hEau8A", "mainGame_Scene", undefined);

      __checkObsolete__(['_decorator', 'Component', 'log', 'assetManager', 'Prefab']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("mainGame_Scene", mainGame_Scene = (_dec = ccclass("mainGame_Scene"), _dec(_class = class mainGame_Scene extends Component {
        onLoad() {
          this.registerEvent();
          log("@ mainGame_Scene: onLoad  !!!");
          var bundle = assetManager.getBundle("bundle_" + (_crd && Config === void 0 ? (_reportPossibleCrUseOfConfig({
            error: Error()
          }), Config) : Config).GAME_NAME);

          if (bundle) {
            this.node.addComponent(_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
              error: Error()
            }), ScreenManager) : ScreenManager);
            (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
              error: Error()
            }), ScreenManager) : ScreenManager).instance.assetBundle = bundle;
            (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
              error: Error()
            }), ScreenManager) : ScreenManager).instance.setupCommon();
            bundle.load((_crd && Path === void 0 ? (_reportPossibleCrUseOfPath({
              error: Error()
            }), Path) : Path).LOADING_SCREEN, Prefab, (error, prefab) => {
              if (error) {
                log("bundle.load: " + error);
              } else {
                log("load loading sucess");
                (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
                  error: Error()
                }), ScreenManager) : ScreenManager).instance.pushScreen(prefab, screen => {
                  log("pushScreen " + screen.name + " success!");
                });
              }
            });
          }
        }

        registerEvent() {}

        onDestroy() {
          (_crd && AudioManager === void 0 ? (_reportPossibleCrUseOfAudioManager({
            error: Error()
          }), AudioManager) : AudioManager).instance.destroy();
          (_crd && AsyncTaskMgr === void 0 ? (_reportPossibleCrUseOfAsyncTaskMgr({
            error: Error()
          }), AsyncTaskMgr) : AsyncTaskMgr).instance.stop();
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=2e1edf05f2945c058a311e665e90b299f22e63d5.js.map