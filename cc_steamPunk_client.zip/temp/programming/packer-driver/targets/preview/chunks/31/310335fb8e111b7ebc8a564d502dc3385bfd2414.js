System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, GameLogicController, GameInfoServiceMock, BetResultsServiceMock, EventBus, GAME_EVENT, _dec, _class, _crd, ccclass, property, MockGameLogicController;

  function _reportPossibleCrUseOfGameLogicController(extras) {
    _reporterNs.report("GameLogicController", "../service/GameLogicController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIBetResultsServiceMock(extras) {
    _reporterNs.report("IBetResultsServiceMock", "../../../../interfaces/Mock_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfbetResultMock(extras) {
    _reporterNs.report("betResultMock", "../../../../dataModel/MockConfigData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfoServiceMock(extras) {
    _reporterNs.report("GameInfoServiceMock", "../../../../mock/GameInfoServiceMock", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsServiceMock(extras) {
    _reporterNs.report("BetResultsServiceMock", "../../../../mock/BetResultsServiceMock", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameInfoService(extras) {
    _reporterNs.report("IGameInfoService", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      GameLogicController = _unresolved_2.GameLogicController;
    }, function (_unresolved_3) {
      GameInfoServiceMock = _unresolved_3.GameInfoServiceMock;
    }, function (_unresolved_4) {
      BetResultsServiceMock = _unresolved_4.BetResultsServiceMock;
    }, function (_unresolved_5) {
      EventBus = _unresolved_5.EventBus;
    }, function (_unresolved_6) {
      GAME_EVENT = _unresolved_6.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a5103+sqWJB77iZ0IezmOv1", "MockGameLogicController", undefined);

      __checkObsolete__(['_decorator']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("MockGameLogicController", MockGameLogicController = (_dec = ccclass("MockGameLogicController"), _dec(_class = class MockGameLogicController extends (_crd && GameLogicController === void 0 ? (_reportPossibleCrUseOfGameLogicController({
        error: Error()
      }), GameLogicController) : GameLogicController) {
        constructor() {
          super(...arguments);
          this.gameInfoService = null;
          this.betResultService = null;
        }

        initGameStart() {
          console.log("init start game");
          super.initGameStart();
          this.init();
        }

        init() {
          this.gameInfoService = new (_crd && GameInfoServiceMock === void 0 ? (_reportPossibleCrUseOfGameInfoServiceMock({
            error: Error()
          }), GameInfoServiceMock) : GameInfoServiceMock)();
          this.betResultService = new (_crd && BetResultsServiceMock === void 0 ? (_reportPossibleCrUseOfBetResultsServiceMock({
            error: Error()
          }), BetResultsServiceMock) : BetResultsServiceMock)();
          this.betResultService.init();
          this.gameInfoService.init();
          this.setGameInfo();
        }

        onPlaceBet(data) {
          var betResults = this.getBetResults(data);
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_BET_RESULT_DATA_TO_GAME_CONTROLLER, betResults);
        }

        setGameInfo() {
          console.log("set game info");
          var gameInfo = this.getGameInfo();
          console.log("game info", gameInfo);
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_GAME_INFO_DATA_TO_GAME_CONTROLLER, gameInfo);
        }

        getBetResults(data) {
          var betResult = this.betResultService.getBetResults(data);
          return betResult;
        }

        getGameInfo() {
          var gameInfo = this.gameInfoService.getGameInfo();
          return gameInfo;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=310335fb8e111b7ebc8a564d502dc3385bfd2414.js.map