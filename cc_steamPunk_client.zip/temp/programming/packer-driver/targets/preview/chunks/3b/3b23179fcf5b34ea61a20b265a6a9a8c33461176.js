System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, BaseSingleton, BNotifyType, LogUtil, _dec, _class, _crd, ccclass, property, NotifyUtil;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  function _reportPossibleCrUseOfBaseSingleton(extras) {
    _reporterNs.report("BaseSingleton", "../common/BaseSingleton", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBNotifyType(extras) {
    _reporterNs.report("BNotifyType", "../../games/steamPunk_client/script/common/Enum", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLogUtil(extras) {
    _reporterNs.report("LogUtil", "./LogUtil", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      BaseSingleton = _unresolved_2.default;
    }, function (_unresolved_3) {
      BNotifyType = _unresolved_3.BNotifyType;
    }, function (_unresolved_4) {
      LogUtil = _unresolved_4.LogUtil;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "897a6pFsRlDKaI2FqVc9pOQ", "NotifyUtil", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("NotifyUtil", NotifyUtil = (_dec = ccclass("NotifyUtil"), _dec(_class = class NotifyUtil extends (_crd && BaseSingleton === void 0 ? (_reportPossibleCrUseOfBaseSingleton({
        error: Error()
      }), BaseSingleton) : BaseSingleton) {
        constructor() {
          super(); //  HLNotifyType , observerMap

          this.observerMap = new Map();

          for (var key in _crd && BNotifyType === void 0 ? (_reportPossibleCrUseOfBNotifyType({
            error: Error()
          }), BNotifyType) : BNotifyType) {
            if (Object.prototype.hasOwnProperty.call(_crd && BNotifyType === void 0 ? (_reportPossibleCrUseOfBNotifyType({
              error: Error()
            }), BNotifyType) : BNotifyType, key)) {
              //ts-expect-error
              var notifyName = (_crd && BNotifyType === void 0 ? (_reportPossibleCrUseOfBNotifyType({
                error: Error()
              }), BNotifyType) : BNotifyType)[key];

              if (notifyName !== key) {
                throw new Error("Definition Error " + key + " -> " + notifyName);
              }

              this.observerMap.set(notifyName, []);
            }
          }
        }

        setup(notifyType) {
          var _this = this;

          return _asyncToGenerator(function* () {
            if (!notifyType) return;
            (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
              error: Error()
            }), LogUtil) : LogUtil).log("NotifyUtil setup");

            for (var key in notifyType) {
              if (Object.prototype.hasOwnProperty.call(notifyType, key)) {
                //ts-expect-error
                var notifyName = notifyType[key];

                if (notifyName !== key) {
                  throw new Error("Definition Error " + key + " -> " + notifyName);
                }

                _this.observerMap.set(notifyName, []);
              }
            }
          })();
        }
        /**
         *
         *
         * @param notifyType
         * @param notifyFunc
         * @param target
         * @memberof NotifyUtil
         */


        on(notifyType, notifyFunc, target) {
          this.observerMap.get(notifyType).push({
            func: notifyFunc,
            target: target
          });
        }
        /**
         *
         *
         * @param notifyType
         * @param notifyFunc
         * @param target
         * @memberof NotifyUtil
         */


        off(notifyType, notifyFunc, target) {
          var observers = this.observerMap.get(notifyType);
          var index = observers.findIndex(o => o.func === notifyFunc && o.target === target);
          index >= 0 && observers.splice(index, 1);
        }
        /**
         *
         *
         * @template T
         * @param notifyType
         * @param [userData=null]
         * @memberof NotifyUtil
         */


        emit(notifyType, userData) {
          if (userData === void 0) {
            userData = null;
          }

          if (this.observerMap.get(notifyType)) {
            this.observerMap.get(notifyType).forEach(obs => {
              if (obs.target) {
                obs.func.call(obs.target, userData, notifyType);
              } else {
                obs.func(userData, notifyType);
              }
            });
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=3b23179fcf5b34ea61a20b265a6a9a8c33461176.js.map