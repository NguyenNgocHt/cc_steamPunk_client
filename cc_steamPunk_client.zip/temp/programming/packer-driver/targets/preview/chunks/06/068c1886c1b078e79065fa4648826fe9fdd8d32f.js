System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, tween, gamePlayController, EventBus, GAME_EVENT, PoolController, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, DataController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfgamePlayController(extras) {
    _reporterNs.report("gamePlayController", "./GamePlayController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPoolController(extras) {
    _reporterNs.report("PoolController", "../../../../common/PoolController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPendingData(extras) {
    _reporterNs.report("PendingData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfgameData(extras) {
    _reporterNs.report("gameData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      tween = _cc.tween;
    }, function (_unresolved_2) {
      gamePlayController = _unresolved_2.gamePlayController;
    }, function (_unresolved_3) {
      EventBus = _unresolved_3.EventBus;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }, function (_unresolved_5) {
      PoolController = _unresolved_5.PoolController;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "aacd5O3FblFiayh1AraPaVe", "DataController", undefined);

      __checkObsolete__(['_decorator', 'tween']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("DataController", DataController = (_dec = ccclass("DataController"), _dec2 = property(_crd && PoolController === void 0 ? (_reportPossibleCrUseOfPoolController({
        error: Error()
      }), PoolController) : PoolController), _dec(_class = (_class2 = class DataController extends (_crd && gamePlayController === void 0 ? (_reportPossibleCrUseOfgamePlayController({
        error: Error()
      }), gamePlayController) : gamePlayController) {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "poolControl", _descriptor, this);

          this.isFreeSpin = false;
          this.betResultData = null;
          this.pendingData = null;
          this.gameData = null;
          this.multiplierValue = 0;
          this.isShowFreeSpinAnim = false;
          this.freeSpinValue = 0;
          this.timeDelayOnBetBtn = 0;
          this.selectedNumber = 0;
          this.isAutoPlay = false;
        }

        // game: IGameLogic;
        start() {
          this.init();
          this.registerEvent();
          this.initPoolControl();
          this.sendPoolModel();
        }

        initPoolControl() {
          this.poolControl.init();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).END_SHOW_LANDING, this.goToGameMain.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).BET_LAYER_TO_UP_END, this.initStartGame.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_BET_RESULT_DATA, this.setFreeSpinStatus.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).WIN_GAME, this.handleWinGameData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).UPDATE_MONEY_PLAYER, this.updateMoneyPlayer.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).BET_DATA, this.placeBet.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).PENDING_DATA, this.checkPendingData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).LOSE_GAME, this.handleLoseGameData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_SELECTED_NUMBER_TO_GAME_CONTROLLER, this.setAutoPlayGame.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ERASE_SELECTED_NUMBER, this.stopAutoPlay.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_TUBO_BUTTON, this.setGreenOverlapActive.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).END_SHOW_LANDING, this.goToGameMain.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).BET_LAYER_TO_UP_END, this.initStartGame.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_BET_RESULT_DATA, this.setFreeSpinStatus.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).WIN_GAME, this.handleWinGameData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).UPDATE_MONEY_PLAYER, this.updateMoneyPlayer.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).BET_DATA, this.placeBet.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).PENDING_DATA, this.checkPendingData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).LOSE_GAME, this.handleLoseGameData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_SELECTED_NUMBER_TO_GAME_CONTROLLER, this.setAutoPlayGame.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ERASE_SELECTED_NUMBER, this.stopAutoPlay.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_TUBO_BUTTON, this.setGreenOverlapActive.bind(this));
        }

        sendPoolModel() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_POOL_MODEL, this.poolControl);
        }

        goToGameMain() {
          this.gameLayerControl.metalgateToUp();
          this.playScreenView.betGroupToUp();
        }

        initStartGame() {
          this.gameLayerControl.startGame();
          this.betControl.onStartGame();
          this.checkFreeSpin();
        }

        setFreeSpinStatus(data) {
          this.betInfoData = data;
          this.betResultData = data.result;

          if (this.betResultData.freeSpins > 0) {
            this.freeSpinValue = this.betResultData.freeSpins;

            if (!this.isFreeSpin) {
              this.isFreeSpin = true;
              this.isShowFreeSpinAnim = true;
              this.timeDelayOnBetBtn = 3;
            }
          } else {
            this.isFreeSpin = false;
          }
        }

        handleWinGameData(paylineList, timeScale) {
          this.betResulService.handleBetResultData(this.betInfoData);
          var betResult = this.betResulService.getBetResult();
          var payLines = paylineList;
          this.multiplierValue = this.betResulService.getMultiplierValue();
          var bonusGroupDestinationNode = this.PlayerControl.getBonusGroupDestinationNode();
          this.gameLayerControl.showWinGameBonus(betResult.payout, this.multiplierValue, bonusGroupDestinationNode);
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SHOW_EFFECT_WIN_GAME, payLines, timeScale);
        }

        handleLoseGameData() {
          this.betResulService.handleBetResultData(this.betInfoData);
          this.multiplierValue = this.betResulService.getMultiplierValue();
          this.updateMoneyPlayer();
        }

        updateMoneyPlayer() {
          var balance = this.playerInfoService.getCurrentMoney();

          if (this.betResultData.payout > 0) {
            balance = balance + this.betResultData.payout;
          }

          this.PlayerControl.updateMoneyEndRound(balance);
          this.PlayerControl.checkIconValue(this.multiplierValue);
          this.betControl.setBetBtnToOriginalState();
          this.scheduleOnce(function () {
            this.checkFreeSpin();

            if (this.selectedNumber != 0 && !this.isFreeSpin) {
              this.checkAutoPlay();
            }
          }, 0.1);
        }

        checkPendingData(pendingData) {
          this.pendingData = pendingData;

          if (pendingData.freeSpins > 0) {
            this.freeSpinValue = pendingData.freeSpins;

            if (!this.isFreeSpin) {
              this.isFreeSpin = true;
              this.isShowFreeSpinAnim = true;
              this.timeDelayOnBetBtn = 3;
            }
          } else {
            this.isFreeSpin = false;
          }
        }

        checkFreeSpin() {
          if (!this.isFreeSpin) {
            return;
          } else {
            tween(this.node).delay(this.timeDelayOnBetBtn).call(() => {
              if (this.freeSpinValue == 1) {
                this.freeSpinValue = 0;
              }

              this.sendBetFreeSpin();
              this.setOnClickBet();
              this.showFreeSpinValue();
              this.timeDelayOnBetBtn = 0.5;
            }).start();
            this.showFreeSpinAnim();
          }
        }

        sendBetFreeSpin() {
          var dataBet = {
            info: {
              stake: 0
            }
          };
          this.placeBet(dataBet);
        }

        setOnClickBet() {
          this.betControl.changeBetbtnSatus();
        }

        setOnClickBetBtn() {
          this.betControl.onClickBetBtn();
        }

        showFreeSpinValue() {
          this.betControl.showFreeSpinValue(this.freeSpinValue);
        }

        showFreeSpinAnim() {
          if (!this.isShowFreeSpinAnim) {
            return;
          } else {
            this.gameLayerControl.showFreeSpinAnim();
            this.betControl.showTextWinFreeSpin();
            setTimeout(() => {
              this.showFreeSpinValue();
            }, 2000);
            this.isShowFreeSpinAnim = false;
          }
        }

        placeBet(data) {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_PLACE_BET, data);
        }

        setAutoPlayGame(selectedNumber) {
          this.selectedNumber = selectedNumber;
          this.isAutoPlay = true;
          this.setOnClickBetBtn();
          this.betControl.onAutoPlay();
        }

        checkAutoPlay() {
          this.downSelectedNUmber();

          if (this.isAutoPlay) {
            this.setOnClickBetBtn();
          } else {
            return;
          }
        }

        downSelectedNUmber() {
          this.selectedNumber -= 1;

          if (this.selectedNumber == 0) {
            this.isAutoPlay = false;
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).END_AUTO_PLAY);
            this.betControl.offAutoPlay();
          }
        }

        stopAutoPlay() {
          this.selectedNumber = 0;
          this.isAutoPlay = false;
          this.betControl.offAutoPlay();
        }

        setGreenOverlapActive(valueIndex) {
          if (valueIndex == 0) {
            this.gameLayerControl.setGreenOverlapActive(false);
          } else if (valueIndex == 1) {
            this.gameLayerControl.setGreenOverlapActive(true);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "poolControl", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=068c1886c1b078e79065fa4648826fe9fdd8d32f.js.map