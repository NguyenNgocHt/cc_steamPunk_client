System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Vec3, SpriteFrame, Sprite, tween, _decorator, Component, Node, sp, EventBus, GAME_EVENT, UITransform, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, SymbolView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Vec3 = _cc.Vec3;
      SpriteFrame = _cc.SpriteFrame;
      Sprite = _cc.Sprite;
      tween = _cc.tween;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      sp = _cc.sp;
      UITransform = _cc.UITransform;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
    }, function (_unresolved_3) {
      GAME_EVENT = _unresolved_3.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "158276chqhEirqWSX/OESbn", "SymbolView", undefined);

      __checkObsolete__(['Vec3']);

      __checkObsolete__(['SpriteFrame']);

      __checkObsolete__(['Sprite']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'sp']);

      __checkObsolete__(['Vec2']);

      __checkObsolete__(['Size']);

      __checkObsolete__(['UITransform']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SymbolView", SymbolView = (_dec = ccclass("SymbolView"), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(sp.SkeletonData), _dec5 = property(SpriteFrame), _dec(_class = (_class2 = class SymbolView extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "symbolImage", _descriptor, this);

          _initializerDefineProperty(this, "symbolAnim", _descriptor2, this);

          _initializerDefineProperty(this, "AnimJsonDataList", _descriptor3, this);

          _initializerDefineProperty(this, "symbolImageList", _descriptor4, this);

          this.nodeScaleList = [];
          this.symbolPosList = [];
          this.symbolSizeList = [];
          this.rowIndex = 0;
          this.columnIndex = 0;
          this.distanceRow = 240;
          this.positionYTop = 1815;
          this.positionYBottom = -825;
          this.symbolIndex = 0;
          this.isShowAnim = false;
          this.timeDelayRow1 = 0.1;
          this.timeDelayRow2 = 0.3;
          this.timeDelayRow3 = 0.5;
        }

        start() {
          this.setInitState();
          var skeleton = this.symbolAnim.getComponent(sp.Skeleton);

          if (skeleton) {
            skeleton.setCompleteListener(() => {
              skeleton.clearTracks();
              skeleton.setToSetupPose();
              this.symbolAnim.active = false;
              this.isShowAnim = false;
            });
          }
        }

        setInitState() {
          this.symbolImage.active = true;
          this.symbolAnim.active = false;
        }

        setRowIndex(row) {
          this.rowIndex = row;
        }

        getRowIndex() {
          return this.rowIndex;
        }

        setColumnIndex(column) {
          this.columnIndex = column;
        }

        getColumnIndex() {
          return this.columnIndex;
        }

        setSymbolIndex(symbolIndex) {
          this.symbolIndex = symbolIndex;
        }

        setSymbolPosList(symbolPosList) {
          this.symbolPosList = symbolPosList;
        }

        setSymbolSizeList(symbolSizeList) {
          this.symbolSizeList = symbolSizeList;
        }

        setNodeScaleList(nodeScaleList) {
          this.nodeScaleList = nodeScaleList;
        }

        setAnimStatus(status) {
          this.isShowAnim = status;
        }

        spinning(loopIndex, timeScale) {
          var timeMove_startSpinning = 1 / timeScale;
          var timeMove_spinning = 0.06 / timeScale;
          var timeMove_stopSpinning = 0.5 / timeScale;
          var timeDelay = 0;
          var downIndex = -1;
          var posStart = this.node.getWorldPosition();

          if (this.columnIndex == 0) {
            timeDelay = this.timeDelayRow1 / timeScale;
          } else if (this.columnIndex == 1) {
            timeDelay = this.timeDelayRow2 / timeScale;
          } else if (this.columnIndex == 2) {
            timeDelay = this.timeDelayRow3 / timeScale;
          }

          var action_startSpinning = () => {
            tween(this.node).by(timeMove_startSpinning, {
              worldPosition: new Vec3(0, downIndex * this.distanceRow, 0)
            }, {
              easing: "backInOut"
            }).start();
          };

          var action_spinning = () => {
            tween(this.node).by(timeMove_spinning, {
              worldPosition: new Vec3(0, downIndex * this.distanceRow, 0)
            }).call(() => {
              var currentPos = this.node.getWorldPosition();

              if (currentPos.y <= this.positionYBottom) {
                this.node.setWorldPosition(posStart.x, this.positionYTop, 0);

                if (this.symbolIndex != parseInt(this.node.name)) {
                  this.changeSpriteFrameAndSkeletonData();
                }
              }
            }).union().repeat(loopIndex).start();
          };

          var action_stopSpining = () => {
            tween(this.node).by(timeMove_stopSpinning, {
              worldPosition: new Vec3(0, downIndex * this.distanceRow, 0)
            }, {
              easing: "elasticOut"
            }).call(() => {
              var currentPos = this.node.getWorldPosition();

              if (currentPos.y <= this.positionYBottom) {
                this.node.setWorldPosition(posStart.x, this.positionYTop, 0);
              }
            }).start();
          };

          tween(this.node).delay(timeDelay).call(action_startSpinning).delay(0.5 / timeScale).call(action_spinning).delay(0.4 / timeScale).call(() => {
            if (this.rowIndex == 11 && this.columnIndex == 2) {
              (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
                error: Error()
              }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
                error: Error()
              }), GAME_EVENT) : GAME_EVENT).ON_SPIN_EFFECT_VER2, timeScale);
            }
          }).delay(0.89 / timeScale).call(action_stopSpining).delay(0.2 / timeScale).call(() => {
            if (this.rowIndex == 11 && this.columnIndex == 2) {
              (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
                error: Error()
              }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
                error: Error()
              }), GAME_EVENT) : GAME_EVENT).SPINING_STOP, this.columnIndex, timeScale);
            } else if (this.rowIndex == 11 && this.columnIndex == 1) {
              (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
                error: Error()
              }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
                error: Error()
              }), GAME_EVENT) : GAME_EVENT).SPINING_STOP, this.columnIndex, timeScale);
            } else if (this.rowIndex == 11 && this.columnIndex == 0) {
              (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
                error: Error()
              }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
                error: Error()
              }), GAME_EVENT) : GAME_EVENT).SPINING_STOP, this.columnIndex, timeScale);
            }
          }).start();
        }

        changeSpriteFrameAndSkeletonData() {
          this.changeSymbolImage();
          this.changeSkeletonData();
        }

        changeSymbolImage() {
          var symbolPos = this.symbolPosList[this.symbolIndex - 1];
          var symbolUiTransform = this.symbolImage.getComponent(UITransform);
          var spriteSymbol = this.symbolImage.getComponent(Sprite);
          spriteSymbol.spriteFrame = this.symbolImageList[this.symbolIndex - 1];
          this.symbolImage.setPosition(symbolPos.x, symbolPos.y, 0);
          symbolUiTransform.setContentSize(this.symbolSizeList[this.symbolIndex - 1]);
        }

        changeSkeletonData() {
          this.symbolAnim.active = true;
          var skeletonNode = this.symbolAnim.getComponent(sp.Skeleton);
          skeletonNode.skeletonData = this.AnimJsonDataList[this.symbolIndex - 1];

          if (this.symbolIndex == 6) {
            skeletonNode.setAnimation(0, "Girl-Nice", true);
          } else {
            skeletonNode.setAnimation(0, "animtion0", true);
          }

          this.node.name = this.symbolIndex.toString();
          var symbolScale = this.nodeScaleList[this.symbolIndex - 1];
          this.symbolAnim.setScale(symbolScale, symbolScale, 0);
          this.symbolAnim.active = false;
        }

        showAnimWin() {
          if (this.isShowAnim) {
            this.symbolAnim.active = true;
            var skeleton = this.symbolAnim.getComponent(sp.Skeleton);

            if (this.symbolIndex == 6) {
              skeleton.setAnimation(0, "Girl-Nice", false);
              skeleton.timeScale = 0.8;
            } else {
              skeleton.setAnimation(0, "animtion0", false);
              skeleton.timeScale = 1;
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "symbolImage", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "symbolAnim", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "AnimJsonDataList", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "symbolImageList", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=19f50f8c6f1945aec83df99df4c8f07986424e3b.js.map