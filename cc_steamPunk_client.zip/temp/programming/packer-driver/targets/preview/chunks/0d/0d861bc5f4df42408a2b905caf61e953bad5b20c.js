System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6", "__unresolved_7", "__unresolved_8", "__unresolved_9", "__unresolved_10", "__unresolved_11", "__unresolved_12", "__unresolved_13", "__unresolved_14", "__unresolved_15", "__unresolved_16"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, BaseScreen, Utils, GAME_EVENT, PlayerController, GameInfo, PlayerInfo, EventBus, landingController, PlayScreenView, BetController, BetResultService, GameLayerController, GameData, HistoryService, PlayerInfoService, GameLogicController, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, property, gamePlayController;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "./../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPendingData(extras) {
    _reporterNs.report("PendingData", "./../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBaseScreen(extras) {
    _reporterNs.report("BaseScreen", "../../../../../../../framework/ui/BaseScreen", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUtils(extras) {
    _reporterNs.report("Utils", "../../../../../../../framework/utils/Utils", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerController(extras) {
    _reporterNs.report("PlayerController", "../../player/controller/PlayerController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfo(extras) {
    _reporterNs.report("GameInfo", "../../../../common/GameInfo", _context.meta, extras);
  }

  function _reportPossibleCrUseOfplayerInfo(extras) {
    _reporterNs.report("playerInfo", "../../../../dataModel/PlayerDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerInfo(extras) {
    _reporterNs.report("PlayerInfo", "../../../../common/PlayerInfo", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameData(extras) {
    _reporterNs.report("IGameData", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameInfo(extras) {
    _reporterNs.report("IGameInfo", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPLayerInfo(extras) {
    _reporterNs.report("IPLayerInfo", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOflandingController(extras) {
    _reporterNs.report("landingController", "../../landing/controller/LandingController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayScreenView(extras) {
    _reporterNs.report("PlayScreenView", "../view/PlayScreenView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetController(extras) {
    _reporterNs.report("BetController", "../../bets/controller/BetController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetData(extras) {
    _reporterNs.report("BetData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIBetResultService(extras) {
    _reporterNs.report("IBetResultService", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameLogicController(extras) {
    _reporterNs.report("IGameLogicController", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIHistoryService(extras) {
    _reporterNs.report("IHistoryService", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPlayerInfoService(extras) {
    _reporterNs.report("IPlayerInfoService", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultService(extras) {
    _reporterNs.report("BetResultService", "../service/BetResultService", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameLayerController(extras) {
    _reporterNs.report("GameLayerController", "../../mainLayer/controller/GameLayerController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfISocketIOClient(extras) {
    _reporterNs.report("ISocketIOClient", "../../../../interfaces/Mock_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameData(extras) {
    _reporterNs.report("GameData", "../../../../common/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHistoryService(extras) {
    _reporterNs.report("HistoryService", "../service/HistoryService", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerInfoService(extras) {
    _reporterNs.report("PlayerInfoService", "../service/PlayerInfoService", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameLogicController(extras) {
    _reporterNs.report("GameLogicController", "./GameLogicController", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      BaseScreen = _unresolved_2.default;
    }, function (_unresolved_3) {
      Utils = _unresolved_3.default;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }, function (_unresolved_5) {
      PlayerController = _unresolved_5.PlayerController;
    }, function (_unresolved_6) {
      GameInfo = _unresolved_6.default;
    }, function (_unresolved_7) {
      PlayerInfo = _unresolved_7.PlayerInfo;
    }, function (_unresolved_8) {
      EventBus = _unresolved_8.EventBus;
    }, function (_unresolved_9) {
      landingController = _unresolved_9.landingController;
    }, function (_unresolved_10) {
      PlayScreenView = _unresolved_10.PlayScreenView;
    }, function (_unresolved_11) {
      BetController = _unresolved_11.BetController;
    }, function (_unresolved_12) {
      BetResultService = _unresolved_12.BetResultService;
    }, function (_unresolved_13) {
      GameLayerController = _unresolved_13.GameLayerController;
    }, function (_unresolved_14) {
      GameData = _unresolved_14.GameData;
    }, function (_unresolved_15) {
      HistoryService = _unresolved_15.HistoryService;
    }, function (_unresolved_16) {
      PlayerInfoService = _unresolved_16.PlayerInfoService;
    }, function (_unresolved_17) {
      GameLogicController = _unresolved_17.GameLogicController;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "44309o0mrxLzZxSKOYNq3EW", "GamePlayController", undefined);

      __checkObsolete__(['_decorator']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("gamePlayController", gamePlayController = (_dec = ccclass("gamePlayController"), _dec2 = property(_crd && GameLayerController === void 0 ? (_reportPossibleCrUseOfGameLayerController({
        error: Error()
      }), GameLayerController) : GameLayerController), _dec3 = property(_crd && PlayerController === void 0 ? (_reportPossibleCrUseOfPlayerController({
        error: Error()
      }), PlayerController) : PlayerController), _dec4 = property(_crd && landingController === void 0 ? (_reportPossibleCrUseOflandingController({
        error: Error()
      }), landingController) : landingController), _dec5 = property(_crd && BetController === void 0 ? (_reportPossibleCrUseOfBetController({
        error: Error()
      }), BetController) : BetController), _dec6 = property(_crd && PlayScreenView === void 0 ? (_reportPossibleCrUseOfPlayScreenView({
        error: Error()
      }), PlayScreenView) : PlayScreenView), _dec(_class = (_class2 = class gamePlayController extends (_crd && BaseScreen === void 0 ? (_reportPossibleCrUseOfBaseScreen({
        error: Error()
      }), BaseScreen) : BaseScreen) {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "gameLayerControl", _descriptor, this);

          _initializerDefineProperty(this, "PlayerControl", _descriptor2, this);

          _initializerDefineProperty(this, "landingGroup", _descriptor3, this);

          _initializerDefineProperty(this, "betControl", _descriptor4, this);

          _initializerDefineProperty(this, "playScreenView", _descriptor5, this);

          this.gameInfoData = null;
          this.playerInfoData = null;
          this._playerInfo = null;
          this._gameInfo = null;
          this._gameData = null;
          this.betResulService = null;
          this.historyService = null;
          this.playerInfoService = null;
          this.betInfoData = null;
          this._socketIOInstance = null;
          this.GameLogicController = null;
          this.dataGame = null;
        }

        onLoad() {}

        start() {
          this.registerEventGame();
          this.init();
          this.setDataDecode();
          this.registerPlayerInfo();
          this.registerGameInfo();
          this.registerGameData();
          this.registerHistorySevice();
          this.initGameLogicController();
          this.requestData();
        }

        init() {
          this._playerInfo = new (_crd && PlayerInfo === void 0 ? (_reportPossibleCrUseOfPlayerInfo({
            error: Error()
          }), PlayerInfo) : PlayerInfo)();
          this._gameInfo = new (_crd && GameInfo === void 0 ? (_reportPossibleCrUseOfGameInfo({
            error: Error()
          }), GameInfo) : GameInfo)();
          this._gameData = new (_crd && GameData === void 0 ? (_reportPossibleCrUseOfGameData({
            error: Error()
          }), GameData) : GameData)();
          this.playerInfoService = new (_crd && PlayerInfoService === void 0 ? (_reportPossibleCrUseOfPlayerInfoService({
            error: Error()
          }), PlayerInfoService) : PlayerInfoService)();
          this.betResulService = new (_crd && BetResultService === void 0 ? (_reportPossibleCrUseOfBetResultService({
            error: Error()
          }), BetResultService) : BetResultService)();
          this.historyService = new (_crd && HistoryService === void 0 ? (_reportPossibleCrUseOfHistoryService({
            error: Error()
          }), HistoryService) : HistoryService)();
          this.GameLogicController = new (_crd && GameLogicController === void 0 ? (_reportPossibleCrUseOfGameLogicController({
            error: Error()
          }), GameLogicController) : GameLogicController)(); // this.GameLogicController = new MockGameLogicController();
        }

        registerPlayerInfo() {
          this._playerInfo.init();
        }

        registerGameInfo() {
          this._gameInfo.init();
        }

        registerGameData() {
          this._gameData.init();
        }

        registerHistorySevice() {
          this.historyService.initGameData();
        }

        initGameLogicController() {
          this.GameLogicController.initGameStart();
        }

        setDataDecode() {
          this.landingGroup.node.active = true;
          var dataDecode = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
            error: Error()
          }), Utils) : Utils).parseUrlData();
          console.log("data decode", dataDecode);

          if (dataDecode) {
            this.dataGame = Object.assign(dataDecode);
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).SEND_GAME_DATA, this.dataGame);
          }
        }

        registerEventGame() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_BET_RESULT_DATA_TO_GAME_CONTROLLER, this.placeBetResponseHandle.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_GAME_INFO_DATA_TO_GAME_CONTROLLER, this.setGameInfo.bind(this));
        }

        placeBetResponseHandle(msg) {
          var betData = null;
          betData = msg;
          this.betInfoData = betData;
          var betResultData = betData.result;
          this.betResulService.handleBetResultData(betData);
          this.gameLayerControl.handleBetResult(betResultData);
          this.PlayerControl.minusMoneyBet(betResultData.stake);
          this.betControl.changeBetbtnSatus();
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_BET_RESULT_DATA, betData);
          this.requestData();
        }

        requestData() {
          var _this = this;

          return _asyncToGenerator(function* () {
            _this.historyService.getHistory(_this.dataGame, data => {
              _this.betControl.showHistoryContent(data);
            });
          })();
        }

        setGameInfo(data) {
          console.log("game data", data);
          this.gameInfoData = data;
          var pendingData = this.gameInfoData.pending;

          if (pendingData.freeSpins > 0) {
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).PENDING_DATA, pendingData);
          }

          console.log(pendingData);
          this.playerInfoData = {
            userName: data.username,
            money: data.balance,
            currency: data.currency
          };
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_TO_PLAYER_INFO, this.playerInfoData);
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_TO_GAME_INFO, this.gameInfoData);
          this.PlayerControl.setPlayerInfo(this.playerInfoData);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gameLayerControl", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "PlayerControl", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "landingGroup", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "betControl", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "playScreenView", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0d861bc5f4df42408a2b905caf61e953bad5b20c.js.map