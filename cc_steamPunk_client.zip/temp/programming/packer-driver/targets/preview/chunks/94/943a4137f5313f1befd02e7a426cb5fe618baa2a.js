System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, tween, Vec3, CCInteger, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, SpiningAnim;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfISpiningAnim(extras) {
    _reporterNs.report("ISpiningAnim", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
      CCInteger = _cc.CCInteger;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "2747db8tjpMJoF6JenJjRpx", "SpiningAnim", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Tween', 'labelAssembler', 'Label', 'tween', 'Vec3']);

      __checkObsolete__(['CCInteger']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SpiningAnim", SpiningAnim = (_dec = ccclass("SpiningAnim"), _dec2 = property(CCInteger), _dec(_class = (_class2 = class SpiningAnim extends Component {
        constructor() {
          super(...arguments);
          this.tweenSpin = void 0;

          _initializerDefineProperty(this, "timeLoopSpinning", _descriptor, this);
        }

        onLoad() {
          this.initSpinningGear();
        }

        initSpinningGear() {
          var moving = tween(this.node).by(this.timeLoopSpinning, {
            eulerAngles: new Vec3(0, 0, -360)
          }).repeatForever();
          this.tweenSpin = tween(this.node).then(moving);
          console.log("init tween stop", this.tweenSpin);
        }

        spinningStop() {
          console.log("tween stop", this.tweenSpin);
          this.tweenSpin.stop();
        }

        spinningStart() {
          this.scheduleOnce(function () {
            this.tweenSpin.start();
          }, 0.1);
        }

        changeTimeLoopSpinning(newTimeLoop) {
          this.timeLoopSpinning = newTimeLoop;
          this.initSpinningGear();
          this.spinningStart();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "timeLoopSpinning", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=943a4137f5313f1befd02e7a426cb5fe618baa2a.js.map