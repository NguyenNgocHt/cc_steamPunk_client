System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, SymbolView, Vec3, Vec2, Size, tween, MAP_CONVERTED_ROW, EventBus, GAME_EVENT, CCFloat, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, SymbolGroupController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfIPoolController(extras) {
    _reporterNs.report("IPoolController", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPoolController(extras) {
    _reporterNs.report("PoolController", "../../../../common/PoolController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSymbolView(extras) {
    _reporterNs.report("SymbolView", "../view/SymbolView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfMAP_CONVERTED_ROW(extras) {
    _reporterNs.report("MAP_CONVERTED_ROW", "../../../../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
      Vec2 = _cc.Vec2;
      Size = _cc.Size;
      tween = _cc.tween;
      CCFloat = _cc.CCFloat;
    }, function (_unresolved_2) {
      SymbolView = _unresolved_2.SymbolView;
    }, function (_unresolved_3) {
      MAP_CONVERTED_ROW = _unresolved_3.MAP_CONVERTED_ROW;
    }, function (_unresolved_4) {
      EventBus = _unresolved_4.EventBus;
    }, function (_unresolved_5) {
      GAME_EVENT = _unresolved_5.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8c6d5eawlZAqZ9fa+tG9e74", "SymbolGroupController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['Vec3']);

      __checkObsolete__(['Vec2']);

      __checkObsolete__(['Size']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['CCFloat']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SymbolGroupController", SymbolGroupController = (_dec = ccclass("SymbolGroupController"), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Vec3), _dec5 = property(CCFloat), _dec6 = property(Vec2), _dec7 = property(Size), _dec(_class = (_class2 = class SymbolGroupController extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "symbolGroup", _descriptor, this);

          _initializerDefineProperty(this, "posStart", _descriptor2, this);

          _initializerDefineProperty(this, "positionStart", _descriptor3, this);

          _initializerDefineProperty(this, "symbolScaleList", _descriptor4, this);

          _initializerDefineProperty(this, "symbolPos", _descriptor5, this);

          _initializerDefineProperty(this, "symbolSize", _descriptor6, this);

          this.distanceColumn = 300;
          this.distanceRow = 240;
          this._poolControl = null;
          this._symbolIndexList = [];
          this._symbolNodeList = null;
          this.row = 12;
          this.column = 3;
        }

        initSlotGroup(symbolIndexList, poolControl) {
          if (this.symbolGroup.children) {
            this.symbolGroup.removeAllChildren();
          }

          this._symbolIndexList = [];
          this._symbolNodeList = [];
          this._poolControl = poolControl;

          for (var i = 0; i < this.row; i++) {
            var row = [];

            for (var j = 0; j < this.column; j++) {
              var k = this.column * i + j;
              row.push(symbolIndexList[i][j]);
              var symbolNode = null;
              symbolNode = this._poolControl.getSymbolNode(symbolIndexList[i][j]);

              if (symbolNode) {
                symbolNode.active = true;
                this.symbolGroup.addChild(symbolNode);
                symbolNode.setWorldPosition(this.positionStart.x + j * this.distanceColumn, this.positionStart.y - i * this.distanceRow, 0);
                var symbolView = symbolNode.getComponent(_crd && SymbolView === void 0 ? (_reportPossibleCrUseOfSymbolView({
                  error: Error()
                }), SymbolView) : SymbolView);

                if (symbolView) {
                  this.initSymbolView(symbolView, i, j, symbolIndexList);
                }

                this._symbolNodeList.push(symbolNode);
              }
            }

            this._symbolIndexList.push(row);
          }
        }

        initSymbolView(symbolView, row, collumn, symbolIndexList) {
          symbolView.setRowIndex(row);
          symbolView.setColumnIndex(collumn);
          symbolView.setSymbolIndex(symbolIndexList[row][collumn]);
          symbolView.setNodeScaleList(this.symbolScaleList);
          symbolView.setSymbolPosList(this.symbolPos);
          symbolView.setSymbolSizeList(this.symbolSize);
        }

        getSymbolNodeList() {
          return this._symbolNodeList;
        }

        changeSymbolsIndex(newSymbolIndexlist) {
          for (var i = 0; i < this.row; i++) {
            for (var j = 0; j < this.column; j++) {
              var k = this.column * i + j;

              var symbolView = this._symbolNodeList[k].getComponent(_crd && SymbolView === void 0 ? (_reportPossibleCrUseOfSymbolView({
                error: Error()
              }), SymbolView) : SymbolView);

              if (symbolView) {
                symbolView.setSymbolIndex(newSymbolIndexlist[i][j]);
              }
            }
          }
        }

        updateResultsPaylines(paylineCv) {
          var paylineConvert = paylineCv;

          for (var i = 0; i < this.row; i++) {
            for (var j = 0; j < this.column; j++) {
              var k = this.column * i + j;

              var symbolView = this._symbolNodeList[k].getComponent(_crd && SymbolView === void 0 ? (_reportPossibleCrUseOfSymbolView({
                error: Error()
              }), SymbolView) : SymbolView);

              if (symbolView) {
                if (i >= 3 && i <= 5) {
                  if (paylineConvert.rowIndex == i || paylineConvert.rowIndex == i || paylineConvert.rowIndex == i) {
                    symbolView.setAnimStatus(true);
                  } else if (paylineConvert.rowIndex == (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                    error: Error()
                  }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).DIAGONAL_4) {
                    if (i == 3 && j == 2) {
                      symbolView.setAnimStatus(true);
                    } else if (i == 4 && j == 1) {
                      symbolView.setAnimStatus(true);
                    } else if (i == 5 && j == 0) {
                      symbolView.setAnimStatus(true);
                    }
                  } else if (paylineConvert.rowIndex == (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                    error: Error()
                  }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).DIAGONAL_5) {
                    if (i == 3 && j == 0) {
                      symbolView.setAnimStatus(true);
                    } else if (i == 4 && j == 1) {
                      symbolView.setAnimStatus(true);
                    } else if (i == 5 && j == 2) {
                      symbolView.setAnimStatus(true);
                    }
                  }
                }
              }
            }
          }
        }

        resetAllSymbolGroup(columnIndex, timeScale) {
          var _this = this;

          var posOrigin = this.posStart.getWorldPosition();

          var _loop = function _loop(i) {
            var _loop2 = function _loop2(j) {
              var k = _this.column * i + j;
              var symbolNode = _this._symbolNodeList[k];

              if (symbolNode) {
                if (j == columnIndex) {
                  if (i == 2 || i == 3 || i == 4 || i == 5 || i == 6) {
                    tween(symbolNode).to(1, {
                      worldPosition: new Vec3(posOrigin.x + j * _this.distanceColumn, posOrigin.y - i * _this.distanceRow, 0)
                    }, {
                      easing: "bounceOut"
                    }).call(() => {
                      if (i == 6 && j == 2) {
                        (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
                          error: Error()
                        }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
                          error: Error()
                        }), GAME_EVENT) : GAME_EVENT).FINISH_RESET_POSITION_ALL_SYMBOL_GROUP, timeScale);
                      }
                    }).start();
                  } else {
                    symbolNode.setWorldPosition(posOrigin.x + j * _this.distanceColumn, posOrigin.y - i * _this.distanceRow, 0);
                  }
                }
              }
            };

            for (var j = 0; j < _this.column; j++) {
              _loop2(j);
            }
          };

          for (var i = 0; i < this.row; i++) {
            _loop(i);
          }
        }

        onAnimWinGameInSymbol() {
          for (var i = 0; i < this.row; i++) {
            for (var j = 0; j < this.column; j++) {
              var k = this.column * i + j;

              var symbolView = this._symbolNodeList[k].getComponent(_crd && SymbolView === void 0 ? (_reportPossibleCrUseOfSymbolView({
                error: Error()
              }), SymbolView) : SymbolView);

              if (symbolView) {
                if (i >= 3 && i <= 5) {
                  symbolView.showAnimWin();
                }
              }
            }
          }
        }

        traverse2DArray() {
          for (var i = 0; i < this.row; i++) {
            for (var j = 0; j < this.column; j++) {
              var k = this.column * i + j;
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "symbolGroup", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "posStart", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "positionStart", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "symbolScaleList", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "symbolPos", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "symbolSize", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=565ed7876988eb9c6e7e02ad43fbb9a6ad167a27.js.map