System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, LogUtil, Utils, SocketIoClient, GAME_EVENT, SOCKET_EVENT, EventBus, _dec, _class, _crd, ccclass, property, GameService;

  function _reportPossibleCrUseOfLogUtil(extras) {
    _reporterNs.report("LogUtil", "../../../../../../../framework/utils/LogUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUtils(extras) {
    _reporterNs.report("Utils", "../../../../../../../framework/utils/Utils", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSocketIoClient(extras) {
    _reporterNs.report("SocketIoClient", "../../../../../../../framework/network/SocketIoClient", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSOCKET_EVENT(extras) {
    _reporterNs.report("SOCKET_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameLogicController(extras) {
    _reporterNs.report("IGameLogicController", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      LogUtil = _unresolved_2.LogUtil;
    }, function (_unresolved_3) {
      Utils = _unresolved_3.default;
    }, function (_unresolved_4) {
      SocketIoClient = _unresolved_4.SocketIoClient;
    }, function (_unresolved_5) {
      GAME_EVENT = _unresolved_5.GAME_EVENT;
      SOCKET_EVENT = _unresolved_5.SOCKET_EVENT;
    }, function (_unresolved_6) {
      EventBus = _unresolved_6.EventBus;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "05cdfP9EO9Dw5QMe6x6djBV", "GameLogicController", undefined);

      __checkObsolete__(['_decorator']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameService", GameService = (_dec = ccclass("GameService"), _dec(_class = class GameService {
        initGameStart() {
          this.registerEvent();
          this.connectServer();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_PLACE_BET, this.onPlaceBet.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_PLACE_BET, this.onPlaceBet.bind(this));
        }

        connectServer() {
          console.log("connect to sever");
          var auth = this.getAuthLogin(window.location.href);

          if (!auth || !auth.server) {
            (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
              error: Error()
            }), LogUtil) : LogUtil).log("Server not found!");
            return;
          }

          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.connectServer(auth.server, {
            auth: auth,
            path: auth.subpath
          });
          this.initEventNetwork();

          if (auth) {
            console.log("auth", auth);
          }
        }

        getAuthLogin(url_string) {
          var dataDecode = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
            error: Error()
          }), Utils) : Utils).parseUrlData(url_string);

          if (!dataDecode) {
            return;
          }

          (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
            error: Error()
          }), LogUtil) : LogUtil).ENV = dataDecode.env;
          return dataDecode;
        }

        initEventNetwork() {
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).CONNECTION, this.onConnection.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).CONNECT, this.onConnect.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).DISCONNECT, this.ondisconnect.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).CONNECT_ERROR, this.onConnectError.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).UPDATE_COIN, this.onUpdateCoin.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).BALANCE, this.onUpdateBalance.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).GAME_INFO, this.onGameInfo.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).LOGIN, this.onLogin.bind(this), true);
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.on((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).BET, this.onPlaceBetResponseHandle.bind(this), true);
        }

        onPlaceBetResponseHandle(msg) {
          console.log("msg", msg);

          if (msg) {
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).SEND_BET_RESULT_DATA_TO_GAME_CONTROLLER, msg);
          }
        }

        onGameInfo(data) {
          if (data) {
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).SEND_GAME_INFO_DATA_TO_GAME_CONTROLLER, data);
          }
        }

        onPlaceBet(data) {
          (_crd && SocketIoClient === void 0 ? (_reportPossibleCrUseOfSocketIoClient({
            error: Error()
          }), SocketIoClient) : SocketIoClient).instance.emit((_crd && SOCKET_EVENT === void 0 ? (_reportPossibleCrUseOfSOCKET_EVENT({
            error: Error()
          }), SOCKET_EVENT) : SOCKET_EVENT).BET, data);
        }

        onLogin(msg) {
          console.log("come in onLogin", msg);
        }

        onUpdateBalance() {
          console.log("onUpdate balance");
        }

        onUpdateCoin(msg) {
          console.log("update coin");
        }

        onConnectError() {
          console.log("onConect err");
        }

        ondisconnect() {
          console.log("on disconect");
        }

        onConnect() {
          console.log("come in onConnect");
        }

        onConnection() {
          console.log("on connecttion");
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8fc90ecbc955b474cff8c3d8082747f215deb6e6.js.map