System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, GameData, HttpClient, LogUtil, Global, _dec, _class, _crd, ccclass, property, HistoryService;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  function _reportPossibleCrUseOfIGameData(extras) {
    _reporterNs.report("IGameData", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameData(extras) {
    _reporterNs.report("GameData", "../../../../common/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHttpClient(extras) {
    _reporterNs.report("HttpClient", "../../../../../../../framework/network/HttpClient", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLogUtil(extras) {
    _reporterNs.report("LogUtil", "../../../../../../../framework/utils/LogUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIHistoryService(extras) {
    _reporterNs.report("IHistoryService", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHistoryData(extras) {
    _reporterNs.report("HistoryData", "../../../../dataModel/HistoryDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGlobal(extras) {
    _reporterNs.report("Global", "../../../../common/Global", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      GameData = _unresolved_2.GameData;
    }, function (_unresolved_3) {
      HttpClient = _unresolved_3.HttpClient;
    }, function (_unresolved_4) {
      LogUtil = _unresolved_4.LogUtil;
    }, function (_unresolved_5) {
      Global = _unresolved_5.Global;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "b8261mNCi1NzJgChNFJMBvB", "HistoryService", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("HistoryService", HistoryService = (_dec = ccclass("HistoryService"), _dec(_class = class HistoryService {
        constructor() {
          this._gameData = null;
        }

        initGameData() {
          this._gameData = new (_crd && GameData === void 0 ? (_reportPossibleCrUseOfGameData({
            error: Error()
          }), GameData) : GameData)();
        }

        getHistory(gameData, callBack) {
          var _this = this;

          return _asyncToGenerator(function* () {
            var dataRequest = {
              Page: 1,
              Limit: 100
            };
            var url = "" + gameData.server + gameData.subpath + "/history";
            var header = {
              "X-Token": btoa(JSON.stringify(gameData))
            };
            var dataRespone = yield (_crd && HttpClient === void 0 ? (_reportPossibleCrUseOfHttpClient({
              error: Error()
            }), HttpClient) : HttpClient).instance.post(url, dataRequest, header);
            (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
              error: Error()
            }), LogUtil) : LogUtil).log("requestData", dataRespone);

            if (dataRespone.status == 1) {
              var listData = _this.initDataHistory(dataRespone.result);

              callBack && callBack(listData);
            } else {
              (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
                error: Error()
              }), LogUtil) : LogUtil).log("requestData err!");
            }
          })();
        }

        initDataHistory(results) {
          var listData = [];
          results.forEach(d => {
            var gResults = JSON.parse(d.result).Result;

            if (gResults) {
              var data = {
                betTime: d.createTime,
                betId: d.betId,
                betAmount: d.betAmount,
                risk: gResults.Risk,
                multiplier: gResults.Payout / gResults.Stake,
                payout: gResults.Payout
              };
              listData.push(data);
            }
          });
          return this.convertHistoryData(listData);
        }

        convertHistoryData(listData) {
          var listHistoryData = [];

          for (var i = 0; i < listData.length; i++) {
            if (i >= 0 && i < 30) {
              var data = null;
              data = {
                lbDate: (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.extractDate(listData[i].betTime),
                lbTime: (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.extractTime(listData[i].betTime),
                betID: listData[i].betId,
                betAmount: listData[i].betAmount,
                risk: listData[i].risk,
                multiplier: listData[i].multiplier,
                payout: listData[i].payout
              };
              listHistoryData.push(data);
            }
          }

          return this.reverseList(listHistoryData);
        }

        reverseList(listData) {
          return listData.reverse();
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4f45835f3ddcc18c27347cb3987f92122076843a.js.map