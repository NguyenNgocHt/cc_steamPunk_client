System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, AutoPlayStView, ButtonLayoutView, SelectLayoutView, EventBus, GAME_EVENT, UIOpacity, tween, Vec3, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, AutoPlayStController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfAutoPlayStView(extras) {
    _reporterNs.report("AutoPlayStView", "./AutoPlayStView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfButtonLayoutView(extras) {
    _reporterNs.report("ButtonLayoutView", "./ButtonLayoutView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSelectLayoutView(extras) {
    _reporterNs.report("SelectLayoutView", "./SelectLayoutView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      UIOpacity = _cc.UIOpacity;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      AutoPlayStView = _unresolved_2.AutoPlayStView;
    }, function (_unresolved_3) {
      ButtonLayoutView = _unresolved_3.ButtonLayoutView;
    }, function (_unresolved_4) {
      SelectLayoutView = _unresolved_4.SelectLayoutView;
    }, function (_unresolved_5) {
      EventBus = _unresolved_5.EventBus;
    }, function (_unresolved_6) {
      GAME_EVENT = _unresolved_6.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fc7cdG8tM5LpKCdvHJOy+zm", "AutoPlayStController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['UIOpacity']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("AutoPlayStController", AutoPlayStController = (_dec = ccclass("AutoPlayStController"), _dec2 = property(_crd && AutoPlayStView === void 0 ? (_reportPossibleCrUseOfAutoPlayStView({
        error: Error()
      }), AutoPlayStView) : AutoPlayStView), _dec3 = property(_crd && ButtonLayoutView === void 0 ? (_reportPossibleCrUseOfButtonLayoutView({
        error: Error()
      }), ButtonLayoutView) : ButtonLayoutView), _dec4 = property(_crd && SelectLayoutView === void 0 ? (_reportPossibleCrUseOfSelectLayoutView({
        error: Error()
      }), SelectLayoutView) : SelectLayoutView), _dec(_class = (_class2 = class AutoPlayStController extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "autoPlayStView", _descriptor, this);

          _initializerDefineProperty(this, "buttonLayoutView", _descriptor2, this);

          _initializerDefineProperty(this, "selectLayoutView", _descriptor3, this);

          this.selectedNumber = 10;
        }

        onLoad() {
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_CLOSE_AUTO_PLAY_POPUP, this.hidePopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SELECTED_NUMBER, this.setSelectedNumber.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_CANCEL, this.setCancelPopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_CONFIRM, this.setConfirm.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_STOP, this.setStop.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).END_AUTO_PLAY, this.setEndAutoPlay.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_CLOSE_AUTO_PLAY_POPUP, this.hidePopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SELECTED_NUMBER, this.setSelectedNumber.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_CANCEL, this.setCancelPopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_CONFIRM, this.setConfirm.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_STOP, this.setStop.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).END_AUTO_PLAY, this.setEndAutoPlay.bind(this));
        }

        start() {
          this.buttonLayoutView.startPopup();
        }

        onNode() {
          this.node.setScale(0, 0, 0);
          this.setOpacityNode(255);
          this.scaleNode(new Vec3(1, 1, 1));
        }

        hidePopup() {
          this.setOpacityNode(0);
          this.scaleNode(new Vec3(0, 0, 0));
        }

        setOpacityNode(opacity) {
          tween(this.node.getComponent(UIOpacity)).to(0.2, {
            opacity: opacity
          }).start();
        }

        scaleNode(scale) {
          tween(this.node).to(0.2, {
            scale: scale
          }).start();
        }

        setSelectedNumber(selectedNumber) {
          this.selectedNumber = selectedNumber;
        } //button controller


        setCancelPopup() {
          this.hidePopup();
        }

        setConfirm() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_SELECTED_NUMBER_TO_GAME_CONTROLLER, this.selectedNumber);
          this.buttonLayoutView.changeToNodeStop();
          this.hidePopup();
        }

        setStop() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ERASE_SELECTED_NUMBER);
          this.hidePopup();
          this.buttonLayoutView.startPopup();
        }

        setEndAutoPlay() {
          this.buttonLayoutView.startPopup();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "autoPlayStView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "buttonLayoutView", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "selectLayoutView", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4f35b2a2ca274b8197d6049b503cbee0d2c49651.js.map