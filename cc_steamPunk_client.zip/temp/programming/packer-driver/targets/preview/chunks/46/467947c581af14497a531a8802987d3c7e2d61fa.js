System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, BaseSingleton, _crd;

  _export("default", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "93d9ams+1pFxb3BuVUqqALB", "BaseSingleton", undefined);

      _export("default", BaseSingleton = class BaseSingleton {
        constructor() {}

        static get instance() {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          var typeClass = this;

          if (!typeClass._instance) {
            typeClass._instance = new typeClass();
          }

          return typeClass._instance;
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=467947c581af14497a531a8802987d3c7e2d61fa.js.map