System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Global, MAP_SYMBOL, _dec, _class, _crd, ccclass, property, SymbolService;

  function _reportPossibleCrUseOfGlobal(extras) {
    _reporterNs.report("Global", "../../../../common/Global", _context.meta, extras);
  }

  function _reportPossibleCrUseOfMAP_SYMBOL(extras) {
    _reporterNs.report("MAP_SYMBOL", "../../../../common/define", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      Global = _unresolved_2.Global;
    }, function (_unresolved_3) {
      MAP_SYMBOL = _unresolved_3.MAP_SYMBOL;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ec354OcRohO0aoe6y9FtUZb", "SymbolService", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SymbolService", SymbolService = (_dec = ccclass("SymbolService"), _dec(_class = class SymbolService extends Component {
        constructor() {
          super(...arguments);
          this.row = 12;
          this.column = 3;
        }

        generateRandomSymbolList() {
          var SymbolList = [];

          for (var i = 0; i < this.row; i++) {
            var row = [];

            for (var j = 0; j < this.column; j++) {
              var randomNumber = (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                error: Error()
              }), Global) : Global).instance.RandomNumber((_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
                error: Error()
              }), MAP_SYMBOL) : MAP_SYMBOL).a, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
                error: Error()
              }), MAP_SYMBOL) : MAP_SYMBOL).freespin);
              row.push(randomNumber);
            }

            SymbolList.push(row);
          }

          return SymbolList;
        }

        changeNewSymbolIndexList(oldSymbolIndexList, newList) {
          var newSymbolList = [];

          for (var i = 0; i < this.row; i++) {
            var row = [];

            for (var j = 0; j < this.column; j++) {
              if (j == 0) {
                if (i >= 3 && i <= 5) {
                  oldSymbolIndexList[i][j] = newList[0][i - 3];
                  row.push(oldSymbolIndexList[i][j]);
                } else {
                  row.push(oldSymbolIndexList[i][j]);
                }
              } else if (j == 1) {
                if (i >= 3 && i <= 5) {
                  oldSymbolIndexList[i][j] = newList[1][i - 3];
                  row.push(oldSymbolIndexList[i][j]);
                } else {
                  row.push(oldSymbolIndexList[i][j]);
                }
              } else if (j == 2) {
                if (i >= 3 && i <= 5) {
                  oldSymbolIndexList[i][j] = newList[2][i - 3];
                  row.push(oldSymbolIndexList[i][j]);
                } else {
                  row.push(oldSymbolIndexList[i][j]);
                }
              } else {
                row.push(oldSymbolIndexList[i][j]);
              }
            }

            newSymbolList.push(row);
          }

          return newSymbolList;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=73edfc15993d7fd7001c97248aec6d5a052bee01.js.map