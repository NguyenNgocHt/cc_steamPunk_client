System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, PaylinesService, _decorator, Component, SymbolGroupController, EventBus, GAME_EVENT, SymbolService, _dec, _dec2, _class, _class2, _descriptor, _crd, WIN_LOSE_STATE, ccclass, property, SlotController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfPaylinesService(extras) {
    _reporterNs.report("PaylinesService", "./../service/PaylinesService", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSymbolGroupController(extras) {
    _reporterNs.report("SymbolGroupController", "../controller/SymbolGroupController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPoolController(extras) {
    _reporterNs.report("PoolController", "../../../../common/PoolController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfNewBetResultList(extras) {
    _reporterNs.report("NewBetResultList", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPaylinesService(extras) {
    _reporterNs.report("IPaylinesService", "../../../../interfaces/gamePlay/MainLayer_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfISymbolService(extras) {
    _reporterNs.report("ISymbolService", "../../../../interfaces/gamePlay/MainLayer_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSymbolService(extras) {
    _reporterNs.report("SymbolService", "../service/SymbolService", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      PaylinesService = _unresolved_2.PaylinesService;
    }, function (_unresolved_3) {
      SymbolGroupController = _unresolved_3.SymbolGroupController;
    }, function (_unresolved_4) {
      EventBus = _unresolved_4.EventBus;
    }, function (_unresolved_5) {
      GAME_EVENT = _unresolved_5.GAME_EVENT;
    }, function (_unresolved_6) {
      SymbolService = _unresolved_6.SymbolService;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "05295t0sY1It5cTuuzutiFM", "SlotController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      WIN_LOSE_STATE = /*#__PURE__*/function (WIN_LOSE_STATE) {
        WIN_LOSE_STATE[WIN_LOSE_STATE["NO_STATE"] = 0] = "NO_STATE";
        WIN_LOSE_STATE[WIN_LOSE_STATE["WIN_GAME"] = 1] = "WIN_GAME";
        WIN_LOSE_STATE[WIN_LOSE_STATE["LOSE_GAME"] = 2] = "LOSE_GAME";
        return WIN_LOSE_STATE;
      }(WIN_LOSE_STATE || {});

      ({
        ccclass,
        property
      } = _decorator);

      _export("SlotController", SlotController = (_dec = ccclass("SlotController"), _dec2 = property(_crd && SymbolGroupController === void 0 ? (_reportPossibleCrUseOfSymbolGroupController({
        error: Error()
      }), SymbolGroupController) : SymbolGroupController), _dec(_class = (_class2 = class SlotController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "symbolGroupController", _descriptor, this);

          this.symbolIndexList = [];
          this.newSymbolIndexList = [];
          this.paylineList = [];
          this._paylinesService = null;
          this._symbolService = null;
          this.winLoseGameStatus = WIN_LOSE_STATE.NO_STATE;
        }

        onLoad() {
          this.init();
          this.registerEvent();
        }

        init() {
          this.initSlotService();
        }

        initSlotService() {
          this._paylinesService = new (_crd && PaylinesService === void 0 ? (_reportPossibleCrUseOfPaylinesService({
            error: Error()
          }), PaylinesService) : PaylinesService)();
          this._symbolService = new (_crd && SymbolService === void 0 ? (_reportPossibleCrUseOfSymbolService({
            error: Error()
          }), SymbolService) : SymbolService)();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SPINING_STOP, this.resetAllSymbolGroup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).FINISH_RESET_POSITION_ALL_SYMBOL_GROUP, this.setWinLoseGame.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SPINING_STOP, this.resetAllSymbolGroup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).FINISH_RESET_POSITION_ALL_SYMBOL_GROUP, this.setWinLoseGame.bind(this));
        }

        initSymbolGroup(poolControl) {
          let poolControler = poolControl;
          this.symbolIndexList = this._symbolService.generateRandomSymbolList();
          this.symbolGroupController.initSlotGroup(this.symbolIndexList, poolControler);
        }

        getBetResult(betResult) {
          this.symbolIndexList = [];
          this.newSymbolIndexList = [];
          let newBetResultList = betResult.result;
          let newList = [];
          newList.push(newBetResultList.reel1);
          newList.push(newBetResultList.reel2);
          newList.push(newBetResultList.reel3);
          this.symbolIndexList = this._symbolService.generateRandomSymbolList();
          this.newSymbolIndexList = this._symbolService.changeNewSymbolIndexList(this.symbolIndexList, newList);
          this.symbolGroupController.changeSymbolsIndex(this.newSymbolIndexList);
          this.checkPaylinesData(betResult);
        }

        checkPaylinesData(betResult) {
          this.paylineList = [];
          this.paylineList = this._paylinesService.checkPayLines(betResult);

          if (!this.paylineList) {
            this.winLoseGameStatus = WIN_LOSE_STATE.LOSE_GAME;
            return;
          } else {
            this.winLoseGameStatus = WIN_LOSE_STATE.WIN_GAME;
          }
        }

        resetAllSymbolGroup(columnIndex, timeScale) {
          this.symbolGroupController.resetAllSymbolGroup(columnIndex, timeScale);
        }

        setWinLoseGame(timeScale) {
          if (this.winLoseGameStatus == WIN_LOSE_STATE.WIN_GAME) {
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).WIN_GAME, this.paylineList, timeScale);
            this.updateWinAnimStatus();
            this.symbolGroupController.onAnimWinGameInSymbol();
          } else if (this.winLoseGameStatus == WIN_LOSE_STATE.LOSE_GAME) {
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).LOSE_GAME);
          }
        }

        updateWinAnimStatus() {
          let paylinesConvertList = this._paylinesService.getPaylineData(this.paylineList);

          for (let i = 0; i < paylinesConvertList.length; i++) {
            this.symbolGroupController.updateResultsPaylines(paylinesConvertList[i]);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "symbolGroupController", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=2599e80f85d8dd91bb152f417d4d23f259961105.js.map