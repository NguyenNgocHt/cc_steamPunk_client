System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Vec3, WebView, tween, _decorator, GameData, BasePopup, EventBus, GAME_EVENT, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, helpLayerView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfIGameData(extras) {
    _reporterNs.report("IGameData", "../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameData(extras) {
    _reporterNs.report("GameData", "../../common/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBasePopup(extras) {
    _reporterNs.report("BasePopup", "../../../../../framework/ui/BasePopup", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Vec3 = _cc.Vec3;
      WebView = _cc.WebView;
      tween = _cc.tween;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      GameData = _unresolved_2.GameData;
    }, function (_unresolved_3) {
      BasePopup = _unresolved_3.default;
    }, function (_unresolved_4) {
      EventBus = _unresolved_4.EventBus;
    }, function (_unresolved_5) {
      GAME_EVENT = _unresolved_5.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "10f30KOhW5CGa1t0lM0ifvq", "helpLayerView", undefined);

      __checkObsolete__(['Vec3']);

      __checkObsolete__(['WebView']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['game']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("helpLayerView", helpLayerView = (_dec = ccclass("helpLayerView"), _dec2 = property(WebView), _dec(_class = (_class2 = class helpLayerView extends (_crd && BasePopup === void 0 ? (_reportPossibleCrUseOfBasePopup({
        error: Error()
      }), BasePopup) : BasePopup) {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "webView", _descriptor, this);

          this._gameData = null;
        }

        start() {
          console.log(this.webView);
          this.initGameData();
          this.node.setScale(0, 0, 0);
          this.upScale();
          this.setUrl();
        }

        initGameData() {
          this._gameData = new (_crd && GameData === void 0 ? (_reportPossibleCrUseOfGameData({
            error: Error()
          }), GameData) : GameData)();
        }

        upScale() {
          tween(this.node).to(0.2, {
            scale: new Vec3(1, 1, 1)
          }).start();
        }

        setUrl() {
          let gameData = this._gameData.getGameData();

          console.log("game data", gameData);

          if (gameData) {
            let url = `${gameData.server}${gameData.subpath}/guide?language=${gameData.language}`;
            console.log("url webview", url);
            this.webView.url = url;
          }
        }

        onClickCloseBtn() {
          this.hide();
        }

        hide() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLOSE_HELP_POPUP);
          this.node.removeFromParent();
          this.node.destroy();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "webView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=cc52e619e72f222c3f46c81719f78b04f0a8b709.js.map