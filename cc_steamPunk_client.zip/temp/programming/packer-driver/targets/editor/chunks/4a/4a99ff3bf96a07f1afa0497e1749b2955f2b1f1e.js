System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _cc, _class, _class2, _crd, cc, ccclass, property, ControlEvent;

  return {
    setters: [function (_cc2) {
      _cclegacy = _cc2.cclegacy;
      __checkObsolete__ = _cc2.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc2.__checkObsoleteInNamespace__;
      _cc = _cc2;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "75803S3nGZOh6iIumwGB5ow", "ControlEvent", undefined);

      cc = __checkObsoleteInNamespace__(_cc);
      ({
        ccclass,
        property
      } = cc._decorator);

      _export("default", ControlEvent = ccclass(_class = (_class2 = class ControlEvent {}, _class2.Click = 'click', _class2.ClickByTouchHandler = 'click-by-touch-handler', _class2.ShowTooltip = 'show-tooltip', _class2.LongClick = 'long-click', _class2.TouchDown = 'touch-down', _class2.TouchDragInside = 'touch-drag-inside', _class2.TouchDragOutside = 'touch-drag-outside', _class2.TouchDragEnter = 'touch-drag-enter', _class2.TouchDragExit = 'touch-drag-exit', _class2.TouchUpInside = 'touch-up-inside', _class2.TouchUpOutside = 'touch-up-outside', _class2.TouchCancel = 'touch-cancel', _class2.DragBegan = 'drag-began', _class2.DragMoved = 'drag-moved', _class2.DragEnded = 'drag-ended', _class2.DragCancelled = 'drag-cancelled', _class2.CanvasCancel = 'canvas-cancelled', _class2.TutorialNextStep = 'tutorial-next-step', _class2.TutorialNextConversation = 'tutorial-next-conversation', _class2.TutorialFinishConversation = 'tutorial-finish-conversation', _class2.TutorialStartConversation = 'tutorial-start-conversation', _class2.TutorialFinished = 'tutorial-finished', _class2.TabbarItemSelected = 'tabbar-item-selected', _class2.ScreenWillAppear = "ScreenWillAppear", _class2.ScreenDidAppear = "ScreenDidAppear", _class2.ScreenWillDisappear = "ScreenWillDisappear", _class2.ScreenDidDisappear = "ScreenDidDisappear", _class2.PopupWillAppear = "PopupWillAppear", _class2.PopupDidAppear = "PopupDidAppear", _class2.PopupWillDisappear = "PopupWillDisappear", _class2.PopupDidDisappear = "PopupDidDisappear", _class2.WindowWillAppear = "WindowWillAppear", _class2.WindowDidAppear = "WindowDidAppear", _class2.WindowWillDisappear = "WindowWillDisappear", _class2.WindowDidDisappear = "WindowDidDisappear", _class2.ScreenDidPush = "ScreenDidPush", _class2.ScreenDidPop = "ScreenDidPop", _class2.SymbolClick = 'symbol-click', _class2.SpinButtonClick = 'spin-clicked', _class2.SpinButtonTapAndHold = 'spin-tap-and-hold', _class2)) || _class);

      ;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4a99ff3bf96a07f1afa0497e1749b2955f2b1f1e.js.map