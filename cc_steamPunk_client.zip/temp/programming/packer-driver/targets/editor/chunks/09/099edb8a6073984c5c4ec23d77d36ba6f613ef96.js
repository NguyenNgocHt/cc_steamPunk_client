System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, _dec, _class, _class2, _crd, ccclass, property, Global;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "02376OacBFHeYqOx1z/aPp/", "Global", undefined);

      __checkObsolete__(['_decorator', 'SpriteAtlas', 'SpriteFrame']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Global", Global = (_dec = ccclass("Global"), _dec(_class = (_class2 = class Global {
        static get instance() {
          if (this._instance == null) {
            this._instance = new Global();
          }

          return this._instance;
        }

        RandomNumber(minNumber, maxNumber) {
          return Math.floor(Math.random() * (maxNumber - minNumber + 1)) + minNumber;
        }

        formatNumber(num, sign) {
          return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, sign);
        }

        extractDate(milliSeconds) {
          let monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
          let date = new Date(milliSeconds);
          let day = date.getDate();
          let monthIndex = date.getMonth() + 1;
          let year = date.getFullYear();
          return day + "." + monthNames[monthIndex] + "." + year;
        }

        extractTime(milliseconds) {
          let date = new Date(milliseconds);
          let hours = date.getHours();
          let minutes = date.getMinutes();
          let seconds = date.getSeconds();
          return hours + ":" + minutes + ":" + seconds;
        }

      }, _class2._instance = null, _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=099edb8a6073984c5c4ec23d77d36ba6f613ef96.js.map