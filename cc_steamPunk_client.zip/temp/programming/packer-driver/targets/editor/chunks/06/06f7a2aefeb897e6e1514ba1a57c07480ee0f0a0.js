System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _crd;

  function _reportPossibleCrUseOfSettingsData(extras) {
    _reporterNs.report("SettingsData", "./../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPendingData(extras) {
    _reporterNs.report("PendingData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfgameData(extras) {
    _reporterNs.report("gameData", "./../dataModel/GameInfoDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8ab84Rs8O1GXoBVWfXlDGGE", "Common_interfaces", undefined);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=06f7a2aefeb897e6e1514ba1a57c07480ee0f0a0.js.map