System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, TaskContainer, SequenceTask, _crd;

  function _reportPossibleCrUseOfTaskContainer(extras) {
    _reporterNs.report("TaskContainer", "./TaskContainer", _context.meta, extras);
  }

  _export("default", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }, function (_unresolved_2) {
      TaskContainer = _unresolved_2.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c7e21MXnlZI1J0m9/Whzfjy", "SequenceTask", undefined);

      _export("default", SequenceTask = class SequenceTask extends (_crd && TaskContainer === void 0 ? (_reportPossibleCrUseOfTaskContainer({
        error: Error()
      }), TaskContainer) : TaskContainer) {
        update(dt) {
          if (this._listTask.length > 0) {
            this._listTask[0].update(dt);

            if (this._listTask[0].isDone()) {
              this.nextTask();
            }
          }
        }

        nextTask() {
          this.completedTask++;

          if (this._listTask.length > 0) {
            this._listTask[0].cleanUp();

            this._listTask.splice(0, 1);
          }
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e373eba4e00aa6e9a2fc6ad89cb59c23b1f92cd5.js.map