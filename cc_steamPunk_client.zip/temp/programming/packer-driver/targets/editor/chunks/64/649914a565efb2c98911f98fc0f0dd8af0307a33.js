System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _crd, Config;

  function _reportPossibleCrUseOfGameConfig(extras) {
    _reporterNs.report("GameConfig", "../../../../framework/common/GameConfig", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "43db1ipumpOPoNoDG4jEX+e", "Config", undefined);

      _export("Config", Config = {
        GAME_ID: "1000",
        GAME_NAME: "steamPunkClient",
        versionGame: "1.0.0",
        isShowFPS: true,
        isUnitTest: true,
        //------ extends
        win_coin: 1000
      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=649914a565efb2c98911f98fc0f0dd8af0307a33.js.map