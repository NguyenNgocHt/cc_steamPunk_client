System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, MAP_CONVERTED_ROW, _dec, _class, _crd, ccclass, property, PaylinesService;

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "./../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPaylinesService(extras) {
    _reporterNs.report("IPaylinesService", "../../../../interfaces/gamePlay/MainLayer_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPayLinesDaTa(extras) {
    _reporterNs.report("PayLinesDaTa", "./../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfpaylineConvert(extras) {
    _reporterNs.report("paylineConvert", "./../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfMAP_CONVERTED_ROW(extras) {
    _reporterNs.report("MAP_CONVERTED_ROW", "../../../../common/define", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      MAP_CONVERTED_ROW = _unresolved_2.MAP_CONVERTED_ROW;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "81f59/YhKtGD4ntIaV/swmE", "PaylinesService", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PaylinesService", PaylinesService = (_dec = ccclass("PaylinesService"), _dec(_class = class PaylinesService {
        checkPayLines(betResult) {
          let paylinesList = [];

          if (betResult.paylines.length > 0) {
            let paylines = betResult.paylines;

            for (let i = 0; i < paylines.length; i++) {
              let paylineData = paylines[i];
              paylinesList.push(paylineData);
            }

            return paylinesList;
          }
        }

        getPaylineData(paylineList) {
          let paylines = paylineList;
          let paylineConvertList = [];

          for (let i = 0; i < paylines.length; i++) {
            let payline = paylines[i];

            if (payline) {
              let paylineCv = null;
              paylineCv = {
                rowIndex: this.convertPaylineToRowIndex(payline.payline),
                symbols: payline.symbols,
                winType: payline.winType
              };
              paylineConvertList.push(paylineCv);
            }
          }

          return paylineConvertList;
        }

        convertPaylineToRowIndex(paylineIndex) {
          switch (paylineIndex) {
            case 1:
              return (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                error: Error()
              }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).ROW_4;
              break;

            case 2:
              return (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                error: Error()
              }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).ROW_3;
              break;

            case 3:
              return (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                error: Error()
              }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).ROW_5;
              break;

            case 4:
              return (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                error: Error()
              }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).DIAGONAL_4;
              break;

            case 5:
              return (_crd && MAP_CONVERTED_ROW === void 0 ? (_reportPossibleCrUseOfMAP_CONVERTED_ROW({
                error: Error()
              }), MAP_CONVERTED_ROW) : MAP_CONVERTED_ROW).DIAGONAL_5;
              break;
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=fe6191c403e0188b582bbff29d3430e6e4fe041a.js.map