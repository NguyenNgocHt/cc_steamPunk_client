System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, sp, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, LineWinView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      sp = _cc.sp;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "d5bbbpvYMlId53Je3MSsAHZ", "LineWinView", undefined);

      __checkObsolete__(['Acceleration']);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'sp']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LineWinView", LineWinView = (_dec = ccclass("LineWinView"), _dec2 = property(sp.Skeleton), _dec(_class = (_class2 = class LineWinView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lineWin", _descriptor, this);
        }

        start() {
          this.offAllEffect();

          for (let i = 0; i < this.lineWin.length; i++) {
            if (this.lineWin[i].node) {
              this.lineWin[i].setCompleteListener(() => {
                this.lineWin[i].node.active = false;
              });
            }
          }
        }

        offAllEffect() {
          for (let i = 0; i < this.lineWin.length; i++) {
            this.lineWin[i].node.active = false;
          }
        }

        onEffect(effectIndex, timeScale) {
          for (let i = 0; i < this.lineWin.length; i++) {
            if (i == effectIndex - 1) {
              this.lineWin[i].node.active = true;
              this.lineWin[i].setAnimation(0, "Sprite", false);
              this.lineWin[i].timeScale = timeScale;
              this.scheduleOnce(function () {
                this.lineWin[i].node.active = true;
                this.lineWin[i].setAnimation(0, "Sprite", false);
                this.lineWin[i].timeScale = timeScale;
              }, 0.6 / timeScale);
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lineWin", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=fe2b8b470b26609cc6e8bfa993d463a027ca2334.js.map