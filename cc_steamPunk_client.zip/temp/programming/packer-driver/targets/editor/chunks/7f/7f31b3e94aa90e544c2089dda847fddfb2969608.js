System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, _dec, _class, _crd, ccclass, property, ImageModel;

  function _reportPossibleCrUseOfIImageModel_loading(extras) {
    _reporterNs.report("IImageModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "671c12isNxJBp2O9VJmrFwg", "ImageModel", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ImageModel", ImageModel = (_dec = ccclass("ImageModel"), _dec(_class = class ImageModel {
        constructor() {
          this._imageDirs = ["res/fonts/", "res/images/bgr/", "res/images/texturePacker/avatar/"];
        }

        getImagesDirsData() {
          return this._imageDirs;
        }

        setImagesDirsData(imagePath) {
          this._imageDirs.push(imagePath);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7f31b3e94aa90e544c2089dda847fddfb2969608.js.map