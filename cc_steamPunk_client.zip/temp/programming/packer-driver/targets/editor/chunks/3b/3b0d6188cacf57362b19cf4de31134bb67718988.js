System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, _dec, _class, _crd, ccclass, property, PrefabModel;

  function _reportPossibleCrUseOfIPrefabModel_loading(extras) {
    _reporterNs.report("IPrefabModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3ddceqQjChJ+K7W23Xotj/x", "PrefabModel", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PrefabModel", PrefabModel = (_dec = ccclass("PrefabModel"), _dec(_class = class PrefabModel {
        constructor() {
          this._prefabDirs = ["res/anims/prefabs/", "res/prefabs/popup/"];
          this._prefabs = ["res/prefabs/transition/transition_cloud", "res/prefabs/screen/play_screen"];
        }

        getPrefabDirds() {
          return this._prefabDirs;
        }

        getPrefabsPath() {
          return this._prefabs;
        }

        setPrefabDirs(prefabDir) {
          this._prefabDirs.push(prefabDir);
        }

        setPrefabsPath(prefabPath) {
          this._prefabs.push(prefabPath);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=3b0d6188cacf57362b19cf4de31134bb67718988.js.map