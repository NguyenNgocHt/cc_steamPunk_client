System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, TaskContainer, _crd;

  function _reportPossibleCrUseOfBaseTask(extras) {
    _reporterNs.report("BaseTask", "./BaseTask", _context.meta, extras);
  }

  _export("default", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "337953H4T5EZJVSwM7JRQd0", "TaskContainer", undefined);

      _export("default", TaskContainer = class TaskContainer {
        constructor() {
          this._delay = 0;
          this._key = "";
          this._listTask = [];
          this.completedTask = 0;
        }

        isDone() {
          return this._listTask.length == 0;
        }

        pushTask(task) {
          if (task) {
            this._listTask.push(task);
          }
        }

        update(dt) {// override me
        }

        cleanUp() {
          for (var i = 0; i < this._listTask.length; ++i) {
            this._listTask[i].cleanUp();
          }

          this._listTask.splice(0, this._listTask.length);
        }

        setKey(key) {
          this._key = key;
        }

        getKey() {
          return this._key;
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=33051edacc2d10b39d3667db7081093934de61f5.js.map