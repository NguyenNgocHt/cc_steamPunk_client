System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6", "__unresolved_7", "__unresolved_8", "__unresolved_9", "__unresolved_10", "__unresolved_11", "__unresolved_12"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, PopupHistoryView, EventBus, GAME_EVENT, GameInfoService, AutoPlayView, BetAmoutGroupView, BetLineGroupView, BtnBetGroupView, _decorator, Component, Node, HistoryView, instantiate, ScreenManager, PATH, Prefab, TuboView, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _crd, ccclass, property, BetController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfPopupHistoryView(extras) {
    _reporterNs.report("PopupHistoryView", "./../../../../popups/history/PopupHistoryView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameInfoService(extras) {
    _reporterNs.report("IGameInfoService", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfoService(extras) {
    _reporterNs.report("GameInfoService", "../../mainController/service/GameInfoService", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAutoPlayView(extras) {
    _reporterNs.report("AutoPlayView", "../view/AutoPlayView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetAmoutGroupView(extras) {
    _reporterNs.report("BetAmoutGroupView", "../view/BetAmoutGroupView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetLineGroupView(extras) {
    _reporterNs.report("BetLineGroupView", "../view/BetLineGroupView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBtnBetGroupView(extras) {
    _reporterNs.report("BtnBetGroupView", "../view/BtnBetGroupView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHistoryView(extras) {
    _reporterNs.report("HistoryView", "../view/HistoryView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfScreenManager(extras) {
    _reporterNs.report("ScreenManager", "../../../../../../../framework/ui/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPATH(extras) {
    _reporterNs.report("PATH", "../../../../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfTuboView(extras) {
    _reporterNs.report("TuboView", "../view/TuboView", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      instantiate = _cc.instantiate;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      PopupHistoryView = _unresolved_2.PopupHistoryView;
    }, function (_unresolved_3) {
      EventBus = _unresolved_3.EventBus;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }, function (_unresolved_5) {
      GameInfoService = _unresolved_5.GameInfoService;
    }, function (_unresolved_6) {
      AutoPlayView = _unresolved_6.AutoPlayView;
    }, function (_unresolved_7) {
      BetAmoutGroupView = _unresolved_7.BetAmoutGroupView;
    }, function (_unresolved_8) {
      BetLineGroupView = _unresolved_8.BetLineGroupView;
    }, function (_unresolved_9) {
      BtnBetGroupView = _unresolved_9.BtnBetGroupView;
    }, function (_unresolved_10) {
      HistoryView = _unresolved_10.HistoryView;
    }, function (_unresolved_11) {
      ScreenManager = _unresolved_11.default;
    }, function (_unresolved_12) {
      PATH = _unresolved_12.PATH;
    }, function (_unresolved_13) {
      TuboView = _unresolved_13.TuboView;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "6f069g/6O1HWqXgXgS3D2kc", "BetController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['instantiate']);

      __checkObsolete__(['Prefab']);

      __checkObsolete__(['Game']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BetController", BetController = (_dec = ccclass("BetController"), _dec2 = property(_crd && BtnBetGroupView === void 0 ? (_reportPossibleCrUseOfBtnBetGroupView({
        error: Error()
      }), BtnBetGroupView) : BtnBetGroupView), _dec3 = property(_crd && BetAmoutGroupView === void 0 ? (_reportPossibleCrUseOfBetAmoutGroupView({
        error: Error()
      }), BetAmoutGroupView) : BetAmoutGroupView), _dec4 = property(_crd && BetLineGroupView === void 0 ? (_reportPossibleCrUseOfBetLineGroupView({
        error: Error()
      }), BetLineGroupView) : BetLineGroupView), _dec5 = property(_crd && AutoPlayView === void 0 ? (_reportPossibleCrUseOfAutoPlayView({
        error: Error()
      }), AutoPlayView) : AutoPlayView), _dec6 = property(_crd && HistoryView === void 0 ? (_reportPossibleCrUseOfHistoryView({
        error: Error()
      }), HistoryView) : HistoryView), _dec7 = property(_crd && PopupHistoryView === void 0 ? (_reportPossibleCrUseOfPopupHistoryView({
        error: Error()
      }), PopupHistoryView) : PopupHistoryView), _dec8 = property(_crd && TuboView === void 0 ? (_reportPossibleCrUseOfTuboView({
        error: Error()
      }), TuboView) : TuboView), _dec9 = property(Node), _dec10 = property(Node), _dec(_class = (_class2 = class BetController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBetGroupView", _descriptor, this);

          _initializerDefineProperty(this, "betAmoutGroupView", _descriptor2, this);

          _initializerDefineProperty(this, "betLineGroupView", _descriptor3, this);

          _initializerDefineProperty(this, "autoPlayView", _descriptor4, this);

          _initializerDefineProperty(this, "historyView", _descriptor5, this);

          _initializerDefineProperty(this, "popupHistoryView", _descriptor6, this);

          _initializerDefineProperty(this, "tuboView", _descriptor7, this);

          _initializerDefineProperty(this, "historyPopupStartNode", _descriptor8, this);

          _initializerDefineProperty(this, "historyPopupTagetNode", _descriptor9, this);

          this._gameInfoService = null;
        }

        onLoad() {
          this.init();
        }

        init() {
          this.initGameInfoService();
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).GET_GAME_INFO, this.getGameInfo.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).CURRENT_BET_VALUE, this.setTotalBet.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_BET_BUTTON, this.sendBetData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).LOSE_GAME, this.setBetBtnToOriginalState.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_HISTORY_BUTTON, this.showHistoryPopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLOSE_HISTORY_POPUP, this.offHistoryPopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_AUTO_PLAY, this.showPopupAutoPlaySettings.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_TUBO_BUTTON, this.setPlayTubo.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).GET_GAME_INFO, this.getGameInfo.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).CURRENT_BET_VALUE, this.setTotalBet.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_BET_BUTTON, this.sendBetData.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).LOSE_GAME, this.setBetBtnToOriginalState.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_HISTORY_BUTTON, this.showHistoryPopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLOSE_HISTORY_POPUP, this.offHistoryPopup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_AUTO_PLAY, this.showPopupAutoPlaySettings.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_TUBO_BUTTON, this.setPlayTubo.bind(this));
        }

        initGameInfoService() {
          this._gameInfoService = new (_crd && GameInfoService === void 0 ? (_reportPossibleCrUseOfGameInfoService({
            error: Error()
          }), GameInfoService) : GameInfoService)();
        }

        start() {
          this.setNodesToStartPoint();
        }

        setNodesToStartPoint() {
          this.autoPlayView.setNodeToStartPoint();
          this.historyView.setNodeToStartPoint();
          this.popupHistoryView.setNodeToStartPoint(this.historyPopupStartNode);
          this.tuboView.setOffTubo();
        }

        onStartGame() {
          this.btnBetGroupView.startGameEffect();
          this.autoPlayView.moveNodeToTagetPoint();
          this.historyView.moveNodeToTagetPoint();
        }

        getGameInfo() {
          let listDenominations = this._gameInfoService.getListDenominations();

          let listSettings = this._gameInfoService.getlistSettings();

          console.log(listDenominations, listSettings);
          this.betAmoutGroupView.getListDenominations(listDenominations);
          this.betAmoutGroupView.getListSettings(listSettings);
        }

        setTotalBet(currentBetLineValue) {
          console.log("current bet line value", currentBetLineValue);
          this.betLineGroupView.setCurrentBetLineValue(currentBetLineValue);
        }

        sendBetData() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).BET_DATA, {
            info: {
              stake: this.betAmoutGroupView.getCurrentBetLineValue(),
              betLines: this.betLineGroupView.getCurrentBetLine()
            }
          });
        }

        onClickBetBtn() {
          this.btnBetGroupView.onClickBtnBet();
        }

        changeBetbtnSatus() {
          this.btnBetGroupView.changeBetBtnWhenPress();
        }

        setBetBtnToOriginalState() {
          this.btnBetGroupView.changeBetBtnWhenNetural();
        }

        showTextWinFreeSpin() {
          this.btnBetGroupView.showTextWinFreeSpin();
        }

        showFreeSpinValue(value) {
          this.btnBetGroupView.showFreeSpinValue(value);
        } //historyController


        showHistoryPopup() {
          this.popupHistoryView.moveNodeToTagetPoint(this.historyPopupTagetNode, 0.5);
        }

        offHistoryPopup() {
          this.popupHistoryView.moveNodeToTagetPoint(this.historyPopupStartNode, 0.5);
        }

        showHistoryContent(data) {
          this.popupHistoryView.showHistoryContent(data);
        } //autoPlay controler


        showPopupAutoPlaySettings() {
          let autoPlayStPrefab = (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
            error: Error()
          }), ScreenManager) : ScreenManager).instance.assetBundle.get((_crd && PATH === void 0 ? (_reportPossibleCrUseOfPATH({
            error: Error()
          }), PATH) : PATH).AUTO_PLAY_SETTINGS, Prefab);

          if (autoPlayStPrefab) {
            let autoPlayStNode = instantiate(autoPlayStPrefab);

            if (autoPlayStNode) {
              this.autoPlayView.showPoupAutoPlaySt(autoPlayStNode);
            }
          }
        }

        onAutoPlay() {
          this.autoPlayView.onAutoPlay();
        }

        offAutoPlay() {
          this.autoPlayView.offAutoPlay();
        } //tuboController


        setPlayTubo(valueIndex) {
          if (valueIndex == 0) {
            this.tuboView.setOffTubo();
            this.btnBetGroupView.changeTimeLoopSpiningBigGrear(5);
            this.btnBetGroupView.setTimeScale(1);
          } else if (valueIndex == 1) {
            this.tuboView.setOnTubo();
            this.btnBetGroupView.changeTimeLoopSpiningBigGrear(2);
            this.btnBetGroupView.setTimeScale(2);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBetGroupView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "betAmoutGroupView", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "betLineGroupView", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "autoPlayView", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "historyView", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "popupHistoryView", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "tuboView", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "historyPopupStartNode", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "historyPopupTagetNode", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=6d9ae2c1d41d5084b67d0e3f382dadf5839ec1a1.js.map