System.register(["__unresolved_0", "cc", "cc/env", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6", "__unresolved_7"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, EDITOR, LANGUAGE_MAP, StorageUtil, BStorageKey, HttpClient, LogUtil, NotifyUtil, BNotifyType, _dec, _class, _class2, _crd, ccclass, property, LanguageManager;

  function _reportPossibleCrUseOfLANGUAGE_MAP(extras) {
    _reporterNs.report("LANGUAGE_MAP", "../../games/steamPunk_client/script/common/Enum", _context.meta, extras);
  }

  function _reportPossibleCrUseOfStorageUtil(extras) {
    _reporterNs.report("StorageUtil", "../utils/StorageUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBStorageKey(extras) {
    _reporterNs.report("BStorageKey", "../../games/steamPunk_client/script/common/Enum", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHttpClient(extras) {
    _reporterNs.report("HttpClient", "../network/HttpClient", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLogUtil(extras) {
    _reporterNs.report("LogUtil", "../utils/LogUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfNotifyUtil(extras) {
    _reporterNs.report("NotifyUtil", "../utils/NotifyUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBNotifyType(extras) {
    _reporterNs.report("BNotifyType", "../../games/steamPunk_client/script/common/Enum", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_ccEnv) {
      EDITOR = _ccEnv.EDITOR;
    }, function (_unresolved_2) {
      LANGUAGE_MAP = _unresolved_2.LANGUAGE_MAP;
    }, function (_unresolved_3) {
      StorageUtil = _unresolved_3.StorageUtil;
    }, function (_unresolved_4) {
      BStorageKey = _unresolved_4.BStorageKey;
    }, function (_unresolved_5) {
      HttpClient = _unresolved_5.HttpClient;
    }, function (_unresolved_6) {
      LogUtil = _unresolved_6.LogUtil;
    }, function (_unresolved_7) {
      NotifyUtil = _unresolved_7.NotifyUtil;
    }, function (_unresolved_8) {
      BNotifyType = _unresolved_8.BNotifyType;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ea2e0PDRvVKaoi5+xBTUcVb", "LanguageManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LanguageManager", LanguageManager = (_dec = ccclass("LanguageManager"), _dec(_class = (_class2 = class LanguageManager extends Component {
        static getText(key) {
          let s = LanguageManager._data[key];

          if (!s) {
            s = "";
          }

          return s;
        }

        async getLanguage2(dataGame, callback = null) {
          if (!dataGame) {
            callback && callback(false);
            return;
          }

          let language = dataGame.language;
          let version = dataGame.version;

          if (!language) {
            language = (_crd && LANGUAGE_MAP === void 0 ? (_reportPossibleCrUseOfLANGUAGE_MAP({
              error: Error()
            }), LANGUAGE_MAP) : LANGUAGE_MAP).English;
          }

          if (!version) {
            version = "0.01";
          }

          let urlLang = `${dataGame.server}${dataGame.subpath}/setting`;
          let cachedData = null;
          let cachedHash = null;

          if (!EDITOR) {
            cachedData = (_crd && StorageUtil === void 0 ? (_reportPossibleCrUseOfStorageUtil({
              error: Error()
            }), StorageUtil) : StorageUtil).instance.read((_crd && BStorageKey === void 0 ? (_reportPossibleCrUseOfBStorageKey({
              error: Error()
            }), BStorageKey) : BStorageKey).LANGUAGE_DATA);
            cachedHash = (_crd && StorageUtil === void 0 ? (_reportPossibleCrUseOfStorageUtil({
              error: Error()
            }), StorageUtil) : StorageUtil).instance.read((_crd && BStorageKey === void 0 ? (_reportPossibleCrUseOfBStorageKey({
              error: Error()
            }), BStorageKey) : BStorageKey).LANGUAGE_CACHE);
          }

          let self = this;
          let hashCheck = version + language;

          if (!EDITOR && cachedData && cachedHash == hashCheck) {
            this._handleData(JSON.parse(cachedData), callback);
          } else {
            let data = await (_crd && HttpClient === void 0 ? (_reportPossibleCrUseOfHttpClient({
              error: Error()
            }), HttpClient) : HttpClient).instance.post(urlLang, dataGame);

            if (data && data.status === 1) {
              self._updateCache(data.result.language, hashCheck);

              this._handleData(data.result.language, callback);

              console.log("language data", data);
            } else {
              // this._handleData(JSON.parse(cachedData));
              callback && callback(false);
            }
          }
        }

        _handleData(data, callback) {
          LanguageManager._data = data;
          (_crd && NotifyUtil === void 0 ? (_reportPossibleCrUseOfNotifyUtil({
            error: Error()
          }), NotifyUtil) : NotifyUtil).instance.emit((_crd && BNotifyType === void 0 ? (_reportPossibleCrUseOfBNotifyType({
            error: Error()
          }), BNotifyType) : BNotifyType).LANGUAGE_CHANGED);
          (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
            error: Error()
          }), LogUtil) : LogUtil).log(JSON.stringify(data));
          console.log("data", data);
          callback && callback(true);
        }

        _updateCache(data, hash) {
          if (!EDITOR) {
            (_crd && StorageUtil === void 0 ? (_reportPossibleCrUseOfStorageUtil({
              error: Error()
            }), StorageUtil) : StorageUtil).instance.write((_crd && BStorageKey === void 0 ? (_reportPossibleCrUseOfBStorageKey({
              error: Error()
            }), BStorageKey) : BStorageKey).LANGUAGE_DATA, JSON.stringify(data));
            (_crd && StorageUtil === void 0 ? (_reportPossibleCrUseOfStorageUtil({
              error: Error()
            }), StorageUtil) : StorageUtil).instance.write((_crd && BStorageKey === void 0 ? (_reportPossibleCrUseOfBStorageKey({
              error: Error()
            }), BStorageKey) : BStorageKey).LANGUAGE_CACHE, hash);
          } // this._handleData(data);

        }

      }, _class2._data = {}, _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=5d4e3c680b6f51ae91c1f13f1cd3d0cdd3b1e081.js.map