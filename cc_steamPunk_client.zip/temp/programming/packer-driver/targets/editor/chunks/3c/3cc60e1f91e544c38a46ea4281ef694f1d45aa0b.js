System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, LampView, GearView, LineSelectView, LightView, LineWinView, WinGameBonusView, sp, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _crd, ccclass, property, EffectLayerView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfLampView(extras) {
    _reporterNs.report("LampView", "./LampView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGearView(extras) {
    _reporterNs.report("GearView", "./GearView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLineSelectView(extras) {
    _reporterNs.report("LineSelectView", "./LineSelectView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLightView(extras) {
    _reporterNs.report("LightView", "./LightView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLineWinView(extras) {
    _reporterNs.report("LineWinView", "./LineWinView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfWinGameBonusView(extras) {
    _reporterNs.report("WinGameBonusView", "./WinGameBonusView", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      sp = _cc.sp;
    }, function (_unresolved_2) {
      LampView = _unresolved_2.LampView;
    }, function (_unresolved_3) {
      GearView = _unresolved_3.GearView;
    }, function (_unresolved_4) {
      LineSelectView = _unresolved_4.LineSelectView;
    }, function (_unresolved_5) {
      LightView = _unresolved_5.LightView;
    }, function (_unresolved_6) {
      LineWinView = _unresolved_6.LineWinView;
    }, function (_unresolved_7) {
      WinGameBonusView = _unresolved_7.WinGameBonusView;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "72297YFOHZJFbm+NHUB6p3h", "EffectLayerView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['sp']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("EffectLayerView", EffectLayerView = (_dec = ccclass("EffectLayerView"), _dec2 = property(_crd && LightView === void 0 ? (_reportPossibleCrUseOfLightView({
        error: Error()
      }), LightView) : LightView), _dec3 = property(_crd && LightView === void 0 ? (_reportPossibleCrUseOfLightView({
        error: Error()
      }), LightView) : LightView), _dec4 = property(_crd && LampView === void 0 ? (_reportPossibleCrUseOfLampView({
        error: Error()
      }), LampView) : LampView), _dec5 = property(_crd && LampView === void 0 ? (_reportPossibleCrUseOfLampView({
        error: Error()
      }), LampView) : LampView), _dec6 = property(_crd && GearView === void 0 ? (_reportPossibleCrUseOfGearView({
        error: Error()
      }), GearView) : GearView), _dec7 = property(_crd && LineSelectView === void 0 ? (_reportPossibleCrUseOfLineSelectView({
        error: Error()
      }), LineSelectView) : LineSelectView), _dec8 = property(_crd && LineWinView === void 0 ? (_reportPossibleCrUseOfLineWinView({
        error: Error()
      }), LineWinView) : LineWinView), _dec9 = property(_crd && WinGameBonusView === void 0 ? (_reportPossibleCrUseOfWinGameBonusView({
        error: Error()
      }), WinGameBonusView) : WinGameBonusView), _dec10 = property(sp.Skeleton), _dec11 = property(sp.Skeleton), _dec(_class = (_class2 = class EffectLayerView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lightRightView", _descriptor, this);

          _initializerDefineProperty(this, "lightLeftView", _descriptor2, this);

          _initializerDefineProperty(this, "lampLeft", _descriptor3, this);

          _initializerDefineProperty(this, "lampRight", _descriptor4, this);

          _initializerDefineProperty(this, "gearView", _descriptor5, this);

          _initializerDefineProperty(this, "lineSelectView", _descriptor6, this);

          _initializerDefineProperty(this, "lineWinView", _descriptor7, this);

          _initializerDefineProperty(this, "winGameBonusView", _descriptor8, this);

          _initializerDefineProperty(this, "spinEffectV1", _descriptor9, this);

          _initializerDefineProperty(this, "spinEffectV2", _descriptor10, this);
        }

        start() {
          this.spinEffectV1.node.active = false;
          this.spinEffectV2.node.active = false;
          this.spinEffectV1.setCompleteListener(() => {
            this.spinEffectV1.node.active = false;
          });
          this.spinEffectV2.setCompleteListener(() => {
            this.spinEffectV2.node.active = false;
          });
        } //common


        initStartGame() {
          this.offLamp_leftRight();
          this.offSpinGear();
          this.offLightStart();
          this.offLbWinStatus();
          this.offAllLines();
        }

        openingEnding() {
          this.onLamp_leftRight();
          this.onLightStart();
          this.scheduleOnce(function () {
            this.offLightStart();
            this.onSpinGear();
            this.onLightContinuously();
          }, 0.5);
        } //Lamp View


        offLamp_leftRight() {
          this.lampLeft.offLamp();
          this.lampRight.offLamp();
        }

        onLamp_leftRight() {
          this.lampLeft.onLamp();
          this.lampRight.onLamp();
        } //Gear View


        offSpinGear() {
          this.gearView.offSpinAnimGear();
        }

        onSpinGear() {
          this.gearView.onSpinAnimGear();
        }

        offLightStart() {
          this.gearView.offLightStart();
        }

        onLightStart() {
          this.gearView.onLightStart();
        }

        offLbWinStatus() {
          this.gearView.offLbWinStatus();
        }

        onLbWinStatus() {
          this.gearView.onLbWinStatus();
        } //line select view


        showLineSelectView(totalLines) {
          this.lineSelectView.showLineSelect(totalLines);
        }

        offAllLines() {
          this.lineSelectView.offAllLines();
        } //light left right view


        onLightContinuously() {
          this.lightLeftView.turnsOnLightContinuously();
          this.lightRightView.turnsOnLightContinuously();
        }

        onEffectWinGame(effectIndex, timeScale) {
          this.lineWinView.onEffect(effectIndex, timeScale);
          this.lightLeftView.onLight(effectIndex, 1.0 / timeScale);
          this.lightRightView.onLight(effectIndex, 1.0 / timeScale);
        } //show bonus


        showWinGameBonus(coinBonus, multiplier, tagetNode) {
          let tagetPos = tagetNode.getWorldPosition();
          this.winGameBonusView.updateCoinAndMultiplier(coinBonus, multiplier);
          this.winGameBonusView.showEffectMoneyWin(tagetPos, 0.5, 0.3);
        } //spinEffect


        onSpinEffectV1() {
          this.spinEffectV1.node.active = true;
          this.spinEffectV1.setAnimation(0, "Sprite", false);
        }

        onSpinEffectV2(timeScale) {
          this.spinEffectV2.node.active = true;
          this.spinEffectV2.setAnimation(0, "Sprite", false);
          this.spinEffectV2.timeScale = timeScale;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lightRightView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lightLeftView", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lampLeft", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "lampRight", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gearView", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "lineSelectView", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "lineWinView", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "winGameBonusView", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "spinEffectV1", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "spinEffectV2", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=3cc60e1f91e544c38a46ea4281ef694f1d45aa0b.js.map