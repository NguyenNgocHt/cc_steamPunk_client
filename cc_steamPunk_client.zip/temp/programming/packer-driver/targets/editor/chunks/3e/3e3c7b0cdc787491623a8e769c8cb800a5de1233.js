System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, _dec, _class, _crd, ccclass, property, BetResultService;

  function _reportPossibleCrUseOfIBetResultService(extras) {
    _reporterNs.report("IBetResultService", "../../../../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetData(extras) {
    _reporterNs.report("BetData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPayLinesDaTa(extras) {
    _reporterNs.report("PayLinesDaTa", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "666a5EQCBlN4oaeiRGOjcuZ", "BetResultService", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BetResultService", BetResultService = (_dec = ccclass("BetResultService"), _dec(_class = class BetResultService {
        constructor() {
          this.betInfoData = null;
        }

        handleBetResultData(betInfo) {
          this.betInfoData = betInfo;
        }

        getBetResult() {
          return this.betInfoData ? this.betInfoData.result : null;
        }

        getPayLines(betResult) {
          let paylinesList = [];

          if (betResult.paylines.length > 0) {
            let paylines = betResult.paylines;

            for (let i = 0; i < paylines.length; i++) {
              let paylineData = paylines[i];
              paylinesList.push(paylineData);
            }

            return paylinesList;
          }
        }

        getBalance() {
          var r = this.getBetResult();
          return r != null ? r.balance : 0;
        }

        getMultiplierValue() {
          var result = this.getBetResult();
          return result != null ? result.payout / result.stake : -1;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=3e3c7b0cdc787491623a8e769c8cb800a5de1233.js.map