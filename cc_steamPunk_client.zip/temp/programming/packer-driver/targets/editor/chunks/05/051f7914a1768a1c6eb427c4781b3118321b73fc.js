System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, TaskContainer, ParallelTask, _crd;

  function _reportPossibleCrUseOfTaskContainer(extras) {
    _reporterNs.report("TaskContainer", "./TaskContainer", _context.meta, extras);
  }

  _export("default", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }, function (_unresolved_2) {
      TaskContainer = _unresolved_2.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "cd7belnwtBDLbGvMC0JEqp/", "ParallelTask", undefined);

      _export("default", ParallelTask = class ParallelTask extends (_crd && TaskContainer === void 0 ? (_reportPossibleCrUseOfTaskContainer({
        error: Error()
      }), TaskContainer) : TaskContainer) {
        update(dt) {
          let removeThisTask = false;

          for (let i = 0; i < this._listTask.length
          /* i increase below, if need */
          ;) {
            removeThisTask = false; // if (this._listTask) {

            this._listTask[i].update(dt);

            if (this._listTask[i].isDone()) {
              removeThisTask = true;

              this._listTask[i].cleanUp();
            }

            if (removeThisTask) {
              // remove the task
              this._listTask.splice(i, 1);
            } else {
              ++i;
            }
          }
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=051f7914a1768a1c6eb427c4781b3118321b73fc.js.map