System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, sys, BaseSingleton, _dec, _class, _class2, _crd, ccclass, property, StorageUtil;

  function _reportPossibleCrUseOfBaseSingleton(extras) {
    _reporterNs.report("BaseSingleton", "../common/BaseSingleton", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBStorageKey(extras) {
    _reporterNs.report("BStorageKey", "../../games/steamPunk_client/script/common/Enum", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      sys = _cc.sys;
    }, function (_unresolved_2) {
      BaseSingleton = _unresolved_2.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "21da3gPUgRPBYkv90QjjpBR", "StorageUtil", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'sys']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("StorageUtil", StorageUtil = (_dec = ccclass("StorageUtil"), _dec(_class = (_class2 = class StorageUtil extends (_crd && BaseSingleton === void 0 ? (_reportPossibleCrUseOfBaseSingleton({
        error: Error()
      }), BaseSingleton) : BaseSingleton) {
        constructor(...args) {
          super(...args);
          this.storageMap = new Map();
        }

        async setup() {
          console.log("StorageUtil setup");
        }

        /**
         *
         *
         * @memberof StorageUtil
         */
        dumpStorageMap() {
          const data = [];
          this.storageMap.forEach((v, k) => {
            data.push({
              key: k,
              value: v
            });
          }); // LogUtil.table(data);
        }
        /**
         *
         *
         * @memberof StorageUtil
         */


        clearCache() {
          this.storageMap.clear();
        }
        /**
         *
         *
         * @param key
         * @param [value]
         * @returns {*}
         * @memberof StorageUtil
         */


        read(key, value) {
          let result = value;
          let realKey = this.getKey(key);

          if (this.storageMap.has(realKey)) {
            return this.storageMap.get(realKey);
          }

          const userData = JSON.parse(sys.localStorage.getItem(realKey));

          if (userData !== null) {
            result = userData;
          }

          this.storageMap.set(realKey, result);
          return result;
        }
        /**
         *
         *
         * @param key
         * @param value
         * @memberof StorageUtil
         */


        write(key, value) {
          let realKey = this.getKey(key);
          this.storageMap.set(realKey, value);
          sys.localStorage.setItem(realKey, JSON.stringify(value || null));
        }
        /**
         *
         *
         * @param key
         * @memberof StorageUtil
         */


        remove(key) {
          let realKey = this.getKey(key);
          this.storageMap.delete(realKey);
          sys.localStorage.removeItem(realKey);
        }
        /**
         *
         *
         * @memberof StorageUtil
         */


        clear() {
          this.storageMap.clear();
          sys.localStorage.clear();
        }
        /**
         * key
         *
         * @private
         * @param key
         * @returns {*}
         * @memberof StorageUtil
         */


        getKey(key) {
          return `${StorageUtil.prefix}_${key}`;
        }

      }, _class2.prefix = "", _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=053fcff5dd49bbbe091cefd969b4ee16fcce8c1a.js.map