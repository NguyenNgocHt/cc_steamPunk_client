System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, tween, Vec3, JackpotAnimView, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, GameLayerView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfJackpotAnimView(extras) {
    _reporterNs.report("JackpotAnimView", "./JackpotAnimView", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      JackpotAnimView = _unresolved_2.JackpotAnimView;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "5da32HavCdLxq2H6fr2bCy/", "GameLayerView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'tween', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameLayerView", GameLayerView = (_dec = ccclass("GameLayerView"), _dec2 = property(_crd && JackpotAnimView === void 0 ? (_reportPossibleCrUseOfJackpotAnimView({
        error: Error()
      }), JackpotAnimView) : JackpotAnimView), _dec3 = property(_crd && JackpotAnimView === void 0 ? (_reportPossibleCrUseOfJackpotAnimView({
        error: Error()
      }), JackpotAnimView) : JackpotAnimView), _dec4 = property(Node), _dec5 = property(Node), _dec6 = property(Node), _dec7 = property(Node), _dec(_class = (_class2 = class GameLayerView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "freeSpinAnimView", _descriptor, this);

          _initializerDefineProperty(this, "jackpotAnimView", _descriptor2, this);

          _initializerDefineProperty(this, "metalgate1", _descriptor3, this);

          _initializerDefineProperty(this, "metalgate2", _descriptor4, this);

          _initializerDefineProperty(this, "destinationUp", _descriptor5, this);

          _initializerDefineProperty(this, "greenOverlap", _descriptor6, this);

          this.duration = 2;
        }

        metalgateToUp() {
          this.moveMetalgate1();
          this.moveMetalgate2();
        }

        moveMetalgate1() {
          this.moveMetalgateToTaget(this.metalgate1, this.destinationUp);
        }

        moveMetalgate2() {
          this.moveMetalgateToTaget(this.metalgate2, this.destinationUp);
        }

        moveMetalgateToTaget(cutrainNode, nodeTaget) {
          tween(cutrainNode).to(this.duration, {
            position: new Vec3(nodeTaget.position.x, nodeTaget.position.y)
          }, {
            easing: "sineIn"
          }).start();
        }

        showFreeSpinAnim() {
          this.freeSpinAnimView.startJackpotAnim();
        }

        showJackpotAnim() {
          this.jackpotAnimView.startJackpotAnim();
        }

        setGreenOverlapActive(active) {
          this.greenOverlap.active = active;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "freeSpinAnimView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "jackpotAnimView", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "metalgate1", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "metalgate2", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "destinationUp", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "greenOverlap", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=2ca38ab859397b00cf330e7bd4ae9d2f7c61fe33.js.map