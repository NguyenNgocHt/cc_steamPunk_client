System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd, MESENGER, PATH, CLIENT_COMMAN_ID_IP, CLIENT_COMMAN_ID_OP, SEVER_COMMAN_ID_IP, SEVER_COMMAN_ID_OP, ANIM_NAME, MAP_SYMBOL, MAP_CONVERTED_ROW, LIGHT_GROUP_NAME, PAY_OUT_RATE, SYMBOL_LIST;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "85172WtBQlH+4PbbvjWMWDI", "define", undefined);

      _export("MESENGER", MESENGER = {
        RESOURCE_LOADING_ERR: "Đã có lỗi tải tài nguyên, vui lòng thử lại"
      });

      _export("PATH", PATH = {
        POPUP_NOTIFY: "res/prefabs/popup/popup_notify",
        LOGIN_SCREEN: "res/prefabs/screen/login_screen",
        PLAY_SCREEN: "res/prefabs/screen/play_screen",
        HELP_LAYER: "res/prefabs/popup/helpLayer",
        AUTO_PLAY_SETTINGS: "res/prefabs/popup/autoPlaySt"
      });

      _export("CLIENT_COMMAN_ID_IP", CLIENT_COMMAN_ID_IP = {
        LOGIN_RESULT_ID: 2000,
        PLAYER_INFO_ID: 2001
      });

      _export("CLIENT_COMMAN_ID_OP", CLIENT_COMMAN_ID_OP = {
        LOGIN_ID: 1000,
        SEND_PLAYERID_ID: 1001
      });

      _export("SEVER_COMMAN_ID_IP", SEVER_COMMAN_ID_IP = {
        LOGIN_ID: 1000,
        SEND_PLAYERID_ID: 1001
      });

      _export("SEVER_COMMAN_ID_OP", SEVER_COMMAN_ID_OP = {
        LOGIN_RESULT_ID: 2000,
        PLAYER_INFO_ID: 2001
      });

      _export("ANIM_NAME", ANIM_NAME = {
        ANIM_BIG_WIN: "big win",
        ANIM_SMALL_WIN: "small win",
        ANIM_IDLE: "idle"
      });

      _export("MAP_SYMBOL", MAP_SYMBOL = {
        a: 1,
        j: 2,
        q: 3,
        k: 4,
        gear: 5,
        girl: 6,
        guys: 7,
        wild: 8,
        jackpot: 9,
        freespin: 10
      });

      _export("MAP_CONVERTED_ROW", MAP_CONVERTED_ROW = {
        ROW_3: 3,
        ROW_4: 4,
        ROW_5: 5,
        DIAGONAL_4: 53,
        DIAGONAL_5: 35
      });

      _export("LIGHT_GROUP_NAME", LIGHT_GROUP_NAME = {
        LIGHT_RIGHT: "lightRight",
        LIGHT_LEFT: "lightLeft"
      });

      _export("PAY_OUT_RATE", PAY_OUT_RATE = [0.05, 0.1, 0.15, 0.25, 0.4, 0.5, 1, 2.5, 5, 10, 15, 20, 25, 35, 50]);

      _export("SYMBOL_LIST", SYMBOL_LIST = ["A", "J", "Q", "K", "GEAR", "GIRL", "GUYS", "WILD", "JACKPOT", "FREE_SPINE"]);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=88f4bb58c8ec4e2194cc0542dbcffe1b95538361.js.map