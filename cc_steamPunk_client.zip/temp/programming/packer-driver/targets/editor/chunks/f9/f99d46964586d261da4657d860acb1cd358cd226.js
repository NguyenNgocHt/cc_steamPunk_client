System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, sys, LOCAL_STORAGE_KEY_WORD, _dec, _class, _crd, ccclass, property, GameInfoService;

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPendingData(extras) {
    _reporterNs.report("PendingData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSettingsData(extras) {
    _reporterNs.report("SettingsData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD(extras) {
    _reporterNs.report("LOCAL_STORAGE_KEY_WORD", "../../../../common/Path", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameInfoService(extras) {
    _reporterNs.report("IGameInfoService", "../../../../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      sys = _cc.sys;
    }, function (_unresolved_2) {
      LOCAL_STORAGE_KEY_WORD = _unresolved_2.LOCAL_STORAGE_KEY_WORD;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fbfd1yf4XZPKLdweROGJaYT", "GameInfoService", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'sys']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameInfoService", GameInfoService = (_dec = ccclass("GameInfoService"), _dec(_class = class GameInfoService {
        init() {}

        getGameInfo() {
          return JSON.parse(sys.localStorage.getItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).GAME_INFO));
        }

        getListDenominations() {
          return this.getlistSettings() ? this.getlistSettings().Denominations : [];
        }

        getListPending() {
          return this.getGameInfo() ? this.getGameInfo().pending : null;
        }

        getlistSettings() {
          return this.getGameInfo() ? this.getGameInfo().settings : null;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=f99d46964586d261da4657d860acb1cd358cd226.js.map