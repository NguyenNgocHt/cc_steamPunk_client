System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, SymbolView, SymbolGroupController, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, SpinningMachineController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSymbolView(extras) {
    _reporterNs.report("SymbolView", "../view/SymbolView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSymbolGroupController(extras) {
    _reporterNs.report("SymbolGroupController", "../controller/SymbolGroupController", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }, function (_unresolved_2) {
      SymbolView = _unresolved_2.SymbolView;
    }, function (_unresolved_3) {
      SymbolGroupController = _unresolved_3.SymbolGroupController;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ab756enul5Oqb2D734n8On0", "SpinningMachineController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SpinningMachineController", SpinningMachineController = (_dec = ccclass("SpinningMachineController"), _dec2 = property(Node), _dec3 = property(_crd && SymbolGroupController === void 0 ? (_reportPossibleCrUseOfSymbolGroupController({
        error: Error()
      }), SymbolGroupController) : SymbolGroupController), _dec(_class = (_class2 = class SpinningMachineController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "symbolGroup", _descriptor, this);

          _initializerDefineProperty(this, "slotView", _descriptor2, this);

          this.symbolNodeList = [];
          this.loopIndex = 21;
          this.timeSCale = 1;
        }

        showPositionSymbols() {
          this.symbolNodeList = [];
          this.symbolNodeList = this.slotView.getSymbolNodeList();

          if (this.symbolNodeList) {
            for (let i = 0; i < this.symbolNodeList.length; i++) {
              let symbolView = this.symbolNodeList[i].getComponent(_crd && SymbolView === void 0 ? (_reportPossibleCrUseOfSymbolView({
                error: Error()
              }), SymbolView) : SymbolView);

              if (symbolView) {
                symbolView.spinning(this.loopIndex, this.timeSCale);
              }
            }
          }
        }

        setTimeScale(timeScale) {
          this.timeSCale = timeScale;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "symbolGroup", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "slotView", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=be9464a12383c84f9ee3dcd72818858cee26c826.js.map