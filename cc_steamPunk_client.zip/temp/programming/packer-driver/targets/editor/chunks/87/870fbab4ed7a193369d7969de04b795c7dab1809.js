System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _crd;

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfbetResultMock(extras) {
    _reporterNs.report("betResultMock", "../dataModel/MockConfigData", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "66e45F+vVFHJKnhBwOssSl3", "Mock_interfaces", undefined);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=870fbab4ed7a193369d7969de04b795c7dab1809.js.map