System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, BaseSingleton, _dec, _class, _crd, ccclass, property, HttpClient;

  function _reportPossibleCrUseOfBaseSingleton(extras) {
    _reporterNs.report("BaseSingleton", "../common/BaseSingleton", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      BaseSingleton = _unresolved_2.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "231fdYXnrVEwIrh6eaQiKMw", "HttpClient", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("HttpClient", HttpClient = (_dec = ccclass("HttpClient"), _dec(_class = class HttpClient extends (_crd && BaseSingleton === void 0 ? (_reportPossibleCrUseOfBaseSingleton({
        error: Error()
      }), BaseSingleton) : BaseSingleton) {
        async setup() {
          console.log("HttpClient setup");
        }

        async get(url, params) {
          try {
            let that = this;
            return new Promise(function (resolve, reject) {
              var xhr = new XMLHttpRequest();
              url = that.buildUrlWithParams(url, params);
              xhr.open("GET", url);

              xhr.onload = function () {
                if (xhr.status >= 200 && xhr.status < 300) {
                  resolve(JSON.parse(xhr.response));
                } else {
                  reject({
                    status: xhr.status,
                    statusText: xhr.statusText
                  });
                }
              };

              xhr.onerror = function () {
                reject({
                  status: xhr.status,
                  statusText: xhr.statusText
                });
              };

              xhr.send();
            });
          } catch (e) {}
        }

        async post(url, body, header = null) {
          try {
            return new Promise(function (resolve, reject) {
              var xhr = new XMLHttpRequest();
              xhr.open("POST", url);
              xhr.setRequestHeader("Content-Type", "application/json");

              if (header) {
                for (const key in header) {
                  const value = header[key];
                  xhr.setRequestHeader(key, value);
                }
              }

              xhr.onload = function () {
                if (xhr.status >= 200 && xhr.status < 300) {
                  resolve(JSON.parse(xhr.response));
                } else {
                  reject({
                    status: xhr.status,
                    statusText: xhr.statusText
                  });
                }
              };

              xhr.onerror = function () {
                reject({
                  status: xhr.status,
                  statusText: xhr.statusText
                });
              };

              xhr.send(JSON.stringify(body));
            });
          } catch (e) {}
        }

        buildUrlWithParams(url, params) {
          const queryString = Object.keys(params).map(key => encodeURIComponent(key) + "=" + encodeURIComponent(params[key].toString())).join("&");
          return url + (url.indexOf("?") === -1 ? "?" : "&") + queryString;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=c8f784bd47ab5f4c6af46833dbceb0b7c6989d6f.js.map