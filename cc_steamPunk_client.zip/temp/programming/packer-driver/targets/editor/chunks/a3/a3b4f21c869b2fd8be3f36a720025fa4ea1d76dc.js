System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, LogUtil, io, _dec, _class, _class2, _crd, ccclass, property, LOGS_SKIPS, SocketIoClient;

  function _reportPossibleCrUseOfLogUtil(extras) {
    _reporterNs.report("LogUtil", "../utils/LogUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfio(extras) {
    _reporterNs.report("io", "./socket.io.min.js", _context.meta, extras);
  }

  function _reportPossibleCrUseOfISocketIOClient(extras) {
    _reporterNs.report("ISocketIOClient", "../../games/steamPunk_client/script/interfaces/Mock_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      LogUtil = _unresolved_2.LogUtil;
    }, function (_unresolved_3) {
      io = _unresolved_3.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "04a7coanaFA8qKcGtVerCeG", "SocketIoClient", undefined);

      __checkObsolete__(['_decorator']);

      ({
        ccclass,
        property
      } = _decorator);
      LOGS_SKIPS = ["move", "balance", "update-x-y", "gameevent", "xmove"];

      _export("SocketIoClient", SocketIoClient = (_dec = ccclass("SocketIoClient"), _dec(_class = (_class2 = class SocketIoClient {
        constructor() {
          this.socket = null;
          this._isConnected = false;
        }

        static get instance() {
          if (this._instance == null) {
            this._instance = new SocketIoClient();
          }

          return this._instance;
        }

        set isConnected(val) {
          this._isConnected = val;
        }

        get isConnected() {
          return this.socket && this.socket.connected && this._isConnected;
        }

        async setup() {
          (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
            error: Error()
          }), LogUtil) : LogUtil).log("SocketIoClient setup");
        }

        connectServer(linkServer, auth) {
          (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
            error: Error()
          }), LogUtil) : LogUtil).logS("%c" + `connectServer->>>>>: ${linkServer}`, "color: #bada55");

          if (this.socket) {
            this.socket.disconnect();
          }

          if (auth) {
            this.socket = (_crd && io === void 0 ? (_reportPossibleCrUseOfio({
              error: Error()
            }), io) : io)(linkServer, auth);
          } else {
            this.socket = (_crd && io === void 0 ? (_reportPossibleCrUseOfio({
              error: Error()
            }), io) : io)(linkServer);
          }
        }

        on(socketEvent, callbackData, isOff = true) {
          console.log("event", socketEvent);

          if (this.socket) {
            if (isOff) {
              this.socket.off(socketEvent);
            }

            this.socket.on(socketEvent, msg => {
              if (!LOGS_SKIPS.includes(socketEvent)) {
                (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
                  error: Error()
                }), LogUtil) : LogUtil).logS("%c" + `-->>socket recive: ${socketEvent}: ${JSON.stringify(msg)}`, "color:#ffe000");
              }

              console.log(msg);
              callbackData(msg);
            });
          }
        }

        off(socketEvent, listen) {
          this.socket && this.socket.off(socketEvent, listen);
        }

        emit(socketEvent, data) {
          if (!LOGS_SKIPS.includes(socketEvent)) {
            (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
              error: Error()
            }), LogUtil) : LogUtil).logS("%c" + `-->>socket send: ${socketEvent}: ${JSON.stringify(data)}`, "color:#00ff0c");
          } // if (!this.isConnected) {
          //   NotifyUtil.instance.emit(BNotifyType.SHOW_DISCONNECT);
          //   return;
          // }


          console.log(data);
          this.socket && this.socket.emit(socketEvent, data);
        }

        close() {
          (_crd && LogUtil === void 0 ? (_reportPossibleCrUseOfLogUtil({
            error: Error()
          }), LogUtil) : LogUtil).logS("%c" + `-->>socket colose:`, "color:#f70707");
          this.socket && this.socket.disconnect();
        }

      }, _class2._instance = null, _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=a3b4f21c869b2fd8be3f36a720025fa4ea1d76dc.js.map