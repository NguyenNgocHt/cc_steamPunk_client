System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, _dec, _class, _crd, ccclass, property, ConnectSeverServiceMock;

  function _reportPossibleCrUseOfIConnectSeverServiceMock(extras) {
    _reporterNs.report("IConnectSeverServiceMock", "../interfaces/Mock_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fdd5ahGoPVPP4jKPUZQ4abO", "ConnectSeverServiceMock", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ConnectSeverServiceMock", ConnectSeverServiceMock = (_dec = ccclass('ConnectSeverService'), _dec(_class = class ConnectSeverServiceMock {}) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=36980f397a879be579d8e135a6981718b8f7551e.js.map