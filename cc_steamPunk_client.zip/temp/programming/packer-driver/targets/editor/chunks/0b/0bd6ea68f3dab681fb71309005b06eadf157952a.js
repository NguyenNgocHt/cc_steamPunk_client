System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, sys, Label, ProgressBar, ScreenManager, PATH, Path, LanguageManager, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, LoadingBarView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfILoadingController(extras) {
    _reporterNs.report("ILoadingController", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfILoadingView_loading(extras) {
    _reporterNs.report("ILoadingView_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfScreenManager(extras) {
    _reporterNs.report("ScreenManager", "../../../../../../framework/ui/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPATH(extras) {
    _reporterNs.report("PATH", "../../../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBasePopup(extras) {
    _reporterNs.report("BasePopup", "../../../../../../framework/ui/BasePopup", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPopupNotify(extras) {
    _reporterNs.report("PopupNotify", "../../../popups/PopupNotify", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPath(extras) {
    _reporterNs.report("Path", "../../../common/Path", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLanguageManager(extras) {
    _reporterNs.report("LanguageManager", "../../../../../../framework/languge/LanguageManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      sys = _cc.sys;
      Label = _cc.Label;
      ProgressBar = _cc.ProgressBar;
    }, function (_unresolved_2) {
      ScreenManager = _unresolved_2.default;
    }, function (_unresolved_3) {
      PATH = _unresolved_3.PATH;
    }, function (_unresolved_4) {
      Path = _unresolved_4.Path;
    }, function (_unresolved_5) {
      LanguageManager = _unresolved_5.LanguageManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f828cogFolGB5Zsa3nLv5Q7", "LoadingBarView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'sys', 'Label']);

      __checkObsolete__(['ProgressBar']);

      __checkObsolete__(['WebView']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LoadingBarView", LoadingBarView = (_dec = ccclass("LoadingBarView"), _dec2 = property(ProgressBar), _dec3 = property(Label), _dec4 = property(Label), _dec(_class = (_class2 = class LoadingBarView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "loadingProgress", _descriptor, this);

          _initializerDefineProperty(this, "LbLoading", _descriptor2, this);

          _initializerDefineProperty(this, "LbCache", _descriptor3, this);

          this._loadingControler = null;
          this._strLoad = [".", "..", "..."];
          this._indexStr = 0;
          this._timeAnim = 0;
        }

        onLoad() {
          console.log("loading view", this.node);
        }

        init(loadingController) {
          this._loadingControler = loadingController;
        }

        startView() {
          this.loadingProgress.progress = 0;
          this.updateProgressBar(0);
          (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
            error: Error()
          }), ScreenManager) : ScreenManager).instance.assetBundle.load((_crd && Path === void 0 ? (_reportPossibleCrUseOfPath({
            error: Error()
          }), Path) : Path).POPUP_NOTIFY, (err, data) => {
            if (!err) {
              this._loadingControler.startLoadingAsset();
            } else {
              console.log("load error  " + err + " _loadAsset");

              if (sys.isBrowser) {
                alert("Không có kết nối, vui lòng thử lại");
              }
            }
          });
        }

        updateProgressBar(updatePoint) {
          this.loadingProgress.progress = updatePoint;
          this.showProgressPercentage(updatePoint);
        }

        showProgressPercentage(updatePoint) {
          this.LbLoading.node.active = true;
          let p = Math.round(updatePoint * 100);
          let textLoading = (_crd && LanguageManager === void 0 ? (_reportPossibleCrUseOfLanguageManager({
            error: Error()
          }), LanguageManager) : LanguageManager).getText("loading");

          if (!textLoading || textLoading.length <= 0) {
            textLoading = "Loading Resources";
          }

          let textLoading1 = `${textLoading} [${p}%]${this._strLoad[this._indexStr]}`;
          this.LbLoading.string = textLoading1;
        }

        getProgressBar() {
          return this.loadingProgress.progress;
        }

        showMessenger(mesenger) {
          (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
            error: Error()
          }), ScreenManager) : ScreenManager).instance.showPopupFromPrefabName((_crd && PATH === void 0 ? (_reportPossibleCrUseOfPATH({
            error: Error()
          }), PATH) : PATH).POPUP_NOTIFY, popup => {
            let popupDisplay = popup;
            popupDisplay.setupPopup(mesenger, [() => {
              (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
                error: Error()
              }), ScreenManager) : ScreenManager).instance.hidePopup(true);

              this._loadingControler.startLoadingAsset();
            }, () => {
              (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
                error: Error()
              }), ScreenManager) : ScreenManager).instance.hidePopup(true);
            }]);
          }, true, true, false);
        }

        onClick_screenChange() {
          this._loadingControler.screenChange();
        }

        update(deltaTime) {
          if (Date.now() - this._timeAnim > 500) {
            this._indexStr++;
            this._indexStr = this._indexStr % 3;
            this._timeAnim = Date.now();
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "loadingProgress", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "LbLoading", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "LbCache", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0bd6ea68f3dab681fb71309005b06eadf157952a.js.map