System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c51f9D6CoZJmI5w2JZd146g", "MockConfigData", undefined); //game info data
      //BetResult data


      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0b51451da373d8b13eb7e699aadbaf9df9f5e3ed.js.map