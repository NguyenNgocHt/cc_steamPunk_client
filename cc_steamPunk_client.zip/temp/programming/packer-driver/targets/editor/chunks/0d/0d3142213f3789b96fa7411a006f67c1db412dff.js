System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, _dec, _class, _class2, _crd, ccclass, property, LogUtil;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8c080B/W01Fw4Kc43FWdcpa", "LogUtil", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LogUtil", LogUtil = (_dec = ccclass("LogUtil"), _dec(_class = (_class2 = class LogUtil extends Component {
        static logS(str, color) {
          if (LogUtil._isS()) {
            console.log(str, color);
          }
        }

        static logRequest(...parms) {
          if (LogUtil._isS()) {
            console.log(parms);
          }
        }

        static log(...parms) {
          if (LogUtil._isS()) {
            console.log(parms);
          }
        }

        static error(...parms) {
          if (LogUtil._isS()) {
            console.error(parms);
          }
        }

        static warn(...parms) {
          if (LogUtil._isS()) {
            console.warn(parms);
          }
        }

        static _isS() {
          let url = window.location.href;
          let iUrl = new URL(url);
          let log = iUrl.searchParams.get("log");

          if (LogUtil.ENV.toUpperCase() == "DEV" || LogUtil.ENV.toUpperCase() == "STAGING" || url.indexOf("localhost") || url.indexOf(":7456") || log == "hcm123456") {
            return true;
          }

          return false;
        }

      }, _class2.ENV = "prod", _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0d3142213f3789b96fa7411a006f67c1db412dff.js.map