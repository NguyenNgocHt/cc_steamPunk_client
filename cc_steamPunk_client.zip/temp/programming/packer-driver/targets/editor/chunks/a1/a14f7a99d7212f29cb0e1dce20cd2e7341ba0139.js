System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6", "__unresolved_7", "__unresolved_8"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Prefab, AudioSevice, AssetsSevice, LoadingBarView, ScreenManager, PATH, languageService, StorageUtil, BStorageKey, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, LoadingBarControler;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfILoadingController(extras) {
    _reporterNs.report("ILoadingController", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIAssetsSevice_loading(extras) {
    _reporterNs.report("IAssetsSevice_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIAudioSevice_loading(extras) {
    _reporterNs.report("IAudioSevice_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfILoadingView_loading(extras) {
    _reporterNs.report("ILoadingView_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfILanguegeService(extras) {
    _reporterNs.report("ILanguegeService", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioSevice(extras) {
    _reporterNs.report("AudioSevice", "../sevice/AudioSevice", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAssetsSevice(extras) {
    _reporterNs.report("AssetsSevice", "../sevice/AssetsSevice", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLoadingBarView(extras) {
    _reporterNs.report("LoadingBarView", "../view/LoadingBarView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfScreenManager(extras) {
    _reporterNs.report("ScreenManager", "../../../../../../framework/ui/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBaseScreen(extras) {
    _reporterNs.report("BaseScreen", "../../../../../../framework/ui/BaseScreen", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPATH(extras) {
    _reporterNs.report("PATH", "../../../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOflanguageService(extras) {
    _reporterNs.report("languageService", "../sevice/languageService", _context.meta, extras);
  }

  function _reportPossibleCrUseOfStorageUtil(extras) {
    _reporterNs.report("StorageUtil", "../../../../../../framework/utils/StorageUtil", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBStorageKey(extras) {
    _reporterNs.report("BStorageKey", "../../../common/Enum", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      AudioSevice = _unresolved_2.AudioSevice;
    }, function (_unresolved_3) {
      AssetsSevice = _unresolved_3.AssetsSevice;
    }, function (_unresolved_4) {
      LoadingBarView = _unresolved_4.LoadingBarView;
    }, function (_unresolved_5) {
      ScreenManager = _unresolved_5.default;
    }, function (_unresolved_6) {
      PATH = _unresolved_6.PATH;
    }, function (_unresolved_7) {
      languageService = _unresolved_7.languageService;
    }, function (_unresolved_8) {
      StorageUtil = _unresolved_8.StorageUtil;
    }, function (_unresolved_9) {
      BStorageKey = _unresolved_9.BStorageKey;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f0099ACE5lHQoUTAMrRst1y", "LoadingBarController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Prefab', 'tween']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LoadingBarControler", LoadingBarControler = (_dec = ccclass("LoadingBarControler"), _dec2 = property(_crd && LoadingBarView === void 0 ? (_reportPossibleCrUseOfLoadingBarView({
        error: Error()
      }), LoadingBarView) : LoadingBarView), _dec(_class = (_class2 = class LoadingBarControler extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "LoadingBarView", _descriptor, this);

          this._audioSevice = null;
          this._assetsSevice = null;
          this._languageService = null;
          this._loadingView = null;
          this.progressCurrent = 0;
        }

        onLoad() {
          this.init(this.LoadingBarView);
        }

        start() {
          this.loadingStart();
        }

        init(iloadingView) {
          this.init_isMe(iloadingView);
          this.init_audioSevice();
          this.init_assetsSevice();
          this.init_loadingView();
        }

        init_isMe(iLoadingView) {
          this._audioSevice = new (_crd && AudioSevice === void 0 ? (_reportPossibleCrUseOfAudioSevice({
            error: Error()
          }), AudioSevice) : AudioSevice)();
          this._assetsSevice = new (_crd && AssetsSevice === void 0 ? (_reportPossibleCrUseOfAssetsSevice({
            error: Error()
          }), AssetsSevice) : AssetsSevice)();
          this._languageService = new (_crd && languageService === void 0 ? (_reportPossibleCrUseOflanguageService({
            error: Error()
          }), languageService) : languageService)();
          this._loadingView = iLoadingView;
        }

        init_audioSevice() {
          this._audioSevice.init();
        }

        init_assetsSevice() {
          this._assetsSevice.init(this);
        }

        init_loadingView() {
          this._loadingView.init(this);
        } //controler audio sevice


        loadingStart() {
          this._audioSevice.loadingAudio();

          this._languageService.loadingLanguage();

          this.startLoadingView();
        }

        initAudios() {
          this._audioSevice.initAudio();
        } //controler assets sevice


        startLoadingAsset() {
          this._assetsSevice.loadingAssets();
        }

        getAudiosFromAudioSevice() {
          let audios = this._audioSevice.getAudios();

          this._assetsSevice.setAudiosData(audios);
        } //controler loading view


        updateLoadingView_progressBar(updatePoint) {
          this._loadingView.updateProgressBar(updatePoint);
        }

        showPopupMessage(message) {
          this._loadingView.showMessenger(message);
        }

        startLoadingView() {
          this._loadingView.startView();
        }

        checkResultLoadingAssets() {
          let resultLoadingLanguage = this._languageService.getResultLoadLanguage();

          let languageData = (_crd && StorageUtil === void 0 ? (_reportPossibleCrUseOfStorageUtil({
            error: Error()
          }), StorageUtil) : StorageUtil).instance.read((_crd && BStorageKey === void 0 ? (_reportPossibleCrUseOfBStorageKey({
            error: Error()
          }), BStorageKey) : BStorageKey).LANGUAGE_DATA);

          if (resultLoadingLanguage && languageData) {
            console.log("next landing view");
            console.log("languageData", JSON.parse(languageData));
            this, setTimeout(() => {
              this.screenChange();
            }, 1000);
          }
        }

        screenChange() {
          console.log("load home screen");
          let play_screen = (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
            error: Error()
          }), ScreenManager) : ScreenManager).instance.assetBundle.get((_crd && PATH === void 0 ? (_reportPossibleCrUseOfPATH({
            error: Error()
          }), PATH) : PATH).PLAY_SCREEN, Prefab);
          console.log("play screen", play_screen);
          (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
            error: Error()
          }), ScreenManager) : ScreenManager).instance.pushScreen(play_screen, screen => {}, true);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "LoadingBarView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=a14f7a99d7212f29cb0e1dce20cd2e7341ba0139.js.map