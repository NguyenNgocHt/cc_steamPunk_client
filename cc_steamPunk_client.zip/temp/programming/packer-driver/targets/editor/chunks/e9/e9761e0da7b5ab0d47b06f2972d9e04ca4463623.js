System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, EventBus, GAME_EVENT, sys, LOCAL_STORAGE_KEY_WORD, _dec, _class, _crd, ccclass, property, GameInfo;

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD(extras) {
    _reporterNs.report("LOCAL_STORAGE_KEY_WORD", "./Path", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameInfo(extras) {
    _reporterNs.report("IGameInfo", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      sys = _cc.sys;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
    }, function (_unresolved_3) {
      GAME_EVENT = _unresolved_3.GAME_EVENT;
    }, function (_unresolved_4) {
      LOCAL_STORAGE_KEY_WORD = _unresolved_4.LOCAL_STORAGE_KEY_WORD;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "47cf1i57ZRLZrOD3hzfTlLh", "GameInfo", undefined);

      __checkObsolete__(['_decorator']);

      __checkObsolete__(['sys']);

      __checkObsolete__(['JsonAsset']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("default", GameInfo = (_dec = ccclass("GameInfo"), _dec(_class = class GameInfo {
        init() {
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_TO_GAME_INFO, this.setGameInfo.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_TO_GAME_INFO, this.setGameInfo.bind(this));
        }

        setGameInfo(data) {
          console.log("come in game info", data);
          let gameInfo = null;
          gameInfo = {
            balance: data.balance,
            betlines: data.betlines,
            currency: data.currency,
            settings: data.settings,
            pending: data.pending,
            denominations: data.denominations,
            username: data.username
          };
          sys.localStorage.setItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).GAME_INFO, JSON.stringify(gameInfo));
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e9761e0da7b5ab0d47b06f2972d9e04ca4463623.js.map