System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, sp, SpiningAnim, SpriteFrame, Sprite, Vec3, EventBus, GAME_EVENT, tween, Tween, Label, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _crd, ccclass, property, BtnBetGroupView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSpiningAnim(extras) {
    _reporterNs.report("SpiningAnim", "../../../../animControl/SpiningAnim", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      sp = _cc.sp;
      SpriteFrame = _cc.SpriteFrame;
      Sprite = _cc.Sprite;
      Vec3 = _cc.Vec3;
      tween = _cc.tween;
      Tween = _cc.Tween;
      Label = _cc.Label;
    }, function (_unresolved_2) {
      SpiningAnim = _unresolved_2.SpiningAnim;
    }, function (_unresolved_3) {
      EventBus = _unresolved_3.EventBus;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "6e8c3eaZQ1PqJRFDCZOaIUd", "BtnBetGroupView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'sp']);

      __checkObsolete__(['SpriteFrame']);

      __checkObsolete__(['Sprite']);

      __checkObsolete__(['EventTouch']);

      __checkObsolete__(['Vec3']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['Tween']);

      __checkObsolete__(['Label']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BtnBetGroupView", BtnBetGroupView = (_dec = ccclass("BtnBetGroupView"), _dec2 = property(Node), _dec3 = property(_crd && SpiningAnim === void 0 ? (_reportPossibleCrUseOfSpiningAnim({
        error: Error()
      }), SpiningAnim) : SpiningAnim), _dec4 = property(_crd && SpiningAnim === void 0 ? (_reportPossibleCrUseOfSpiningAnim({
        error: Error()
      }), SpiningAnim) : SpiningAnim), _dec5 = property(SpriteFrame), _dec6 = property(SpriteFrame), _dec7 = property(Node), _dec8 = property(Label), _dec9 = property(sp.Skeleton), _dec10 = property(sp.Skeleton), _dec11 = property(sp.Skeleton), _dec(_class = (_class2 = class BtnBetGroupView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBet", _descriptor, this);

          _initializerDefineProperty(this, "union", _descriptor2, this);

          _initializerDefineProperty(this, "bigGear", _descriptor3, this);

          _initializerDefineProperty(this, "btnBetPress", _descriptor4, this);

          _initializerDefineProperty(this, "btnBetNetural", _descriptor5, this);

          _initializerDefineProperty(this, "winFreeSpin", _descriptor6, this);

          _initializerDefineProperty(this, "lbFreeSpin", _descriptor7, this);

          _initializerDefineProperty(this, "animBetPress", _descriptor8, this);

          _initializerDefineProperty(this, "animBetRound", _descriptor9, this);

          _initializerDefineProperty(this, "tapAnim", _descriptor10, this);

          this.isPressButton = false;
          this.originPosNodeUnion = new Vec3(0, 0, 0);
          this.freeSpinValue = 0;
          this.timeScale = 1;
        }

        start() {
          this.init();
          this.registerEvent();
        }

        init() {
          this.initAnim();
          this.initNode();
        }

        initNode() {
          this.winFreeSpin.active = false;
          this.lbFreeSpin.node.active = false;
        }

        initAnim() {
          this.tapAnim.node.active = false;
          this.animBetRound.node.active = false;
          this.animBetPress.node.active = false;
          this.animBetPress.setCompleteListener(() => {
            this.animBetPress.node.active = false;
          });
        }

        registerEvent() {
          this.btnBet.on(Node.EventType.TOUCH_START, this.onBetTouchDown.bind(this));
          this.btnBet.on(Node.EventType.TOUCH_END, this.onBetTouchEnd.bind(this));
        }

        onClickBtnBet() {
          if (!this.isPressButton) {
            this.isPressButton = true;
            this.changeBetBtnWhenPress;
            this.sendActionToBetControl();
          }
        }

        setBtnBetPressStatus(status) {
          this.isPressButton = status;
        }

        startGameEffect() {
          this.startSpinBigGear();
          this.startAnimBetRound();
        }

        startSpinBigGear() {
          this.bigGear.spinningStart();
        }

        startAnimBetRound() {
          this.animBetRound.node.active = true;
        }

        startSpinSmallGear() {
          this.union.spinningStart();
        }

        stopSpinGear() {
          this.union.spinningStop();
        }

        changeBetBtnWhenPress() {
          let posUnion = this.union.node.getWorldPosition();
          this.originPosNodeUnion = posUnion;
          let spriteNode = this.btnBet.getComponent(Sprite);
          spriteNode.spriteFrame = this.btnBetPress;
          this.animBetPress.node.active = true;
          this.animBetPress.setAnimation(0, "Sprite", false);
          Tween.stopAllByTarget(this.node);
          tween(this.node).delay(0.1).call(() => {
            this.animBetPress.setAnimation(0, "Sprite", false);
          }).delay(0.1).call(() => {
            this.animBetPress.setAnimation(0, "Sprite", false);
          }).start();
          this.union.node.worldPosition = new Vec3(posUnion.x, 125, 0);
          this.startSpinSmallGear();
          this.bigGear.changeTimeLoopSpinning(2);
        }

        changeTimeLoopSpiningBigGrear(timeLoop) {
          this.bigGear.changeTimeLoopSpinning(timeLoop);
        }

        setTimeScale(timeScale) {
          this.timeScale = timeScale;
        }

        changeBetBtnWhenNetural() {
          this.isPressButton = false;
          this.stopSpinGear();
          this.bigGear.changeTimeLoopSpinning(5);
          let spriteNode = this.btnBet.getComponent(Sprite);
          spriteNode.spriteFrame = this.btnBetNetural;
          this.union.node.worldPosition = new Vec3(this.originPosNodeUnion.x, 180, 0);
          this.checkFreeSpineValue();
        }

        onBetTouchDown(event) {
          if (!this.isPressButton) {
            this.startSpinSmallGear();
            this.bigGear.changeTimeLoopSpinning(2);
            this.changeBetBtnWhenPress();
          }
        }

        onBetTouchEnd(event) {}

        sendActionToBetControl() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_BET_BUTTON, this.timeScale);
        }

        showTextWinFreeSpin() {
          this.winFreeSpin.active = true;
          setTimeout(() => {
            this.winFreeSpin.active = false;
          }, 2000);
        }

        showFreeSpinValue(value) {
          this.freeSpinValue = value;
          this.setEffectNode(value);
        }

        setEffectNode(value) {
          tween(this.lbFreeSpin.node).to(0.1, {
            scale: new Vec3(1.3, 1.3, 1.3)
          }, {
            easing: "backInOut"
          }).call(() => {
            this.lbFreeSpin.node.active = true;
            this.lbFreeSpin.string = value.toString();
          }).to(0.5, {
            scale: new Vec3(1, 1, 1)
          }, {
            easing: "backOut"
          }).start();
        }

        checkFreeSpineValue() {
          if (this.freeSpinValue == 0) {
            this.lbFreeSpin.string = "";
            this.lbFreeSpin.node.active = false;
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBet", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "union", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "bigGear", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btnBetPress", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "btnBetNetural", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "winFreeSpin", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "lbFreeSpin", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "animBetPress", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "animBetRound", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "tapAnim", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=99e82ee13b8299cd3ee4b24127efae8b685c0e6f.js.map