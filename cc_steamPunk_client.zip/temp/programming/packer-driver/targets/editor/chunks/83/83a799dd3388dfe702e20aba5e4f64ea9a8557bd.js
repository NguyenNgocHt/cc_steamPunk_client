System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, HistoryContentView, _decorator, Component, Node, tween, Vec3, EventBus, GAME_EVENT, Prefab, instantiate, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, PopupHistoryView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfHistoryContentView(extras) {
    _reporterNs.report("HistoryContentView", "./HistoryContentView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfHistoryData(extras) {
    _reporterNs.report("HistoryData", "../../dataModel/HistoryDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
    }, function (_unresolved_2) {
      HistoryContentView = _unresolved_2.HistoryContentView;
    }, function (_unresolved_3) {
      EventBus = _unresolved_3.EventBus;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f13ffxfAntCaoxZHnJdHJbd", "PopupHistoryView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'tween', 'Vec3']);

      __checkObsolete__(['Prefab']);

      __checkObsolete__(['instantiate']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PopupHistoryView", PopupHistoryView = (_dec = ccclass("PopupHistoryView"), _dec2 = property(Node), _dec3 = property(Prefab), _dec4 = property(Node), _dec(_class = (_class2 = class PopupHistoryView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "riskLevelNode", _descriptor, this);

          _initializerDefineProperty(this, "historyConten", _descriptor2, this);

          _initializerDefineProperty(this, "content", _descriptor3, this);
        }

        setNodeToStartPoint(startNode) {
          let startPos = startNode.getWorldPosition();
          this.node.setWorldPosition(startPos.x, startPos.y, 0);
        }

        moveNodeToTagetPoint(tagetNode, timeMove) {
          let tagetPos = tagetNode.getWorldPosition();
          tween(this.node).to(timeMove, {
            worldPosition: new Vec3(tagetPos.x, tagetPos.y, 0)
          }).start();
        }

        onClickClosePopup() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLOSE_HISTORY_POPUP);
        }

        showHistoryContent(dataList) {
          let historyDataList = dataList;
          let contentlength = this.content.children.length;
          console.log("contentlength", contentlength);

          if (contentlength == 30) {
            this.content.children.shift();
            contentlength = this.content.children.length;
          }

          for (let i = 0; i < historyDataList.length; i++) {
            if (!historyDataList[i].risk) {
              this.riskLevelNode.active = false;
            } else {
              this.riskLevelNode.active = true;
            }

            if (i >= contentlength) {
              let historyContentNode = instantiate(this.historyConten);

              if (historyContentNode) {
                let historyContentView = historyContentNode.getComponent(_crd && HistoryContentView === void 0 ? (_reportPossibleCrUseOfHistoryContentView({
                  error: Error()
                }), HistoryContentView) : HistoryContentView);
                historyContentView.updateHistoryContent(historyDataList[i]);
                this.content.addChild(historyContentNode);
              }
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "riskLevelNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "historyConten", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "content", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=83a799dd3388dfe702e20aba5e4f64ea9a8557bd.js.map