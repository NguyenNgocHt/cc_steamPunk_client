System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, SlotController, SpinningMachineController, EventBus, GAME_EVENT, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, SlotMachineController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSlotController(extras) {
    _reporterNs.report("SlotController", "./SlotController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSpinningMachineController(extras) {
    _reporterNs.report("SpinningMachineController", "./SpinningMachineController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      SlotController = _unresolved_2.SlotController;
    }, function (_unresolved_3) {
      SpinningMachineController = _unresolved_3.SpinningMachineController;
    }, function (_unresolved_4) {
      EventBus = _unresolved_4.EventBus;
    }, function (_unresolved_5) {
      GAME_EVENT = _unresolved_5.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "113c1SqZgpJKaEfAHoxSkI5", "SlotMachineController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SlotMachineController", SlotMachineController = (_dec = ccclass("SlotMachineController"), _dec2 = property(_crd && SlotController === void 0 ? (_reportPossibleCrUseOfSlotController({
        error: Error()
      }), SlotController) : SlotController), _dec3 = property(_crd && SpinningMachineController === void 0 ? (_reportPossibleCrUseOfSpinningMachineController({
        error: Error()
      }), SpinningMachineController) : SpinningMachineController), _dec(_class = (_class2 = class SlotMachineController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "slotControl", _descriptor, this);

          _initializerDefineProperty(this, "spinningMachineControl", _descriptor2, this);
        }

        onLoad() {
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_POOL_MODEL, this.initSlotGroup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_TUBO_BUTTON, this.setPlayTubo.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_POOL_MODEL, this.initSlotGroup.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_TUBO_BUTTON, this.setPlayTubo.bind(this));
        }

        initSlotGroup(poolControl) {
          console.log("init slot group");
          this.slotControl.initSymbolGroup(poolControl);
        }

        setBetResultData(result) {
          this.slotControl.getBetResult(result);
          this.spinningMachineControl.showPositionSymbols();
        }

        setPlayTubo(valueIndex) {
          if (valueIndex == 0) {
            this.spinningMachineControl.setTimeScale(1);
          } else if (valueIndex == 1) {
            this.spinningMachineControl.setTimeScale(2);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "slotControl", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "spinningMachineControl", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b7a43d363471fcc77de01ce850ecef35deb483c0.js.map