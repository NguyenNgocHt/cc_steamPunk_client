System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Label, _decorator, Component, Color, Sprite, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _crd, ccclass, property, HistoryContentView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfHistoryData(extras) {
    _reporterNs.report("HistoryData", "../../dataModel/HistoryDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIHistoryContentView(extras) {
    _reporterNs.report("IHistoryContentView", "../../interfaces/gamePlay/bets_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Label = _cc.Label;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Color = _cc.Color;
      Sprite = _cc.Sprite;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "212d06eXwtNtZZS13jqJmlm", "HistoryContentView", undefined);

      __checkObsolete__(['labelAssembler']);

      __checkObsolete__(['Label']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['color']);

      __checkObsolete__(['Color']);

      __checkObsolete__(['Sprite']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("HistoryContentView", HistoryContentView = (_dec = ccclass("HistoryContentView"), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Label), _dec7 = property(Label), _dec8 = property(Label), _dec9 = property(Sprite), _dec(_class = (_class2 = class HistoryContentView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lbDay", _descriptor, this);

          _initializerDefineProperty(this, "lbTime", _descriptor2, this);

          _initializerDefineProperty(this, "lbBetId", _descriptor3, this);

          _initializerDefineProperty(this, "lbRiskLevel", _descriptor4, this);

          _initializerDefineProperty(this, "lbBestAmount", _descriptor5, this);

          _initializerDefineProperty(this, "lbMuntiplier", _descriptor6, this);

          _initializerDefineProperty(this, "lbPayout", _descriptor7, this);

          _initializerDefineProperty(this, "bgMultiplier", _descriptor8, this);

          this.maxLength = 10;
          this.green = new Color(72, 188, 25, 255);
          this.red = new Color(245, 122, 127, 255);
        }

        updateHistoryContent(historyData) {
          this.lbDay.string = historyData.lbDate;
          this.lbTime.string = historyData.lbTime;
          this.lbBetId.string = this.checkString(historyData.betID.toString());
          this.lbBestAmount.string = historyData.betAmount.toFixed(4);

          if (!historyData.risk) {
            this.lbRiskLevel.node.active = false;
          } else {
            this.lbRiskLevel.node.active = true;
            this.lbRiskLevel.string = historyData.risk.toString();
          }

          this.lbMuntiplier.string = historyData.multiplier.toFixed(4);
          this.lbPayout.string = historyData.payout.toFixed(4);

          if (historyData.payout == 0) {
            this.lbPayout.color = this.red;
            this.bgMultiplier.color = this.red;
          } else {
            this.lbPayout.color = this.green;
            this.bgMultiplier.color = this.green;
          }
        }

        checkString(text) {
          let slicedText = "";

          for (let i = 0; i < text.length; i += this.maxLength) {
            slicedText += text.slice(i, i + this.maxLength) + "\n";
          }

          return slicedText;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lbDay", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lbTime", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lbBetId", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "lbRiskLevel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "lbBestAmount", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "lbMuntiplier", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "lbPayout", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "bgMultiplier", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e8e68f29b5b8ed869868e3c73d1bbd5f5c4cf182.js.map