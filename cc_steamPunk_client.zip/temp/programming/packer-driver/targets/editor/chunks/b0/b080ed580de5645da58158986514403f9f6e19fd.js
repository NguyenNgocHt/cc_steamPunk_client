System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, EventBus, GAME_EVENT, EditBox, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, BetAmoutGroupView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSettingsData(extras) {
    _reporterNs.report("SettingsData", "../../../../dataModel/GameInfoDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      EditBox = _cc.EditBox;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
    }, function (_unresolved_3) {
      GAME_EVENT = _unresolved_3.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "85ae5yq17dMppVqwRDQe9yx", "BetAmoutGroupView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['EditBox']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BetAmoutGroupView", BetAmoutGroupView = (_dec = ccclass("BetAmoutGroupView"), _dec2 = property(EditBox), _dec(_class = (_class2 = class BetAmoutGroupView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lbLineValue", _descriptor, this);

          this.defaultLineValue = 0;
          this.defaultListDenominationsIndex = 0;
          this._listDenominations = [];
          this._listSettings = null;
          this.currentBetLineValue = 0;
          this._listDenominationLenght = 0;
          this._listDenominationsIndexMax = 14;
          this._listDenominationsIndexMin = 0;
        }

        start() {
          this.scheduleOnce(function () {
            this.callGetGameInfo();
            this.initDefaultValue();
          }, 1);
        }

        callGetGameInfo() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).GET_GAME_INFO);
        }

        initDefaultValue() {
          this.defaultLineValue = this._listDenominations[0];
          this.currentBetLineValue = this.defaultLineValue;
          this.lbLineValue.string = this.defaultLineValue.toString();
          this._listDenominationLenght = this._listDenominations.length;
        }

        getListDenominations(data) {
          this._listDenominations = data;
        }

        getListSettings(data) {
          this._listSettings = data;
        }

        onClickAddLineValue() {
          this.onChangeBetValue(function computeNewLineValue(defaultListDenominationsIndex, listDenominationLenght, listDenominanyationsIndexMax, listDenominationsIndexMin) {
            defaultListDenominationsIndex += 1;
            defaultListDenominationsIndex = defaultListDenominationsIndex >= listDenominationLenght - 1 ? listDenominationLenght - 1 : defaultListDenominationsIndex;
            return defaultListDenominationsIndex;
          });
        }

        onClickSubLineValue() {
          this.onChangeBetValue(function computeNewLineValue(defaultListDenominationsIndex, listDenominationLenght, listDenominationsIndexMax, listDenominationsIndexMin) {
            defaultListDenominationsIndex -= 1;
            defaultListDenominationsIndex = defaultListDenominationsIndex <= 0 ? 0 : defaultListDenominationsIndex;
            return defaultListDenominationsIndex;
          });
        }

        onClickMinLineValue() {
          this.onChangeBetValue(function computeNewLineValue(defaultListDenominationsIndex, listDenominationLenght, listDenominationsIndexMax, listDenominationsIndexMin) {
            return listDenominationsIndexMin;
          });
        }

        oncClickMaxLineValue() {
          this.onChangeBetValue(function computeNewLineValue(defaultListDenominationsIndex, listDenominationLenght, listDenominationsIndexMax, listDenominationsIndexMin) {
            return listDenominationsIndexMax;
          });
        }

        onChangeBetValue(computeNewLineValue) {
          this.defaultListDenominationsIndex = computeNewLineValue(this.defaultListDenominationsIndex, this._listDenominationLenght, this._listDenominationsIndexMax, this._listDenominationsIndexMin);
          this.currentBetLineValue = this._listDenominations[this.defaultListDenominationsIndex];
          this.lbLineValue.string = this.currentBetLineValue.toString();
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).CURRENT_BET_VALUE, this.currentBetLineValue);
        }

        getCurrentBetLineValue() {
          return this.currentBetLineValue;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lbLineValue", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b080ed580de5645da58158986514403f9f6e19fd.js.map