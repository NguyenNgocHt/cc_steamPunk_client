System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, EffectLayerView, EventBus, GAME_EVENT, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, EffectLayerController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEffectLayerView(extras) {
    _reporterNs.report("EffectLayerView", "../view/EffectLayerView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPayLinesDaTa(extras) {
    _reporterNs.report("PayLinesDaTa", "../../../../dataModel/BetDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      EffectLayerView = _unresolved_2.EffectLayerView;
    }, function (_unresolved_3) {
      EventBus = _unresolved_3.EventBus;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "9103aFrIbhJhZUiP2A3smrW", "EffectLayerController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("EffectLayerController", EffectLayerController = (_dec = ccclass("EffectLayerController"), _dec2 = property(_crd && EffectLayerView === void 0 ? (_reportPossibleCrUseOfEffectLayerView({
        error: Error()
      }), EffectLayerView) : EffectLayerView), _dec(_class = (_class2 = class EffectLayerController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "effectLayerView", _descriptor, this);
        }

        onLoad() {
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_CURRENT_BET_LINE, this.showBetLine.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_BET_BUTTON, this.setEffectWhenOnClickBetBnt.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SHOW_EFFECT_WIN_GAME, this.setEffectWinGame.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_SPIN_EFFECT_VER2, this.setSpinEffectStop.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ONCLICK_ADD_LINE, this.showBetLine.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_BET_BUTTON, this.setEffectWhenOnClickBetBnt.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SHOW_EFFECT_WIN_GAME, this.setEffectWinGame.bind(this));
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_SPIN_EFFECT_VER2, this.setSpinEffectStop.bind(this));
        }

        start() {
          this.initEffectStartGame();
        }

        initEffectStartGame() {
          this.effectLayerView.initStartGame();
        }

        onAllEffect() {
          this.effectLayerView.openingEnding();
        }

        showBetLine(totalLines) {
          this.effectLayerView.showLineSelectView(totalLines);
        }

        setEffectWhenOnClickBetBnt(timeScale) {
          this.offAllLine();
          this.onSpinEffectV1(timeScale);
        }

        offAllLine() {
          this.effectLayerView.offAllLines();
        }

        setSpinEffectStop(timeScale) {
          this.effectLayerView.onSpinEffectV2(timeScale);
        }

        onSpinEffectV1(timeScale) {
          this.scheduleOnce(function () {
            this.effectLayerView.onSpinEffectV1();
          }, 0.75 / timeScale);
        }

        setEffectWinGame(payLineList, timeScale) {
          for (let i = 0; i < payLineList.length; i++) {
            let payline = payLineList[i];

            if (payline) {
              this.effectLayerView.onEffectWinGame(payline.payline, timeScale);
            }
          }
        }

        showWinGameBonus(coinBonus, multiplier, tagetNode) {
          this.effectLayerView.showWinGameBonus(coinBonus, multiplier, tagetNode);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "effectLayerView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=f2f7bb1ef304fc314970fcb9428a147c616fd18d.js.map