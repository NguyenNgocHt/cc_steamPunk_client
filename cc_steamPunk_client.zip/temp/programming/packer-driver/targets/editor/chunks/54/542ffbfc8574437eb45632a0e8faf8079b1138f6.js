System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, tween, _decorator, Component, Node, sp, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, JackpotAnimView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      tween = _cc.tween;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      sp = _cc.sp;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "279ddTOR8dEc7lGkTmQ+/s4", "JackpotAnimView", undefined);

      __checkObsolete__(['tween']);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'sp']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("JackpotAnimView", JackpotAnimView = (_dec = ccclass("JackpotAnimView"), _dec2 = property(sp.Skeleton), _dec3 = property(Node), _dec(_class = (_class2 = class JackpotAnimView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "jackpotAnim", _descriptor, this);

          _initializerDefineProperty(this, "objTextNode", _descriptor2, this);
        }

        start() {
          this.offAllAnim();
        }

        offAllAnim() {
          this.jackpotAnim.node.active = false;
          this.objTextNode.active = false;
          this.jackpotAnim.setCompleteListener(() => {
            this.jackpotAnim.node.active = false;
          });
        }

        startJackpotAnim() {
          this.jackpotAnim.node.active = true;
          this.jackpotAnim.setAnimation(0, "animtion0", false);
          this.showJackpotText();
        }

        showJackpotText() {
          tween(this.node).delay(0.7).call(() => {
            this.objTextNode.active = true;
          }).delay(1.8).call(() => {
            this.objTextNode.active = false;
          }).start();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "jackpotAnim", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "objTextNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=542ffbfc8574437eb45632a0e8faf8079b1138f6.js.map