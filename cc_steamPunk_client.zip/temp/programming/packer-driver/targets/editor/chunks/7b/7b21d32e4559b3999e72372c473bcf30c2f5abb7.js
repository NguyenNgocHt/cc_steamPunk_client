System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _cc, _class, _crd, cc, ccclass, property, ScrollContent;

  function _reportPossibleCrUseOfScrollView(extras) {
    _reporterNs.report("ScrollView", "./ScrollView", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc2) {
      _cclegacy = _cc2.cclegacy;
      __checkObsolete__ = _cc2.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc2.__checkObsoleteInNamespace__;
      _cc = _cc2;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c5d2c1Fn1FFJptsNankFxAN", "ScrollContent", undefined);

      cc = __checkObsoleteInNamespace__(_cc);
      ({
        ccclass,
        property
      } = cc._decorator);

      _export("default", ScrollContent = ccclass(_class = class ScrollContent extends cc.Component {
        constructor(...args) {
          super(...args);
          this._scrollView = null;
        }

        get scrollView() {
          return this._scrollView;
        }

        set scrollView(value) {
          this._scrollView = value;
        }

      }) || _class);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7b21d32e4559b3999e72372c473bcf30c2f5abb7.js.map