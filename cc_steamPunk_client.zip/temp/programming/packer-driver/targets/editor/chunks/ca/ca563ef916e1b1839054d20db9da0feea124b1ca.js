System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, instantiate, Prefab, _decorator, Component, Node, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _crd, ccclass, property, PoolController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfIPoolController(extras) {
    _reporterNs.report("IPoolController", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      instantiate = _cc.instantiate;
      Prefab = _cc.Prefab;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "19ccdZZ2mhKPY1hV7dn1Onu", "PoolController", undefined);

      __checkObsolete__(['instantiate']);

      __checkObsolete__(['Prefab']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PoolController", PoolController = (_dec = ccclass("PoolController"), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Prefab), _dec5 = property(Prefab), _dec6 = property(Prefab), _dec7 = property(Node), _dec8 = property(Node), _dec9 = property(Node), _dec(_class = (_class2 = class PoolController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "listPrefab", _descriptor, this);

          _initializerDefineProperty(this, "listSymbolGroup", _descriptor2, this);

          _initializerDefineProperty(this, "trendGreenPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "trendBluePrefab", _descriptor4, this);

          _initializerDefineProperty(this, "trendYellowPrefab", _descriptor5, this);

          _initializerDefineProperty(this, "trendBlueGroupNode", _descriptor6, this);

          _initializerDefineProperty(this, "trendGreenGroupNode", _descriptor7, this);

          _initializerDefineProperty(this, "trendYellowGroupNode", _descriptor8, this);

          this.listSymbolNodes = [];
          this.trendBlueList = [];
          this.trendGreenList = [];
          this.trendYellowList = [];
          this.symbolListLenght = 30;
          this.listLenght = 10;
        }

        init() {
          this.initListSymbolNodes();
          this.initPools(this.listPrefab, this.listSymbolNodes, this.listSymbolGroup);
          this.initPoolTrendBlue();
          this.initPoolTrendGreen();
          this.initPoolTrendYellow();
        }

        initListSymbolNodes() {
          for (let i = 0; i < this.listLenght; i++) {
            let symbolNodes = [];
            this.listSymbolNodes.push(symbolNodes);
          }
        }

        initPools(listPrefab, listSymbol, listNode) {
          for (let i = 0; i < listPrefab.length; i++) {
            this.initPool(listPrefab[i], listSymbol[i], listNode[i], i + 1);
          }
        }

        initPoolTrendBlue() {
          this.initPool(this.trendBluePrefab, this.trendBlueList, this.trendBlueGroupNode, 1);
        }

        initPoolTrendGreen() {
          this.initPool(this.trendGreenPrefab, this.trendGreenList, this.trendGreenGroupNode, 2);
        }

        initPoolTrendYellow() {
          this.initPool(this.trendYellowPrefab, this.trendYellowList, this.trendYellowGroupNode, 3);
        }

        initPool(iconPrefab, nodeList, iconGroup, iconIndex) {
          for (let i = 0; i < this.symbolListLenght; i++) {
            this.instantiateNode(iconPrefab, nodeList, iconGroup, iconIndex);
          }
        }

        instantiateNode(symbolPrefab, symbolListNode, symbolNodeGroup, symbolIndex) {
          let symbolNode = instantiate(symbolPrefab);

          if (symbolNode) {
            symbolNode.name = symbolIndex.toString();
            symbolNodeGroup.addChild(symbolNode);
            symbolListNode.push(symbolNode);
            symbolNode.active = false;
          }
        }

        getSymbolNode(symbolNumber) {
          for (let i = 0; i < this.listSymbolNodes.length; i++) {
            if (symbolNumber == i + 1) {
              let symbolNodes = this.listSymbolNodes[i];

              if (symbolNodes) {
                if (symbolNodes.length > 0) {
                  let symbolNode = symbolNodes.pop();
                  symbolNode.removeFromParent();
                  return symbolNode;
                } else {
                  this.initPool(this.listPrefab[i], this.listSymbolNodes[i], this.listSymbolGroup[i], symbolNumber);
                  let symbolNodes = this.listSymbolNodes[i];
                  let symbolNode = symbolNodes.pop();
                  symbolNode.removeFromParent();
                  return symbolNode;
                }
              }
            }
          }
        }

        pushSymbolNode(symbolName, symbolNode) {
          let symbolIndex = parseInt(symbolName);

          if (symbolNode.parent) {
            symbolNode.removeFromParent();
          }

          this.listSymbolNodes[symbolIndex - 1].push(symbolNode);
          this.listSymbolGroup[symbolIndex - 1].addChild(symbolNode);
          symbolNode.active = false;
        }

        getTrendBlueNode() {
          return this.getNode(this.trendBlueList, this.initPoolTrendBlue);
        }

        getTrendGreenNode() {
          return this.getNode(this.trendGreenList, this.initPoolTrendGreen);
        }

        getTrendYellowNode() {
          return this.getNode(this.trendYellowList, this.initPoolTrendYellow);
        }

        pushTrendBlueNode(iconNode) {
          this.pushNode(iconNode, this.trendBlueList, this.trendBlueGroupNode);
        }

        pushTrendGreenNode(iconNode) {
          this.pushNode(iconNode, this.trendGreenList, this.trendGreenGroupNode);
        }

        pushTrendYellowNode(iconNode) {
          this.pushNode(iconNode, this.trendYellowList, this.trendYellowGroupNode);
        }

        resetNodePropertyesToOrigin(symbolNode) {}

        pushNode(symbolNode, symbolList, symbolGroup) {
          this.resetNodePropertyesToOrigin(symbolNode);

          if (symbolNode.parent) {
            symbolNode.removeFromParent();
          }

          symbolGroup.addChild(symbolNode);
          symbolList.push(symbolNode);
          symbolNode.active = false;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "listPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "listSymbolGroup", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "trendGreenPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "trendBluePrefab", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "trendYellowPrefab", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "trendBlueGroupNode", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "trendGreenGroupNode", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "trendYellowGroupNode", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ca563ef916e1b1839054d20db9da0feea124b1ca.js.map