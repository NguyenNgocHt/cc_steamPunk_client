System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, _dec, _class, _crd, ccclass, property, AudioModel;

  function _reportPossibleCrUseOfIAudioModel_loading(extras) {
    _reporterNs.report("IAudioModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "98a3fbsXZVKM5xjanDl+lgH", "AudioModel", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("AudioModel", AudioModel = (_dec = ccclass("AudioModel"), _dec(_class = class AudioModel {
        constructor() {
          this.soundDirs = ["res/sounds/bgm/", "res/sounds/sfx/"];
        }

        getSoundDirsData() {
          return this.soundDirs;
        }

        setSoundDirsData(soundPath) {
          this.soundDirs.push(soundPath);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=caabb425fe418ac9c6cae9d54940296c35ad72f1.js.map