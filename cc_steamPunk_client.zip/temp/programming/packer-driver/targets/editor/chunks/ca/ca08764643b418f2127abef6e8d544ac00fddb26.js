System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, AudioManager, _decorator, AudioClip, ScreenManager, assetManager, LocalDataManager, AudioModel, _dec, _class, _crd, ccclass, property, AudioSevice;

  function _reportPossibleCrUseOfAudioManager(extras) {
    _reporterNs.report("AudioManager", "./../../../../../../framework/audio/AudioManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfScreenManager(extras) {
    _reporterNs.report("ScreenManager", "../../../../../../framework/ui/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLocalDataManager(extras) {
    _reporterNs.report("LocalDataManager", "../../../../../../framework/common/LocalDataManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIAudioModel_loading(extras) {
    _reporterNs.report("IAudioModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIAudioSevice_loading(extras) {
    _reporterNs.report("IAudioSevice_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioModel(extras) {
    _reporterNs.report("AudioModel", "../model/AudioModel", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      AudioClip = _cc.AudioClip;
      assetManager = _cc.assetManager;
    }, function (_unresolved_2) {
      AudioManager = _unresolved_2.AudioManager;
    }, function (_unresolved_3) {
      ScreenManager = _unresolved_3.default;
    }, function (_unresolved_4) {
      LocalDataManager = _unresolved_4.default;
    }, function (_unresolved_5) {
      AudioModel = _unresolved_5.AudioModel;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "70619Apbf5LWrOxUgMlBgrf", "AudioSevice", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'AudioClip']);

      __checkObsolete__(['assetManager']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("AudioSevice", AudioSevice = (_dec = ccclass("AudioSevice"), _dec(_class = class AudioSevice {
        constructor() {
          this._audios = {};
          this._audioModel = null;
        }

        init() {
          this._audioModel = new (_crd && AudioModel === void 0 ? (_reportPossibleCrUseOfAudioModel({
            error: Error()
          }), AudioModel) : AudioModel)();
        }

        loadingAudio() {
          console.log("loading Audio start");
          this.loadAudioWeb();
        }

        loadAudioWeb() {
          let soundDirs = ["res/sounds/bgm/", "res/sounds/sfx/"];
          soundDirs.forEach(soundsPath => {
            const sounds = (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
              error: Error()
            }), ScreenManager) : ScreenManager).instance.assetBundle.getDirWithPath(soundsPath, AudioClip);
            sounds.forEach(sound => {
              if (this._audios[`${sound.path}`]) return;
              const nativeUrl = assetManager.utils.getUrlWithUuid(sound.uuid, {
                isNative: true,
                nativeExt: ".mp3"
              });
              console.log("sound", sound.path, sound.uuid, nativeUrl);
              console.log("sound", assetManager.utils.getUrlWithUuid(sound.uuid, {
                isNative: false
              }));
              this._audios[`${sound.path}`] = nativeUrl;
            });
          });
          this.initAudio();
        }

        initAudio() {
          (_crd && AudioManager === void 0 ? (_reportPossibleCrUseOfAudioManager({
            error: Error()
          }), AudioManager) : AudioManager).instance.init(this._audios);
          let isMuteMusic = (_crd && LocalDataManager === void 0 ? (_reportPossibleCrUseOfLocalDataManager({
            error: Error()
          }), LocalDataManager) : LocalDataManager).getBoolean((_crd && AudioManager === void 0 ? (_reportPossibleCrUseOfAudioManager({
            error: Error()
          }), AudioManager) : AudioManager).ENABLE_MUSIC, false);
          let isMuteSfx = (_crd && LocalDataManager === void 0 ? (_reportPossibleCrUseOfLocalDataManager({
            error: Error()
          }), LocalDataManager) : LocalDataManager).getBoolean((_crd && AudioManager === void 0 ? (_reportPossibleCrUseOfAudioManager({
            error: Error()
          }), AudioManager) : AudioManager).ENABLE_SFX, false);
          (_crd && AudioManager === void 0 ? (_reportPossibleCrUseOfAudioManager({
            error: Error()
          }), AudioManager) : AudioManager).instance.isMutingMusic = isMuteMusic;
          (_crd && AudioManager === void 0 ? (_reportPossibleCrUseOfAudioManager({
            error: Error()
          }), AudioManager) : AudioManager).instance.isMutingEffect = isMuteSfx;
        }

        getAudios() {
          return this._audios;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ca08764643b418f2127abef6e8d544ac00fddb26.js.map