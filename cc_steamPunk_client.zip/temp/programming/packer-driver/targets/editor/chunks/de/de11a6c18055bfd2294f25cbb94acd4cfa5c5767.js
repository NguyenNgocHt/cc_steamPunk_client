System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, MAP_SYMBOL, instantiate, Prefab, _decorator, Component, Node, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _dec16, _dec17, _dec18, _dec19, _dec20, _dec21, _dec22, _dec23, _dec24, _dec25, _dec26, _dec27, _dec28, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _descriptor16, _descriptor17, _descriptor18, _descriptor19, _descriptor20, _descriptor21, _descriptor22, _descriptor23, _descriptor24, _descriptor25, _descriptor26, _descriptor27, _crd, ccclass, property, PoolController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfMAP_SYMBOL(extras) {
    _reporterNs.report("MAP_SYMBOL", "./define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPoolController(extras) {
    _reporterNs.report("IPoolController", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      instantiate = _cc.instantiate;
      Prefab = _cc.Prefab;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }, function (_unresolved_2) {
      MAP_SYMBOL = _unresolved_2.MAP_SYMBOL;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "19ccdZZ2mhKPY1hV7dn1Onu", "PoolController", undefined);

      __checkObsolete__(['instantiate']);

      __checkObsolete__(['Prefab']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PoolController", PoolController = (_dec = ccclass("PoolController"), _dec2 = property(Prefab), _dec3 = property(Prefab), _dec4 = property(Prefab), _dec5 = property(Prefab), _dec6 = property(Prefab), _dec7 = property(Prefab), _dec8 = property(Prefab), _dec9 = property(Prefab), _dec10 = property(Prefab), _dec11 = property(Prefab), _dec12 = property(Prefab), _dec13 = property(Node), _dec14 = property(Node), _dec15 = property(Node), _dec16 = property(Node), _dec17 = property(Node), _dec18 = property(Node), _dec19 = property(Node), _dec20 = property(Node), _dec21 = property(Node), _dec22 = property(Node), _dec23 = property(Prefab), _dec24 = property(Prefab), _dec25 = property(Prefab), _dec26 = property(Node), _dec27 = property(Node), _dec28 = property(Node), _dec(_class = (_class2 = class PoolController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "listNode", _descriptor, this);

          _initializerDefineProperty(this, "aPrefab", _descriptor2, this);

          _initializerDefineProperty(this, "freeSpinPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "gearPrefab", _descriptor4, this);

          _initializerDefineProperty(this, "girlPrefab", _descriptor5, this);

          _initializerDefineProperty(this, "guysPrefab", _descriptor6, this);

          _initializerDefineProperty(this, "jPrefab", _descriptor7, this);

          _initializerDefineProperty(this, "qPrefab", _descriptor8, this);

          _initializerDefineProperty(this, "kPrefab", _descriptor9, this);

          _initializerDefineProperty(this, "wildPrefab", _descriptor10, this);

          _initializerDefineProperty(this, "jackpotPrefab", _descriptor11, this);

          _initializerDefineProperty(this, "aGroup", _descriptor12, this);

          _initializerDefineProperty(this, "freeSpinGroup", _descriptor13, this);

          _initializerDefineProperty(this, "gearGroup", _descriptor14, this);

          _initializerDefineProperty(this, "girlGroup", _descriptor15, this);

          _initializerDefineProperty(this, "guysGroup", _descriptor16, this);

          _initializerDefineProperty(this, "jGroup", _descriptor17, this);

          _initializerDefineProperty(this, "jackpotGroup", _descriptor18, this);

          _initializerDefineProperty(this, "qGroup", _descriptor19, this);

          _initializerDefineProperty(this, "kGroup", _descriptor20, this);

          _initializerDefineProperty(this, "wildGroup", _descriptor21, this);

          _initializerDefineProperty(this, "trendGreenPrefab", _descriptor22, this);

          _initializerDefineProperty(this, "trendBluePrefab", _descriptor23, this);

          _initializerDefineProperty(this, "trendYellowPrefab", _descriptor24, this);

          _initializerDefineProperty(this, "trendBlueGroupNode", _descriptor25, this);

          _initializerDefineProperty(this, "trendGreenGroupNode", _descriptor26, this);

          _initializerDefineProperty(this, "trendYellowGroupNode", _descriptor27, this);

          this.aList = [];
          this.freeSpinList = [];
          this.gearList = [];
          this.girlList = [];
          this.guysList = [];
          this.jList = [];
          this.qList = [];
          this.kList = [];
          this.wildList = [];
          this.jackpotList = [];
          this.trendBlueList = [];
          this.trendGreenList = [];
          this.trendYellowList = [];
          this.symbolListLenght = 30;
        }

        init() {
          this.initPoolA();
          this.initPoolFreeSpin();
          this.initPoolGear();
          this.initPoolGirl();
          this.initPoolGuys();
          this.initPoolJ();
          this.initPoolQ();
          this.initPoolK();
          this.initPoolWild();
          this.initPoolJackpot();
          this.initPoolTrendBlue();
          this.initPoolTrendGreen();
          this.initPoolTrendYellow();
        }

        initCommon() {}

        initPoolA() {
          this.initPool(this.aPrefab, this.aList, this.aGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).a);
        }

        initPoolFreeSpin() {
          this.initPool(this.freeSpinPrefab, this.freeSpinList, this.freeSpinGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).freespin);
        }

        initPoolGear() {
          this.initPool(this.gearPrefab, this.gearList, this.gearGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).gear);
        }

        initPoolGirl() {
          this.initPool(this.girlPrefab, this.girlList, this.girlGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).girl);
        }

        initPoolGuys() {
          this.initPool(this.guysPrefab, this.guysList, this.guysGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).guys);
        }

        initPoolJ() {
          this.initPool(this.jPrefab, this.jList, this.jGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).j);
        }

        initPoolQ() {
          this.initPool(this.qPrefab, this.qList, this.qGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).q);
        }

        initPoolK() {
          this.initPool(this.kPrefab, this.kList, this.kGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).k);
        }

        initPoolWild() {
          this.initPool(this.wildPrefab, this.wildList, this.wildGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).wild);
        }

        initPoolJackpot() {
          this.initPool(this.jackpotPrefab, this.jackpotList, this.jackpotGroup, (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
            error: Error()
          }), MAP_SYMBOL) : MAP_SYMBOL).jackpot);
        }

        initPoolTrendBlue() {
          this.initPool(this.trendBluePrefab, this.trendBlueList, this.trendBlueGroupNode, 1);
        }

        initPoolTrendGreen() {
          this.initPool(this.trendGreenPrefab, this.trendGreenList, this.trendGreenGroupNode, 2);
        }

        initPoolTrendYellow() {
          this.initPool(this.trendYellowPrefab, this.trendYellowList, this.trendYellowGroupNode, 3);
        }

        initPool(iconPrefab, nodeList, iconGroup, iconIndex) {
          for (let i = 0; i < this.symbolListLenght; i++) {
            this.instantiateNode(iconPrefab, nodeList, iconGroup, iconIndex);
          }
        }

        instantiateNode(symbolPrefab, symbolListNode, symbolNodeGroup, symbolIndex) {
          let symbolNode = instantiate(symbolPrefab);

          if (symbolNode) {
            symbolNode.name = symbolIndex.toString();
            symbolNodeGroup.addChild(symbolNode);
            symbolListNode.push(symbolNode);
            symbolNode.active = false;
          }
        }

        getSymbolNode(symbolNumber) {
          switch (symbolNumber) {
            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).a:
              return this.getNode(this.aList, this.initPoolA);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).freespin:
              return this.getNode(this.freeSpinList, this.initPoolFreeSpin);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).gear:
              return this.getNode(this.gearList, this.initPoolGear);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).girl:
              return this.getNode(this.girlList, this.initPoolGirl);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).guys:
              return this.getNode(this.guysList, this.initPoolGuys);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).j:
              return this.getNode(this.jList, this.initPoolJ);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).jackpot:
              return this.getNode(this.jackpotList, this.initPoolJackpot);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).q:
              return this.getNode(this.qList, this.initPoolQ);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).k:
              return this.getNode(this.kList, this.initPoolK);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).wild:
              return this.getNode(this.wildList, this.initPoolWild);
          }
        }

        pushSymbolNode(symbolName, symbolNode) {
          switch (symbolName) {
            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).a.toString():
              this.pushNode(symbolNode, this.aList, this.aGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).freespin.toString():
              this.pushNode(symbolNode, this.freeSpinList, this.freeSpinGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).gear.toString():
              this.pushNode(symbolNode, this.gearList, this.gearGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).girl.toString():
              this.pushNode(symbolNode, this.girlList, this.girlGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).guys.toString():
              this.pushNode(symbolNode, this.guysList, this.guysGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).j.toString():
              this.pushNode(symbolNode, this.jList, this.jGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).jackpot.toString():
              this.pushNode(symbolNode, this.jackpotList, this.jackpotGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).q.toString():
              this.pushNode(symbolNode, this.qList, this.qGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).k.toString():
              this.pushNode(symbolNode, this.kList, this.kGroup);
              break;

            case (_crd && MAP_SYMBOL === void 0 ? (_reportPossibleCrUseOfMAP_SYMBOL({
              error: Error()
            }), MAP_SYMBOL) : MAP_SYMBOL).wild.toString():
              this.pushNode(symbolNode, this.wildList, this.wildGroup);
              break;
          }
        }

        getTrendBlueNode() {
          return this.getNode(this.trendBlueList, this.initPoolTrendBlue);
        }

        getTrendGreenNode() {
          return this.getNode(this.trendGreenList, this.initPoolTrendGreen);
        }

        getTrendYellowNode() {
          return this.getNode(this.trendYellowList, this.initPoolTrendYellow);
        }

        pushTrendBlueNode(iconNode) {
          this.pushNode(iconNode, this.trendBlueList, this.trendBlueGroupNode);
        }

        pushTrendGreenNode(iconNode) {
          this.pushNode(iconNode, this.trendGreenList, this.trendGreenGroupNode);
        }

        pushTrendYellowNode(iconNode) {
          this.pushNode(iconNode, this.trendYellowList, this.trendYellowGroupNode);
        }

        resetNodePropertyesToOrigin(symbolNode) {}

        getNode(symbolList, initNewPool) {
          if (symbolList.length > 0) {
            let symbolNode = symbolList.pop();
            symbolNode.removeFromParent();
            return symbolNode;
          } else {
            initNewPool();
            let symbolNode = this.freeSpinList.pop();
            symbolNode.removeFromParent();
            return symbolNode;
          }
        }

        pushNode(symbolNode, symbolList, symbolGroup) {
          this.resetNodePropertyesToOrigin(symbolNode);

          if (symbolNode.parent) {
            symbolNode.removeFromParent();
          }

          symbolGroup.addChild(symbolNode);
          symbolList.push(symbolNode);
          symbolNode.active = false;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "listNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "aPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "freeSpinPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gearPrefab", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "girlPrefab", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "guysPrefab", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "jPrefab", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "qPrefab", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "kPrefab", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "wildPrefab", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "jackpotPrefab", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "aGroup", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "freeSpinGroup", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "gearGroup", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor15 = _applyDecoratedDescriptor(_class2.prototype, "girlGroup", [_dec16], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor16 = _applyDecoratedDescriptor(_class2.prototype, "guysGroup", [_dec17], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor17 = _applyDecoratedDescriptor(_class2.prototype, "jGroup", [_dec18], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor18 = _applyDecoratedDescriptor(_class2.prototype, "jackpotGroup", [_dec19], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor19 = _applyDecoratedDescriptor(_class2.prototype, "qGroup", [_dec20], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor20 = _applyDecoratedDescriptor(_class2.prototype, "kGroup", [_dec21], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor21 = _applyDecoratedDescriptor(_class2.prototype, "wildGroup", [_dec22], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor22 = _applyDecoratedDescriptor(_class2.prototype, "trendGreenPrefab", [_dec23], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor23 = _applyDecoratedDescriptor(_class2.prototype, "trendBluePrefab", [_dec24], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor24 = _applyDecoratedDescriptor(_class2.prototype, "trendYellowPrefab", [_dec25], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor25 = _applyDecoratedDescriptor(_class2.prototype, "trendBlueGroupNode", [_dec26], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor26 = _applyDecoratedDescriptor(_class2.prototype, "trendGreenGroupNode", [_dec27], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor27 = _applyDecoratedDescriptor(_class2.prototype, "trendYellowGroupNode", [_dec28], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=de11a6c18055bfd2294f25cbb94acd4cfa5c5767.js.map