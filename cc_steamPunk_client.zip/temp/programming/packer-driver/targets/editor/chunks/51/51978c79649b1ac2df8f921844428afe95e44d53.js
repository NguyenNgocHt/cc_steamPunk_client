System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, sys, AudioClip, ScreenManager, MESENGER, ImageModel, PrefabModel, AudioModel, _dec, _class, _crd, ccclass, property, AssetsSevice;

  function _reportPossibleCrUseOfILoadingController(extras) {
    _reporterNs.report("ILoadingController", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIAudioModel_loading(extras) {
    _reporterNs.report("IAudioModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPrefabModel_loading(extras) {
    _reporterNs.report("IPrefabModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIAssetsSevice_loading(extras) {
    _reporterNs.report("IAssetsSevice_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIImageModel_loading(extras) {
    _reporterNs.report("IImageModel_loading", "../../../interfaces/Loading_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfScreenManager(extras) {
    _reporterNs.report("ScreenManager", "../../../../../../framework/ui/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfMESENGER(extras) {
    _reporterNs.report("MESENGER", "../../../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfImageModel(extras) {
    _reporterNs.report("ImageModel", "../model/ImageModel", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPrefabModel(extras) {
    _reporterNs.report("PrefabModel", "../model/PrefabModel", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioModel(extras) {
    _reporterNs.report("AudioModel", "../model/AudioModel", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      sys = _cc.sys;
      AudioClip = _cc.AudioClip;
    }, function (_unresolved_2) {
      ScreenManager = _unresolved_2.default;
    }, function (_unresolved_3) {
      MESENGER = _unresolved_3.MESENGER;
    }, function (_unresolved_4) {
      ImageModel = _unresolved_4.ImageModel;
    }, function (_unresolved_5) {
      PrefabModel = _unresolved_5.PrefabModel;
    }, function (_unresolved_6) {
      AudioModel = _unresolved_6.AudioModel;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "dc160wDMUxLS5pYaMFLeKC0", "AssetsSevice", undefined);

      __checkObsolete__(['_decorator', 'sys', 'Asset', 'AudioClip']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("AssetsSevice", AssetsSevice = (_dec = ccclass("assetsSevice"), _dec(_class = class AssetsSevice {
        constructor() {
          this._imagesModel = null;
          this._prefabModel = null;
          this._audioModel = null;
          this._loadingController = null;
          this._audios = {};
          this._items = [];
          this.progressBar_current = 0;
        }

        init(loadingControler) {
          this._imagesModel = new (_crd && ImageModel === void 0 ? (_reportPossibleCrUseOfImageModel({
            error: Error()
          }), ImageModel) : ImageModel)();
          this._prefabModel = new (_crd && PrefabModel === void 0 ? (_reportPossibleCrUseOfPrefabModel({
            error: Error()
          }), PrefabModel) : PrefabModel)();
          this._audioModel = new (_crd && AudioModel === void 0 ? (_reportPossibleCrUseOfAudioModel({
            error: Error()
          }), AudioModel) : AudioModel)();
          this._loadingController = loadingControler;
        }

        loadingAssets() {
          this._items = this.getAllItems();
          let percent = 1.0 / (this._items.length + 1);
          console.log("items", this._items);

          this._loadAsset(0, percent);
        }

        getAllItems() {
          let allItems = [];

          let imagesDirs = this._imagesModel.getImagesDirsData();

          let audioDirs = this._audioModel.getSoundDirsData();

          let prefabDirs = this._prefabModel.getPrefabDirds();

          let prefabPaths = this._prefabModel.getPrefabsPath();

          allItems = audioDirs.concat(imagesDirs).concat(audioDirs).concat(prefabDirs).concat(prefabPaths);
          return allItems;
        }

        _loadAsset(index, totalPercent) {
          if (index >= this._items.length) {
            this._loadingController.updateLoadingView_progressBar(1.0);

            this._loadingController.checkResultLoadingAssets();

            this._finishedLoading();

            return;
          }

          let path = this._items[index];
          console.log("_loadAsset  " + path);

          if (this._isDirectory(path)) {
            (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
              error: Error()
            }), ScreenManager) : ScreenManager).instance.assetBundle.loadDir(path, (finished, total) => {
              // console.log(`items #${index}:  ${finished} / ${total} `);
              let progress = index * totalPercent + finished / total * totalPercent;

              if (progress > this.progressBar_current) {
                this.progressBar_current = progress;

                this._loadingController.updateLoadingView_progressBar(progress);
              }
            }, (err, data) => {
              if (sys.isNative && (path.endsWith("/bgm/") || path.endsWith("/sfx/"))) {
                this._loadingController.getAudiosFromAudioSevice();

                console.log(`AudioClip loaded:${JSON.stringify(this._audios)}`);
                let assets = data;

                for (let as of assets) {
                  if (as instanceof AudioClip) {
                    this._audios[`${path}${as.name}`] = `${as._nativeAsset.url}`;
                  }
                }

                this._loadingController.initAudios();
              }

              if (!err) {
                this._loadAsset(index + 1, totalPercent);
              } else {
                console.log("load error  " + err + "    " + path);

                if (sys.isBrowser) {
                  this._loadingController.showPopupMessage((_crd && MESENGER === void 0 ? (_reportPossibleCrUseOfMESENGER({
                    error: Error()
                  }), MESENGER) : MESENGER).RESOURCE_LOADING_ERR);
                }
              }
            });
          } else {
            (_crd && ScreenManager === void 0 ? (_reportPossibleCrUseOfScreenManager({
              error: Error()
            }), ScreenManager) : ScreenManager).instance.assetBundle.load(path, (finished, total) => {
              // console.log(`${finished} / ${total} `);
              let progress = index * totalPercent + finished / total * totalPercent;

              this._loadingController.updateLoadingView_progressBar(progress);
            }, (err, data) => {
              if (!err) {
                this._loadAsset(index + 1, totalPercent);
              } else {
                console.log("load error  " + err + "    " + path);

                if (sys.isBrowser) {
                  this._loadingController.showPopupMessage((_crd && MESENGER === void 0 ? (_reportPossibleCrUseOfMESENGER({
                    error: Error()
                  }), MESENGER) : MESENGER).RESOURCE_LOADING_ERR);
                }
              }
            });
          }
        }

        _finishedLoading() {
          console.log(`LoadingScreen: _finishedLoading`);
        }

        _isDirectory(path) {
          return path != null && typeof path == "string" && path.length > 0 && path[path.length - 1] == "/";
        }

        setProgressBarCurrent(progressCurrent) {
          this.progressBar_current = progressCurrent;
        }

        setAudiosData(audios) {
          this._audios = audios;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=51978c79649b1ac2df8f921844428afe95e44d53.js.map