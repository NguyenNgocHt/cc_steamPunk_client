System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, GameLoop, _crd;

  _export("default", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "446eeRnBU5ON5iactAqMzD9", "GameLoop", undefined);

      _export("default", GameLoop = class GameLoop {
        constructor() {
          // in second
          this._listFuncLoop = new Map();
          this._intervalId = -1;
        }

        static get instance() {
          return GameLoop._instance;
        }

        update() {
          var _this = GameLoop._instance;

          if (_this.isRunning()) {
            _this._listFuncLoop.forEach((value, key) => {
              if (value) {
                value.funcName.apply(value.caller[GameLoop.TIME_LOOP]);
              } else {
                _this.removeFunc(key);
              }
            });
          }
        }

        addFunc(key, caller, funcName) {
          var data = {
            key: key,
            caller: caller,
            funcName: funcName
          };

          this._listFuncLoop.set(key, data);
        }

        isRunning() {
          return this._intervalId > 0;
        }

        start() {
          if (this._intervalId < 0) {
            this.update();
            this._intervalId = setInterval(this.update, GameLoop.TIME_LOOP * 1000);
          }
        }

        stop() {
          if (this._intervalId > 0) {
            clearInterval(this._intervalId);
            this._intervalId = -1;
          }
        }

        cleanUp() {
          for (var key in this._listFuncLoop) {
            this._listFuncLoop.set(key, null);

            this._listFuncLoop.delete(key);
          }

          this._listFuncLoop.clear();
        }

        removeFunc(key) {
          var func = this._listFuncLoop.get(key);

          if (func) {
            this._listFuncLoop.delete(key);

            return true;
          }

          return false;
        }

      });

      GameLoop.TIME_LOOP = 0.1;
      GameLoop._instance = new GameLoop();

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1eb0582cef5e4b35e18927f6ed4461cdac318f65.js.map