System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, BaseDirector, _crd;

  _export("default", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a5893DRaBBHnpMP9R2za9Do", "BaseDirector", undefined);

      _export("default", BaseDirector = class BaseDirector {
        constructor() {
          this._eventNames = null;
        }

        _registerListeners() {}

        _unregisterListeners() {}

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=a7b9ee94898cf66cb985b3de82234b40598bfb1d.js.map