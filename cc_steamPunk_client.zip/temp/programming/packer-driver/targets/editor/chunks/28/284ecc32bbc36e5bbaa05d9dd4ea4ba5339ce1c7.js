System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, sys, AudioNativeManager, AudioWebManager, AudioManager, _crd;

  function _reportPossibleCrUseOfBaseAudio(extras) {
    _reporterNs.report("BaseAudio", "./BaseAudio", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioNativeManager(extras) {
    _reporterNs.report("AudioNativeManager", "./AudioNativeManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioWebManager(extras) {
    _reporterNs.report("AudioWebManager", "./AudioWebManager", _context.meta, extras);
  }

  _export("AudioManager", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      sys = _cc.sys;
    }, function (_unresolved_2) {
      AudioNativeManager = _unresolved_2.AudioNativeManager;
    }, function (_unresolved_3) {
      AudioWebManager = _unresolved_3.AudioWebManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ff32dP3jxxEY476ylEx1cRi", "AudioManager", undefined);

      __checkObsolete__(['_decorator', 'sys']);

      _export("AudioManager", AudioManager = class AudioManager {
        static get instance() {
          if (AudioManager._instance) {
            return AudioManager._instance;
          }

          AudioManager._instance = new AudioManager();
          return AudioManager._instance;
        }

        constructor() {
          this._audioManager = void 0;

          if (this._isWebAudio()) {
            this._audioManager = new (_crd && AudioWebManager === void 0 ? (_reportPossibleCrUseOfAudioWebManager({
              error: Error()
            }), AudioWebManager) : AudioWebManager)();
          } else {
            this._audioManager = new (_crd && AudioNativeManager === void 0 ? (_reportPossibleCrUseOfAudioNativeManager({
              error: Error()
            }), AudioNativeManager) : AudioNativeManager)();
          }
        }

        _isWebAudio() {
          return sys.isBrowser;
        }

        get isMutingMusic() {
          return this._audioManager.isMutingMusic;
        }

        set isMutingMusic(value) {
          this._audioManager.isMutingMusic = value;
        }

        get isMutingEffect() {
          return this._audioManager.isMutingEffect;
        }

        set isMutingEffect(value) {
          this._audioManager.isMutingEffect = value;
        }

        get musicVolume() {
          return this._audioManager.musicVolume;
        }

        set musicVolume(value) {
          this._audioManager.musicVolume = value;
        }

        get effectVolume() {
          return this._audioManager.effectVolume;
        }

        set effectVolume(value) {
          this._audioManager.effectVolume = value;
        }

        init(audio) {
          this._audioManager.init(audio);
        }

        playBGM(name, fade = false) {
          this._audioManager.playBGM(name, fade);
        }

        pauseBGM(fade = true) {
          this._audioManager.pauseBGM(fade);
        }

        resumeBGM(fade = true) {
          this._audioManager.resumeBGM(fade);
        }

        playClip(name, loop = false, resumeBGM = true, callback = null) {
          this._audioManager.playClip(name, loop, resumeBGM, callback);
        }

        stopClip(resumeBGM = true, callback = null) {
          this._audioManager.stopClip(resumeBGM, callback);
        }

        playEffect(name, loop = false, callback = null) {
          return this._audioManager.playEffect(name, loop, callback);
        }

        stopEffect(sfxId, fade = false) {
          return this._audioManager.stopEffect(sfxId, fade);
        }

        stopEffectByName(name, fade = false) {
          return this._audioManager.stopEffectByName(name, fade);
        }

        resumeEffect(sfxId, fade = false) {
          this._audioManager.resumeEffect(sfxId, fade);
        }

        pauseEffect(sfxId, fade = false) {
          this._audioManager.pauseEffect(sfxId, fade);
        }

        stopAllEffects(fade = false) {
          this._audioManager.stopAllEffects(fade);
        }

        pauseAllEffects(fade = false) {
          this._audioManager.pauseAllEffects(fade);
        }

        resumeAllEffects(fade = false) {
          this._audioManager.resumeAllEffects(fade);
        }

        destroy() {
          this._audioManager && this._audioManager.destroy();
          AudioManager._instance = null;
        }

      });

      AudioManager.ENABLE_MUSIC = "enableBackgroundMusic";
      AudioManager.ENABLE_SFX = "enableSound";
      AudioManager._instance = void 0;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=284ecc32bbc36e5bbaa05d9dd4ea4ba5339ce1c7.js.map