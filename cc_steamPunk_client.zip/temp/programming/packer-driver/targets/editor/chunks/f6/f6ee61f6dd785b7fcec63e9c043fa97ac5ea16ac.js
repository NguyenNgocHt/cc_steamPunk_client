System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd, LANGUAGE_MAP, BStorageKey, BNotifyType;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "09258n3MIpM8IbX5VSK3tPb", "Enum", undefined);

      _export("LANGUAGE_MAP", LANGUAGE_MAP = /*#__PURE__*/function (LANGUAGE_MAP) {
        LANGUAGE_MAP["Thai"] = "th";
        LANGUAGE_MAP["Vietnamese"] = "vi";
        LANGUAGE_MAP["Portugese"] = "pt";
        LANGUAGE_MAP["SimplifiedChinese"] = "zh";
        LANGUAGE_MAP["Tagalog"] = "tl";
        LANGUAGE_MAP["Indo"] = "id";
        LANGUAGE_MAP["English"] = "en";
        LANGUAGE_MAP["Russia"] = "ru";
        LANGUAGE_MAP["Turkish"] = "tr";
        LANGUAGE_MAP["Spanish"] = "es";
        return LANGUAGE_MAP;
      }({}));

      _export("BStorageKey", BStorageKey = /*#__PURE__*/function (BStorageKey) {
        BStorageKey["IP_TEST"] = "IP_TEST";
        BStorageKey["LANGUAGE_CHANGE"] = "LANGUAGE_CHANGE";
        BStorageKey["USERNAME"] = "USERNAME";
        BStorageKey["PASS"] = "PASS";
        BStorageKey["MUSIC"] = "MUSIC";
        BStorageKey["SOUND"] = "SOUND";
        BStorageKey["SHOW_WELCOME"] = "SHOW_WELCOME";
        BStorageKey["LANGUAGE_DATA"] = "LANGUAGE_DATA";
        BStorageKey["LANGUAGE_CACHE"] = "LANGUAGE_CACHE";
        return BStorageKey;
      }({}));

      _export("BNotifyType", BNotifyType = /*#__PURE__*/function (BNotifyType) {
        BNotifyType["LANGUAGE_CHANGED"] = "LANGUAGE_CHANGED";
        BNotifyType["BLOCK_INPUT_SHOW"] = "BLOCK_INPUT_SHOW";
        BNotifyType["BLOCK_INPUT_HIDE"] = "BLOCK_INPUT_HIDE";
        BNotifyType["CHANGE_MONEY"] = "CHANGE_MONEY";
        BNotifyType["INPUT_ACTION"] = "INPUT_ACTION";
        BNotifyType["TAP_EFFECT"] = "TAP_EFFECT";
        BNotifyType["UPDATE_GAME_MODE"] = "UPDATE_GAME_MODE";
        BNotifyType["TREND_CHANGE"] = "TREND_CHANGE";
        BNotifyType["ADD_TREND"] = "ADD_TREND";
        BNotifyType["RUN_AUTO"] = "RUN_AUTO";
        BNotifyType["STOP_AUTO"] = "STOP_AUTO";
        BNotifyType["MUSIC_CHANGE"] = "MUSIC_CHANGE";
        BNotifyType["SOUND_CHANGE"] = "SOUND_CHANGE";
        BNotifyType["CHANGE_GAME_INFO"] = "CHANGE_GAME_INFO";
        BNotifyType["SOUND_CLICK"] = "SOUND_CLICK";
        BNotifyType["SHOW_MESSAGE"] = "SHOW_MESSAGE";
        BNotifyType["HIDE_MESSAGE"] = "HIDE_MESSAGE";
        BNotifyType["SHOW_DISCONNECT"] = "SHOW_DISCONNECT";
        BNotifyType["HIDE_DISCONNECT"] = "HIDE_DISCONNECT";
        BNotifyType["RECONNECT_SERVER"] = "RECONNECT_SERVER";
        BNotifyType["SHOW_WELCOME"] = "SHOW_WELCOME";
        BNotifyType["HIDE_WELCOME"] = "HIDE_WELCOME";
        BNotifyType["UPDATE_BET_AMOUT"] = "UPDATE_BET_AMOUT";
        BNotifyType["UPDATE_AVATA"] = "UPDATE_AVATA";
        BNotifyType["RUN_ANIM_AVATA"] = "RUN_ANIM_AVATA";
        BNotifyType["GAME_PAUSE"] = "GAME_PAUSE";
        BNotifyType["SHOW_HELP"] = "SHOW_HELP";
        BNotifyType["HIDE_HELP"] = "HIDE_HELP";
        BNotifyType["SHOW_HISTORY"] = "SHOW_HISTORY";
        BNotifyType["HISTORY_UPDATE"] = "HISTORY_UPDATE";
        BNotifyType["RESET_GAME"] = "RESET_GAME";
        return BNotifyType;
      }({}));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=f6ee61f6dd785b7fcec63e9c043fa97ac5ea16ac.js.map