System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _crd;

  function _reportPossibleCrUseOfBetData(extras) {
    _reporterNs.report("BetData", "../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPayLinesDaTa(extras) {
    _reporterNs.report("PayLinesDaTa", "../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfplayerInfo(extras) {
    _reporterNs.report("playerInfo", "../../dataModel/PlayerDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "7173clrkPZPuo9Ahhv4aO3J", "GamePlayInterfaces", undefined);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4b3320a5a85197b2d4bdfbdd47885652bb1f894f.js.map