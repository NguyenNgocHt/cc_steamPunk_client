System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, PlayerInfoService, _dec, _class, _crd, ccclass, property, GameInfoServiceMock;

  function _reportPossibleCrUseOfSettingsData(extras) {
    _reporterNs.report("SettingsData", "./../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIGameInfoService(extras) {
    _reporterNs.report("IGameInfoService", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameInfoData(extras) {
    _reporterNs.report("GameInfoData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPendingData(extras) {
    _reporterNs.report("PendingData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPlayerInfoService(extras) {
    _reporterNs.report("IPlayerInfoService", "../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerInfoService(extras) {
    _reporterNs.report("PlayerInfoService", "../screensManager/gamePlay/mainController/service/PlayerInfoService", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      PlayerInfoService = _unresolved_2.PlayerInfoService;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "5ae791LPo9NhZLLu16OsKFw", "GameInfoServiceMock", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['Settings']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameInfoServiceMock", GameInfoServiceMock = (_dec = ccclass("GameInfoServiceMock"), _dec(_class = class GameInfoServiceMock {
        constructor() {
          this.denomination = [0.05, 0.1, 0.15, 0.25, 0.4, 0.5, 1, 2.5, 5, 10, 15, 20, 25, 35, 50];
          this.currentMoney = null;
        }

        init() {
          this.currentMoney = new (_crd && PlayerInfoService === void 0 ? (_reportPossibleCrUseOfPlayerInfoService({
            error: Error()
          }), PlayerInfoService) : PlayerInfoService)();
        }

        getGameInfo() {
          let pendingData = {
            freeSpins: 0,
            refId: "",
            roundId: "",
            stake: 0.05
          };
          let settingsData = {
            Denominations: this.denomination,
            MaxBet: 50,
            MinBet: 0.05,
            currency: "USD"
          };
          let gameInfo = null;
          gameInfo = {
            balance: this.currentMoney.getCurrentMoney(),
            betlines: 1,
            currency: "USD",
            denominations: this.denomination,
            pending: pendingData,
            settings: settingsData,
            username: "ngocdev"
          };
          return gameInfo;
        }

        getListDenominations() {
          let listNumber = [];
          return listNumber;
        }

        getListPending() {
          let pendingData = null;
          return pendingData;
        }

        getlistSettings() {
          let settingData = null;
          return settingData;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=6689cdad562b964c96825a6113ece52aadbdd47f.js.map