System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd, Path, LOCAL_STORAGE_KEY_WORD, MESSENGER_DEFINE, SKELETON_KEY_WORK;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "32025VhmkxKNLebXdBbhrOu", "Path", undefined);

      _export("Path", Path = {
        GET_AVATAR_GROUP: "images/avatarGroup/avatar",
        AVATAR_TEXTURE_PACKER: "res/images/texturePacker/avatar/avatarGroup",
        TRANSITION_CLOUD: "res/prefabs/transition/transition_cloud",
        HOME_SCREEN: "res/prefabs/screen/home_screen",
        POPUP_NOTIFY: "res/prefabs/popup/popup_notify",
        LOADING_SCREEN: "res/prefabs/screen/loading_screen"
      });

      _export("LOCAL_STORAGE_KEY_WORD", LOCAL_STORAGE_KEY_WORD = {
        PLAYER_LIST: "player list",
        PLAYER_INFO: "player info",
        GAME_INFO: "game info",
        GAME_DATA: "game data"
      });

      _export("MESSENGER_DEFINE", MESSENGER_DEFINE = {
        USER_NAME_WRONG: "input user name wrong",
        PASSWORD_WRONG: "input password wrong"
      });

      _export("SKELETON_KEY_WORK", SKELETON_KEY_WORK = {
        TRANSITION_TO_LUCKY: "transition_to_lucky",
        NAME_OF_RETURN_EVENT: "transition"
      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=735bf646c673d7eff4af8fc306bfefa3483a9492.js.map