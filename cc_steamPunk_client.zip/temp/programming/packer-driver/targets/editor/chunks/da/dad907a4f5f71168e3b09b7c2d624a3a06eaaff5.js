System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, sys, _decorator, LOCAL_STORAGE_KEY_WORD, EventBus, GAME_EVENT, _dec, _class, _crd, ccclass, property, PlayerInfo;

  function _reportPossibleCrUseOfplayerInfo(extras) {
    _reporterNs.report("playerInfo", "./../dataModel/PlayerDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD(extras) {
    _reporterNs.report("LOCAL_STORAGE_KEY_WORD", "./Path", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPLayerInfo(extras) {
    _reporterNs.report("IPLayerInfo", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      sys = _cc.sys;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      LOCAL_STORAGE_KEY_WORD = _unresolved_2.LOCAL_STORAGE_KEY_WORD;
    }, function (_unresolved_3) {
      EventBus = _unresolved_3.EventBus;
    }, function (_unresolved_4) {
      GAME_EVENT = _unresolved_4.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1888bAmHWtCBZB5PlTK9txa", "PlayerInfo", undefined);

      __checkObsolete__(['sys']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['EventHandler']);

      __checkObsolete__(['TriggerEventType']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerInfo", PlayerInfo = (_dec = ccclass("PlayerInfo"), _dec(_class = class PlayerInfo {
        constructor() {
          this.playerInfo = null;
        }

        init() {
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_TO_PLAYER_INFO, this.handlePlayerInfo.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_TO_PLAYER_INFO, this.handlePlayerInfo.bind(this));
        }

        handlePlayerInfo(data) {
          console.log("come in player info", data);
          this.playerInfo = {
            userName: data.userName,
            money: data.money,
            currency: data.currency
          };
          sys.localStorage.setItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).PLAYER_INFO, JSON.stringify(this.playerInfo));
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=dad907a4f5f71168e3b09b7c2d624a3a06eaaff5.js.map