System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, EventBus, GAME_EVENT, LOCAL_STORAGE_KEY_WORD, sys, _dec, _class, _crd, ccclass, property, GameData;

  function _reportPossibleCrUseOfIGameData(extras) {
    _reporterNs.report("IGameData", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD(extras) {
    _reporterNs.report("LOCAL_STORAGE_KEY_WORD", "./Path", _context.meta, extras);
  }

  function _reportPossibleCrUseOfgameData(extras) {
    _reporterNs.report("gameData", "../dataModel/GameInfoDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      sys = _cc.sys;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
    }, function (_unresolved_3) {
      GAME_EVENT = _unresolved_3.GAME_EVENT;
    }, function (_unresolved_4) {
      LOCAL_STORAGE_KEY_WORD = _unresolved_4.LOCAL_STORAGE_KEY_WORD;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "466f5mSMFdFnpVzpcAza6fT", "GameData", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      __checkObsolete__(['sys']);

      __checkObsolete__(['Layers']);

      __checkObsolete__(['game']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameData", GameData = (_dec = ccclass("GameData"), _dec(_class = class GameData {
        init() {
          this.registerEvent();
        }

        registerEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).on((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_GAME_DATA, this.setGameData.bind(this));
        }

        unRegisterEvent() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).off((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).SEND_GAME_DATA, this.setGameData.bind(this));
        }

        setGameData(data) {
          console.log("data game data", data);
          let v = null;
          v = {
            api: data.api,
            currency: data.currency,
            env: data.env,
            gameCode: data.gameCode,
            ip: data.ip,
            language: data.language,
            operator: data.operator,
            playmode: data.playmode,
            server: data.server,
            signature: data.signature,
            staticUrl: data.staticUrl,
            subpath: data.subpath,
            timestamp: data.timestamp,
            token: data.token,
            username: data.username
          };
          sys.localStorage.setItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).GAME_DATA, JSON.stringify(v));
        }

        getGameData() {
          let gameData = JSON.parse(sys.localStorage.getItem((_crd && LOCAL_STORAGE_KEY_WORD === void 0 ? (_reportPossibleCrUseOfLOCAL_STORAGE_KEY_WORD({
            error: Error()
          }), LOCAL_STORAGE_KEY_WORD) : LOCAL_STORAGE_KEY_WORD).GAME_DATA));
          return gameData ? gameData : null;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7d63051c9e493a78cbcd238c4e8c44d9a4055121.js.map