System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _crd;

  function _reportPossibleCrUseOfBetResultsData(extras) {
    _reporterNs.report("BetResultsData", "../../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfpaylineConvert(extras) {
    _reporterNs.report("paylineConvert", "../../dataModel/BetDataType", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "80588pCANZDQrAUAZCwJ/gM", "MainLayer_interfaces", undefined);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e7d6736677aa718891c683d0ca750d1c152cdf92.js.map