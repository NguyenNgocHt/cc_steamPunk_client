System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Vec3, tween, _decorator, Component, Node, EventBus, GAME_EVENT, AutoPlayStController, ToggleAutoView, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, AutoPlayView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAutoPlayStController(extras) {
    _reporterNs.report("AutoPlayStController", "../../../../popups/autoPlaySt/AutoPlayStController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfToggleAutoView(extras) {
    _reporterNs.report("ToggleAutoView", "./ToggleAutoView", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Vec3 = _cc.Vec3;
      tween = _cc.tween;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
    }, function (_unresolved_3) {
      GAME_EVENT = _unresolved_3.GAME_EVENT;
    }, function (_unresolved_4) {
      AutoPlayStController = _unresolved_4.AutoPlayStController;
    }, function (_unresolved_5) {
      ToggleAutoView = _unresolved_5.ToggleAutoView;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "7a131PJu3ZJiqNNABVK34LM", "AutoPlayView", undefined);

      __checkObsolete__(['Vec3']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("AutoPlayView", AutoPlayView = (_dec = ccclass("AutoPlayView"), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(_crd && ToggleAutoView === void 0 ? (_reportPossibleCrUseOfToggleAutoView({
        error: Error()
      }), ToggleAutoView) : ToggleAutoView), _dec(_class = (_class2 = class AutoPlayView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "startNode", _descriptor, this);

          _initializerDefineProperty(this, "tagetNode", _descriptor2, this);

          _initializerDefineProperty(this, "parentPopup", _descriptor3, this);

          _initializerDefineProperty(this, "toggleAutoView", _descriptor4, this);
        }

        setNodeToStartPoint() {
          let startPos = this.startNode.getWorldPosition();
          this.node.setWorldPosition(startPos.x, startPos.y, 0);
        }

        moveNodeToTagetPoint() {
          let tagetPos = this.tagetNode.getWorldPosition();
          tween(this.node).to(0.8, {
            worldPosition: new Vec3(tagetPos.x, tagetPos.y, 0)
          }, {
            easing: "backInOut"
          }).start();
        }

        onClickAutoPlay() {
          (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
            error: Error()
          }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
            error: Error()
          }), GAME_EVENT) : GAME_EVENT).ON_CLICK_AUTO_PLAY);
        }

        showPoupAutoPlaySt(nodeShow) {
          if (this.parentPopup.children.length == 0) {
            this.parentPopup.addChild(nodeShow);
            this.onNode(nodeShow);
          } else {
            let childNode = this.parentPopup.children[0];
            this.onNode(childNode);
          }
        }

        onNode(nodeShow) {
          let autoPlayStController = nodeShow.getComponent(_crd && AutoPlayStController === void 0 ? (_reportPossibleCrUseOfAutoPlayStController({
            error: Error()
          }), AutoPlayStController) : AutoPlayStController);

          if (autoPlayStController) {
            autoPlayStController.onNode();
          }
        }

        onAutoPlay() {
          this.toggleAutoView.setOnAutoPlay();
        }

        offAutoPlay() {
          this.toggleAutoView.setOffAutoPlay();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "startNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tagetNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "parentPopup", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "toggleAutoView", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=434aa63171589748120ae0e55b3e41616ceecf6c.js.map