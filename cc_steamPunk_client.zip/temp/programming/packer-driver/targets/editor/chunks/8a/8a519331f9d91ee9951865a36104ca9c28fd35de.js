System.register(["__unresolved_0", "cc"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, instantiate, Prefab, _decorator, Component, Node, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, PoolController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfIPoolController(extras) {
    _reporterNs.report("IPoolController", "../interfaces/Common_interfaces", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      instantiate = _cc.instantiate;
      Prefab = _cc.Prefab;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "19ccdZZ2mhKPY1hV7dn1Onu", "PoolController", undefined);

      __checkObsolete__(['instantiate']);

      __checkObsolete__(['Prefab']);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);
      /*
      Pool -> stateless
      
      interface Pool<T> where T:IDisposal{
        T Get();
        Return<T>(T object);
      }
      
      class XXX:IPool<T>{
        public XXX(Func<T> create){
      
        }
      }
      
      Pool [] _pools = new Pool[2];
      
      Math.Add(int a,int b);
      */

      _export("PoolController", PoolController = (_dec = ccclass("PoolController"), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Prefab), _dec5 = property(Node), _dec(_class = (_class2 = class PoolController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "listSymbolPrefab", _descriptor, this);

          _initializerDefineProperty(this, "listSymbolGroup", _descriptor2, this);

          _initializerDefineProperty(this, "listTrendPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "listTrendGroupNode", _descriptor4, this);

          this.listSymbolNodes = [];
          this.listTrendNodes = [];
          this.trendBlueList = [];
          this.trendGreenList = [];
          this.trendYellowList = [];

          /*
          list -> remove
          -> limit | max ,....
          -> const 
          -> variable -> inject into constructor
          */
          this.symbolListLenght = 30;
          this.listSymbolLenght = 10;
          this.listTrendLenght = 3;
        }

        init() {
          this.initListSymbolNodes();
          this.initListTrendNodes();
          this.initSymbolPools();
          this.initTrendPools();
        }

        initListSymbolNodes() {
          for (let i = 0; i < this.listSymbolLenght; i++) {
            let symbolNodes = [];
            this.listSymbolNodes.push(symbolNodes);
          }
        }

        initListTrendNodes() {
          for (let i = 0; i < this.listTrendLenght; i++) {
            let trendNodes = [];
            this.listTrendNodes.push(trendNodes);
          }
        }

        initSymbolPools() {
          this.initPools(this.listSymbolPrefab, this.listSymbolNodes, this.listSymbolGroup);
        }

        initTrendPools() {
          this.initPools(this.listTrendPrefab, this.listTrendNodes, this.listTrendGroupNode);
        }

        initPools(listPrefab, listSymbol, listNode) {
          for (let i = 0; i < listPrefab.length; i++) {
            this.initPool(listPrefab[i], listSymbol[i], listNode[i], i + 1);
          }
        }

        initPool(iconPrefab, nodeList, iconGroup, iconIndex) {
          for (let i = 0; i < this.symbolListLenght; i++) {
            this.instantiateNode(iconPrefab, nodeList, iconGroup, iconIndex);
          }
        }

        instantiateNode(symbolPrefab, symbolListNode, symbolNodeGroup, symbolIndex) {
          let symbolNode = instantiate(symbolPrefab);

          if (symbolNode) {
            symbolNode.name = symbolIndex.toString();
            symbolNodeGroup.addChild(symbolNode);
            symbolListNode.push(symbolNode);
            symbolNode.active = false;
          }
        }

        getSymbolNode(symbolIndex) {
          return this.findNode(symbolIndex, this.listSymbolPrefab, this.listSymbolNodes, this.listSymbolGroup);
        }

        getTrendNode(trendIndex) {
          return this.findNode(trendIndex, this.listTrendPrefab, this.listTrendNodes, this.listTrendGroupNode);
        }

        pushSymbolNode(symbolName, symbolNode) {
          this.pushNode(symbolName, symbolNode, this.listSymbolNodes, this.listSymbolGroup);
        }

        pushTrendNode(symbolName, symbolNode) {
          this.pushNode(symbolName, symbolNode, this.listTrendNodes, this.listTrendGroupNode);
        } //findNode


        findNode(symbolNumber, symbolPrefab, symbolListNodes, symbolNodeGroup) {
          for (let i = 0; i < symbolListNodes.length; i++) {
            if (symbolNumber == i + 1) {
              let symbolNodes = symbolListNodes[i];

              if (symbolNodes) {
                if (symbolNodes.length > 0) {
                  let symbolNode = symbolNodes.pop();
                  symbolNode.removeFromParent();
                  return symbolNode;
                } else {
                  this.initPool(symbolPrefab[i], symbolListNodes[i], symbolNodeGroup[i], symbolNumber);
                  let symbolNodes = symbolListNodes[i];
                  let symbolNode = symbolNodes.pop();
                  symbolNode.removeFromParent();
                  return symbolNode;
                }
              }
            }
          }
        }

        pushNode(NodeName, iconNode, listIconNodes, listIconGroup) {
          this.resetNodePropertyesToOrigin(iconNode);
          let symbolIndex = parseInt(NodeName);

          if (iconNode.parent) {
            iconNode.removeFromParent();
          }

          listIconNodes[symbolIndex - 1].push(iconNode);
          listIconGroup[symbolIndex - 1].addChild(iconNode);
          iconNode.active = false;
        }

        resetNodePropertyesToOrigin(symbolNode) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "listSymbolPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "listSymbolGroup", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "listTrendPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "listTrendGroupNode", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8a519331f9d91ee9951865a36104ca9c28fd35de.js.map