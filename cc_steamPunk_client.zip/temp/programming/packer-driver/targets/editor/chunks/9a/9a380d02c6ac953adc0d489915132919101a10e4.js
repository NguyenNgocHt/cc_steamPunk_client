System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, GameLayerView, SlotMachineController, EffectLayerController, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, GameLayerController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameLayerView(extras) {
    _reporterNs.report("GameLayerView", "../view/GameLayerView", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSlotMachineController(extras) {
    _reporterNs.report("SlotMachineController", "./SlotMachineController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEffectLayerController(extras) {
    _reporterNs.report("EffectLayerController", "./EffectLayerController", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      GameLayerView = _unresolved_2.GameLayerView;
    }, function (_unresolved_3) {
      SlotMachineController = _unresolved_3.SlotMachineController;
    }, function (_unresolved_4) {
      EffectLayerController = _unresolved_4.EffectLayerController;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "35034mLujxEMa/WovlICUjA", "GameLayerController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameLayerController", GameLayerController = (_dec = ccclass("GameLayerController"), _dec2 = property(_crd && GameLayerView === void 0 ? (_reportPossibleCrUseOfGameLayerView({
        error: Error()
      }), GameLayerView) : GameLayerView), _dec3 = property(_crd && SlotMachineController === void 0 ? (_reportPossibleCrUseOfSlotMachineController({
        error: Error()
      }), SlotMachineController) : SlotMachineController), _dec4 = property(_crd && EffectLayerController === void 0 ? (_reportPossibleCrUseOfEffectLayerController({
        error: Error()
      }), EffectLayerController) : EffectLayerController), _dec(_class = (_class2 = class GameLayerController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "gameLayerView", _descriptor, this);

          _initializerDefineProperty(this, "slotMachingControl", _descriptor2, this);

          _initializerDefineProperty(this, "effectLayerControl", _descriptor3, this);
        }

        metalgateToUp() {
          this.gameLayerView.metalgateToUp();
        }

        handleBetResult(result) {
          this.slotMachingControl.setBetResultData(result);
        }

        startGame() {
          this.effectLayerControl.onAllEffect();
        }

        showWinGameBonus(coinBonus, multiplier, tagetNode) {
          this.effectLayerControl.showWinGameBonus(coinBonus, multiplier, tagetNode);
        }

        showFreeSpinAnim() {
          this.gameLayerView.showFreeSpinAnim();
        }

        showJackpotAnim() {
          this.gameLayerView.showJackpotAnim();
        }

        setGreenOverlapActive(active) {
          this.gameLayerView.setGreenOverlapActive(active);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gameLayerView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "slotMachingControl", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "effectLayerControl", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=9a380d02c6ac953adc0d489915132919101a10e4.js.map