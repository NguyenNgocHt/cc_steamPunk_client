System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, tween, Label, _decorator, Component, Node, Vec3, EventBus, GAME_EVENT, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, property, WinGameBonusView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEventBus(extras) {
    _reporterNs.report("EventBus", "../../../../../../../framework/common/EventBus", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGAME_EVENT(extras) {
    _reporterNs.report("GAME_EVENT", "../../../../network/networkDefine", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      tween = _cc.tween;
      Label = _cc.Label;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      EventBus = _unresolved_2.EventBus;
    }, function (_unresolved_3) {
      GAME_EVENT = _unresolved_3.GAME_EVENT;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "852b5ICSnRMu4Fs8QmJVwA2", "WinGameBonusView", undefined);

      __checkObsolete__(['tween']);

      __checkObsolete__(['Label']);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("WinGameBonusView", WinGameBonusView = (_dec = ccclass("WinGameBonusView"), _dec2 = property(Node), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Node), _dec6 = property(Node), _dec(_class = (_class2 = class WinGameBonusView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "moneyGroup", _descriptor, this);

          _initializerDefineProperty(this, "lbCoin", _descriptor2, this);

          _initializerDefineProperty(this, "lbMultiplier", _descriptor3, this);

          _initializerDefineProperty(this, "startNode", _descriptor4, this);

          _initializerDefineProperty(this, "originNode", _descriptor5, this);

          this.scaleMax = new Vec3(1.2, 1.2, 1.2);
          this.scaleMin = new Vec3(0.1, 0.1, 0.1);
          this.scaleZezo = new Vec3(0, 0, 0);
          this.OriginPos = new Vec3(0, 0, 0);
        }

        start() {
          this.moneyGroup.setScale(this.scaleZezo);
        }

        resetToOrigin() {
          this.moneyGroup.setScale(this.scaleZezo);
        }

        updateCoinAndMultiplier(coin, multiplier) {
          let coinValue = 0;
          let multiplierValue = 0;
          coinValue = coin;
          multiplierValue = multiplier;

          if (!Number.isInteger(coin)) {
            coinValue = Math.round(coin * 100) / 100;
          }

          if (!Number.isInteger(multiplier)) {
            multiplierValue = Math.round(multiplier * 100) / 100;
          }

          this.lbCoin.string = coinValue.toString();
          this.lbMultiplier.string = multiplierValue.toString();
        }

        showEffectMoneyWin(playerPos, timeAction1, timeAction2) {
          let originPos = this.originNode.getPosition();
          let startPos = this.startNode.getWorldPosition();

          let action_ShowMoneyWinStart = () => {
            tween(this.moneyGroup).to(timeAction1, {
              scale: this.scaleMax
            }, {
              easing: "backInOut"
            }).start();
            tween(this.moneyGroup).to(timeAction1, {
              worldPosition: new Vec3(startPos.x, startPos.y, 0)
            }, {
              easing: "backInOut"
            }).start();
          };

          let action_coinMoveToPayerGroup = () => {
            tween(this.moneyGroup).to(timeAction2, {
              scale: this.scaleMin
            }).start();
            tween(this.moneyGroup).to(timeAction2, {
              worldPosition: new Vec3(playerPos.x, playerPos.y, 0)
            }).start();
          };

          tween(this.node).call(action_ShowMoneyWinStart).delay(timeAction1 + 0.1).call(action_coinMoveToPayerGroup).delay(timeAction2 + 0.05).call(() => {
            console.log("update money in playerGroup");
            (_crd && EventBus === void 0 ? (_reportPossibleCrUseOfEventBus({
              error: Error()
            }), EventBus) : EventBus).dispatchEvent((_crd && GAME_EVENT === void 0 ? (_reportPossibleCrUseOfGAME_EVENT({
              error: Error()
            }), GAME_EVENT) : GAME_EVENT).UPDATE_MONEY_PLAYER);
            this.moneyGroup.setScale(this.scaleZezo);
            this.moneyGroup.setPosition(originPos.x, originPos.y, 0);
          }).start();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "moneyGroup", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lbCoin", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lbMultiplier", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "startNode", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "originNode", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=386a9b59ef09aa4dd313af9a2005f2654b8d7694.js.map