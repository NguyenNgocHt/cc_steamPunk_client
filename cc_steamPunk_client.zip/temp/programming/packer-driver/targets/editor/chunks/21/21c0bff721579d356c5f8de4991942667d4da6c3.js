System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Global, PAY_OUT_RATE, SYMBOL_LIST, PlayerInfoService, _dec, _class, _crd, ccclass, property, BetResultsServiceMock;

  function _reportPossibleCrUseOfPaylinesMock(extras) {
    _reporterNs.report("PaylinesMock", "./../dataModel/MockConfigData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPaylineMock(extras) {
    _reporterNs.report("PaylineMock", "./../dataModel/MockConfigData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfResultMock(extras) {
    _reporterNs.report("ResultMock", "./../dataModel/MockConfigData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfResultsMock(extras) {
    _reporterNs.report("ResultsMock", "./../dataModel/MockConfigData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIBetResultsServiceMock(extras) {
    _reporterNs.report("IBetResultsServiceMock", "../interfaces/Mock_interfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfbetResultMock(extras) {
    _reporterNs.report("betResultMock", "../dataModel/MockConfigData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSendBet(extras) {
    _reporterNs.report("SendBet", "../dataModel/BetDataType", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGlobal(extras) {
    _reporterNs.report("Global", "../common/Global", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPAY_OUT_RATE(extras) {
    _reporterNs.report("PAY_OUT_RATE", "../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSYMBOL_LIST(extras) {
    _reporterNs.report("SYMBOL_LIST", "../common/define", _context.meta, extras);
  }

  function _reportPossibleCrUseOfIPlayerInfoService(extras) {
    _reporterNs.report("IPlayerInfoService", "../interfaces/gamePlay/GamePlayInterfaces", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerInfoService(extras) {
    _reporterNs.report("PlayerInfoService", "../screensManager/gamePlay/mainController/service/PlayerInfoService", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      Global = _unresolved_2.Global;
    }, function (_unresolved_3) {
      PAY_OUT_RATE = _unresolved_3.PAY_OUT_RATE;
      SYMBOL_LIST = _unresolved_3.SYMBOL_LIST;
    }, function (_unresolved_4) {
      PlayerInfoService = _unresolved_4.PlayerInfoService;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fe290DLedFOXrhWvvPzTF+p", "BetResultsServiceMock", undefined);

      __checkObsolete__(['_decorator']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BetResultsServiceMock", BetResultsServiceMock = (_dec = ccclass("BetResultsServiceMock"), _dec(_class = class BetResultsServiceMock {
        constructor() {
          this.currentMoney = null;
          this.freeSpine = 0;
        }

        init() {
          this.currentMoney = new (_crd && PlayerInfoService === void 0 ? (_reportPossibleCrUseOfPlayerInfoService({
            error: Error()
          }), PlayerInfoService) : PlayerInfoService)();
        }

        getBetResults(data) {
          let resultsMock = null;
          let resultMock = null;
          let betResults = null;
          resultMock = this.getResults();

          if (this.freeSpine == 0) {
            this.freeSpine = this.getNumberBasedOnProbability();
            console.log("freeSpine value", this.freeSpine);
          }

          let dataInfo = data.info;

          if (dataInfo.stake != 0) {} else {
            dataInfo.betLines = (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
              error: Error()
            }), Global) : Global).instance.RandomNumber(0, 5);
            dataInfo.stake = (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
              error: Error()
            }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
              error: Error()
            }), Global) : Global).instance.RandomNumber(0, 14)];
            this.freeSpine -= 1;
            console.log("free spine mock", this.freeSpine);
          }

          let paylines = this.getPaylines(dataInfo.betLines, resultMock);
          resultsMock = {
            balance: this.currentMoney.getCurrentMoney(),
            betLines: dataInfo.betLines,
            betTime: "1714025495622",
            freeSpins: this.freeSpine,
            id: "305317612076662785",
            jackpot: 0,
            paylines: paylines,
            payout: this.getPayout(paylines, dataInfo.stake),
            playType: "",
            processedTime: "1714025495630",
            refId: "305317612076662785",
            result: resultMock,
            roundId: "305317612076662785",
            settledTime: "1714025495630",
            stake: dataInfo.stake,
            winlose: -0.025
          };
          betResults = {
            code: 0,
            msg: "",
            result: resultsMock,
            status: 1
          };
          return betResults;
        }

        getPaylines(betline, resultMock) {
          let betLineRandom = (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
            error: Error()
          }), Global) : Global).instance.RandomNumber(0, betline);

          switch (betLineRandom) {
            case 0:
              let payLineMock = [];
              return payLineMock = [];
              break;

            case 1:
              return this.getPayline1(resultMock);
              break;

            case 2:
              return this.getPayline2(resultMock);
              break;

            case 3:
              return this.getPayline3(resultMock);
              break;

            case 4:
              return this.getPayline4(resultMock);
              break;

            case 5:
              return this.getPayline5(resultMock);
              break;
          }
        }

        getPayout(paylineMock, stake) {
          if (paylineMock.length == 0) {
            return 0;
          } else {
            let payoutSum = 0;

            for (let i = 0; i < paylineMock.length; i++) {
              let payout = paylineMock[i].payoutRate * stake;
              payoutSum = payoutSum + payout;
            }

            return payoutSum;
          }
        }

        getResults() {
          let resultsMock = null;
          resultsMock = {
            reel1: this.getRandomNumberList(),
            reel2: this.getRandomNumberList(),
            reel3: this.getRandomNumberList()
          };
          return resultsMock;
        }

        getRandomNumberList() {
          let numberList = [];

          for (let i = 0; i < 3; i++) {
            let randomNumber = (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
              error: Error()
            }), Global) : Global).instance.RandomNumber(1, 10);
            numberList.push(randomNumber);
          }

          return numberList;
        }

        getWinType(symbolIndexList) {
          return (_crd && SYMBOL_LIST === void 0 ? (_reportPossibleCrUseOfSYMBOL_LIST({
            error: Error()
          }), SYMBOL_LIST) : SYMBOL_LIST)[symbolIndexList[0] - 1] + "-" + (_crd && SYMBOL_LIST === void 0 ? (_reportPossibleCrUseOfSYMBOL_LIST({
            error: Error()
          }), SYMBOL_LIST) : SYMBOL_LIST)[symbolIndexList[1] - 1] + "-" + (_crd && SYMBOL_LIST === void 0 ? (_reportPossibleCrUseOfSYMBOL_LIST({
            error: Error()
          }), SYMBOL_LIST) : SYMBOL_LIST)[symbolIndexList[2] - 1];
        }

        getPayline1(resultMock) {
          let payLineMock = [];
          let payline = null;
          payline = {
            payline: 1,
            payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
              error: Error()
            }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
              error: Error()
            }), Global) : Global).instance.RandomNumber(0, 14)],
            symbols: [resultMock.reel1[1], resultMock.reel2[1], resultMock.reel3[1]],
            winType: this.getWinType([resultMock.reel1[1], resultMock.reel2[1], resultMock.reel3[1]])
          };
          payLineMock.push(payline);
          return payLineMock;
        }

        getPayline2(resultMock) {
          let payLineMock = [];
          let t = 0;
          let p = 0;

          for (let i = 0; i < 2; i++) {
            if (i == 0) {
              p = 1;
              t = 1;
            } else if (i == 1) {
              p = 2;
              t = 0;
            }

            let payline = null;
            payline = {
              payline: p,
              payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                error: Error()
              }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                error: Error()
              }), Global) : Global).instance.RandomNumber(0, 14)],
              symbols: [resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]],
              winType: this.getWinType([resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]])
            };
            payLineMock.push(payline);
          }

          return payLineMock;
        }

        getPayline3(resultMock) {
          let payLineMock = [];
          let t = 0;
          let p = 0;

          for (let i = 0; i < 3; i++) {
            if (i == 0) {
              t = 1;
              p = 1;
            } else if (i == 1) {
              t = 0;
              p = 2;
            } else if (i == 2) {
              t = 2;
              p = 3;
            }

            let payline = null;
            payline = {
              payline: p,
              payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                error: Error()
              }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                error: Error()
              }), Global) : Global).instance.RandomNumber(0, 14)],
              symbols: [resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]],
              winType: this.getWinType([resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]])
            };
            payLineMock.push(payline);
          }

          return payLineMock;
        }

        getPayline4(resultMock) {
          let payLineMock = [];
          let t = 0;
          let p = 0;

          for (let i = 0; i < 4; i++) {
            if (i == 0) {
              t = 1;
              p = 1;
            } else if (i == 1) {
              t = 0;
              p = 2;
            } else if (i == 2) {
              t = 2;
              p = 3;
            }

            if (i >= 0 && i < 3) {
              let payline = null;
              payline = {
                payline: p,
                payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                  error: Error()
                }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.RandomNumber(0, 14)],
                symbols: [resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]],
                winType: this.getWinType([resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]])
              };
              payLineMock.push(payline);
            } else if (i == 3) {
              let payline = null;
              payline = {
                payline: 4,
                payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                  error: Error()
                }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.RandomNumber(0, 14)],
                symbols: [resultMock.reel1[2], resultMock.reel2[1], resultMock.reel3[0]],
                winType: this.getWinType([resultMock.reel1[2], resultMock.reel2[1], resultMock.reel3[0]])
              };
              payLineMock.push(payline);
            }
          }

          return payLineMock;
        }

        getPayline5(resultMock) {
          let payLineMock = [];
          let t = 0;
          let p = 0;

          for (let i = 0; i < 4; i++) {
            if (i == 0) {
              p = 1;
              t = 1;
            } else if (i == 1) {
              p = 2;
              t = 0;
            } else if (i == 2) {
              p = 3;
              t = 2;
            }

            if (i >= 0 && i < 3) {
              let payline = null;
              payline = {
                payline: p,
                payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                  error: Error()
                }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.RandomNumber(0, 14)],
                symbols: [resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]],
                winType: this.getWinType([resultMock.reel1[t], resultMock.reel2[t], resultMock.reel3[t]])
              };
              payLineMock.push(payline);
            } else if (i == 3) {
              let payline = null;
              payline = {
                payline: 4,
                payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                  error: Error()
                }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.RandomNumber(0, 14)],
                symbols: [resultMock.reel1[2], resultMock.reel2[1], resultMock.reel3[0]],
                winType: this.getWinType([resultMock.reel1[2], resultMock.reel2[1], resultMock.reel3[0]])
              };
              payLineMock.push(payline);
            } else if (i == 4) {
              let payline = null;
              payline = {
                payline: 5,
                payoutRate: (_crd && PAY_OUT_RATE === void 0 ? (_reportPossibleCrUseOfPAY_OUT_RATE({
                  error: Error()
                }), PAY_OUT_RATE) : PAY_OUT_RATE)[(_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
                  error: Error()
                }), Global) : Global).instance.RandomNumber(0, 14)],
                symbols: [resultMock.reel1[0], resultMock.reel2[1], resultMock.reel3[2]],
                winType: this.getWinType([resultMock.reel1[0], resultMock.reel2[1], resultMock.reel3[2]])
              };
              payLineMock.push(payline);
            }
          }

          return payLineMock;
        }

        getNumberBasedOnProbability() {
          const randomNumber = Math.random() * 100;

          if (randomNumber == 1) {
            return (_crd && Global === void 0 ? (_reportPossibleCrUseOfGlobal({
              error: Error()
            }), Global) : Global).instance.RandomNumber(5, 15);
          } else {
            return 0;
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=21c0bff721579d356c5f8de4991942667d4da6c3.js.map