export type GameConfig = {
  GAME_ID: string;
  GAME_NAME: string;
  versionGame: string;
  isShowFPS: boolean;
  isUnitTest: boolean;
};
