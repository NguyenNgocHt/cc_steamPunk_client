import { HistoryData } from "../../dataModel/HistoryDataType";
export interface IHistoryContentView {
  updateHistoryContent(historyData: HistoryData);
}
