import { playerInfo } from "../../dataModel/PlayerDataType";

export interface IIconTrendView {
  updateValue(value: number);
}
