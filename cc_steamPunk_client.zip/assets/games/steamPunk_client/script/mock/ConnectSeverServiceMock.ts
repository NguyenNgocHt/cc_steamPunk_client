import { _decorator, Component, Node } from 'cc';
import { IConnectSeverServiceMock } from '../interfaces/Mock_interfaces';
const { ccclass, property } = _decorator;

@ccclass('ConnectSeverService')
export class ConnectSeverServiceMock  implements IConnectSeverServiceMock{
  
}


