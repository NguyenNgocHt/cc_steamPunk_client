export type HistoryData = {
  lbDate: string;
  lbTime: string;
  betID: number;
  risk: number;
  betAmount: number;
  multiplier: number;
  payout: number;
};
